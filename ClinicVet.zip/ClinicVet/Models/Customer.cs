using System;
using System.Collections.Generic;

namespace ClinicVets.Models
{
    /// <summary>
    /// Represents a pet owner / clinic customer.
    /// </summary>
    public class Customer
    {
        // ─────────────────────────────────────────────
        //  Properties
        // ─────────────────────────────────────────────
        public int      CustomerId  { get; set; }
        public string   FirstName   { get; set; }
        public string   LastName    { get; set; }
        public string   Phone       { get; set; }
        public string   Email       { get; set; }
        public string   Address     { get; set; }
        public string   City        { get; set; }
        public string   Notes       { get; set; }
        public bool     IsActive    { get; set; }
        public DateTime CreatedAt   { get; set; }
        public DateTime UpdatedAt   { get; set; }

        /// <summary>Animals owned by this customer (populated by service/repository when needed).</summary>
        public List<Animal> Animals { get; set; }

        // ─────────────────────────────────────────────
        //  Computed / display helpers
        // ─────────────────────────────────────────────
        public string FullName      => $"{FirstName} {LastName}";
        public string FullAddress   => string.IsNullOrWhiteSpace(City)
                                        ? Address
                                        : $"{Address}, {City}";

        // ─────────────────────────────────────────────
        //  Constructors
        // ─────────────────────────────────────────────

        /// <summary>Default constructor — required for data-binding and ORM mapping.</summary>
        public Customer()
        {
            FirstName = string.Empty;
            LastName  = string.Empty;
            Phone     = string.Empty;
            Email     = string.Empty;
            Address   = string.Empty;
            City      = string.Empty;
            Notes     = string.Empty;
            IsActive  = true;
            Animals   = new List<Animal>();
            CreatedAt = DateTime.Now;
            UpdatedAt = DateTime.Now;
        }

        /// <summary>Constructor for creating a new customer record.</summary>
        public Customer(string firstName, string lastName, string phone,
                        string email = "", string address = "", string city = "")
        {
            FirstName = firstName ?? throw new ArgumentNullException(nameof(firstName));
            LastName  = lastName  ?? throw new ArgumentNullException(nameof(lastName));
            Phone     = phone     ?? throw new ArgumentNullException(nameof(phone));
            Email     = email     ?? string.Empty;
            Address   = address   ?? string.Empty;
            City      = city      ?? string.Empty;
            Notes     = string.Empty;
            IsActive  = true;
            Animals   = new List<Animal>();
            CreatedAt = DateTime.Now;
            UpdatedAt = DateTime.Now;
        }

        // ─────────────────────────────────────────────
        //  Overrides
        // ─────────────────────────────────────────────
        public override string ToString() => FullName;

        public override bool Equals(object obj) =>
            obj is Customer other && CustomerId == other.CustomerId;

        public override int GetHashCode() => CustomerId.GetHashCode();
    }
}
