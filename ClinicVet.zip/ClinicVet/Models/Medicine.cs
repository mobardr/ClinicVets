using System;

namespace ClinicVets.Models
{
    /// <summary>
    /// Represents a medicine / pharmaceutical product held in clinic inventory.
    /// </summary>
    public class Medicine
    {
        // ─────────────────────────────────────────────
        //  Properties
        // ─────────────────────────────────────────────
        public int     MedicineId   { get; set; }
        public string  Name         { get; set; }
        public string  Description  { get; set; }
        public string  Unit         { get; set; }   // mg | ml | tablet | etc.
        public double  UnitPrice    { get; set; }
        public double  StockQty     { get; set; }
        public double  ReorderLevel { get; set; }
        public bool    IsActive     { get; set; }
        public DateTime CreatedAt   { get; set; }
        public DateTime UpdatedAt   { get; set; }

        // ─────────────────────────────────────────────
        //  Computed helpers
        // ─────────────────────────────────────────────

        /// <summary>True when current stock is at or below the reorder level.</summary>
        public bool IsLowStock => StockQty <= ReorderLevel;

        /// <summary>Formatted price string for display.</summary>
        public string PriceDisplay => $"${UnitPrice:F2} / {Unit}";

        /// <summary>Stock status label for UI badges.</summary>
        public string StockStatus =>
            StockQty == 0      ? "Out of Stock" :
            IsLowStock         ? "Low Stock"    :
                                 "In Stock";

        // ─────────────────────────────────────────────
        //  Constructors
        // ─────────────────────────────────────────────

        /// <summary>Default constructor — required for data-binding and ORM mapping.</summary>
        public Medicine()
        {
            Name         = string.Empty;
            Description  = string.Empty;
            Unit         = "mg";
            UnitPrice    = 0.0;
            StockQty     = 0.0;
            ReorderLevel = 10.0;
            IsActive     = true;
            CreatedAt    = DateTime.Now;
            UpdatedAt    = DateTime.Now;
        }

        /// <summary>Constructor for adding a new medicine to inventory.</summary>
        public Medicine(string name, string unit, double unitPrice,
                        double stockQty, double reorderLevel, string description = "")
        {
            Name         = name  ?? throw new ArgumentNullException(nameof(name));
            Unit         = unit  ?? "mg";
            Description  = description ?? string.Empty;
            UnitPrice    = unitPrice    >= 0 ? unitPrice    : throw new ArgumentOutOfRangeException(nameof(unitPrice));
            StockQty     = stockQty     >= 0 ? stockQty     : throw new ArgumentOutOfRangeException(nameof(stockQty));
            ReorderLevel = reorderLevel >= 0 ? reorderLevel : throw new ArgumentOutOfRangeException(nameof(reorderLevel));
            IsActive     = true;
            CreatedAt    = DateTime.Now;
            UpdatedAt    = DateTime.Now;
        }

        // ─────────────────────────────────────────────
        //  Methods
        // ─────────────────────────────────────────────

        /// <summary>
        /// Deducts quantity from stock. Throws if stock would go negative.
        /// </summary>
        public void DeductStock(double quantity)
        {
            if (quantity <= 0)
                throw new ArgumentOutOfRangeException(nameof(quantity), "Quantity must be positive.");
            if (quantity > StockQty)
                throw new InvalidOperationException(
                    $"Insufficient stock for '{Name}'. Available: {StockQty} {Unit}, Requested: {quantity} {Unit}.");
            StockQty  -= quantity;
            UpdatedAt  = DateTime.Now;
        }

        /// <summary>Adds quantity to stock (restocking).</summary>
        public void AddStock(double quantity)
        {
            if (quantity <= 0)
                throw new ArgumentOutOfRangeException(nameof(quantity), "Quantity must be positive.");
            StockQty  += quantity;
            UpdatedAt  = DateTime.Now;
        }

        // ─────────────────────────────────────────────
        //  Overrides
        // ─────────────────────────────────────────────
        public override string ToString() => $"{Name} ({Unit})";

        public override bool Equals(object obj) =>
            obj is Medicine other && MedicineId == other.MedicineId;

        public override int GetHashCode() => MedicineId.GetHashCode();
    }
}
