using System;
using System.Collections.Generic;
using System.Linq;

namespace ClinicVets.Models
{
    // ═════════════════════════════════════════════════════════════════
    //  VisitMedicine  (line item: medicine prescribed in a visit)
    // ═════════════════════════════════════════════════════════════════

    /// <summary>
    /// Junction entity linking a Visit to a Medicine with quantity and dosage.
    /// </summary>
    public class VisitMedicine
    {
        // ─────────────────────────────────────────────
        //  Properties
        // ─────────────────────────────────────────────
        public int    VisitMedicineId { get; set; }
        public int    VisitId         { get; set; }
        public int    MedicineId      { get; set; }
        public double Quantity        { get; set; }
        public double UnitPrice       { get; set; }   // snapshot price at time of visit
        public string Dosage          { get; set; }
        public string Instructions    { get; set; }
        public DateTime CreatedAt     { get; set; }

        // ─────────────────────────────────────────────
        //  Navigation properties
        // ─────────────────────────────────────────────
        public Medicine Medicine { get; set; }

        // ─────────────────────────────────────────────
        //  Computed helpers
        // ─────────────────────────────────────────────
        public double LineTotal => Math.Round(Quantity * UnitPrice, 2);

        public string DisplaySummary =>
            Medicine != null
                ? $"{Medicine.Name} — {Quantity} {Medicine.Unit} @ ${UnitPrice:F2}"
                : $"Medicine #{MedicineId} — {Quantity} units";

        // ─────────────────────────────────────────────
        //  Constructors
        // ─────────────────────────────────────────────
        public VisitMedicine()
        {
            Dosage       = string.Empty;
            Instructions = string.Empty;
            CreatedAt    = DateTime.Now;
        }

        public VisitMedicine(int visitId, int medicineId,
                             double quantity, double unitPrice,
                             string dosage = "", string instructions = "")
        {
            VisitId      = visitId;
            MedicineId   = medicineId;
            Quantity     = quantity   > 0 ? quantity  : throw new ArgumentOutOfRangeException(nameof(quantity));
            UnitPrice    = unitPrice  >= 0 ? unitPrice : throw new ArgumentOutOfRangeException(nameof(unitPrice));
            Dosage       = dosage        ?? string.Empty;
            Instructions = instructions  ?? string.Empty;
            CreatedAt    = DateTime.Now;
        }

        public override string ToString() => DisplaySummary;
    }


    // ═════════════════════════════════════════════════════════════════
    //  Visit
    // ═════════════════════════════════════════════════════════════════

    /// <summary>
    /// Represents a single clinic visit / appointment for an animal.
    /// </summary>
    public class Visit
    {
        // ─────────────────────────────────────────────
        //  Properties
        // ─────────────────────────────────────────────
        public int      VisitId    { get; set; }
        public int      AnimalId   { get; set; }
        public int      EmployeeId { get; set; }
        public DateTime VisitDate  { get; set; }
        public string   Reason     { get; set; }
        public string   Diagnosis  { get; set; }
        public string   Treatment  { get; set; }
        public string   Notes      { get; set; }
        public double   TotalCost  { get; set; }
        public bool     IsPaid     { get; set; }
        public string   Status     { get; set; }   // Scheduled | InProgress | Completed | Cancelled
        public DateTime CreatedAt  { get; set; }
        public DateTime UpdatedAt  { get; set; }

        // ─────────────────────────────────────────────
        //  Navigation properties (populated by service)
        // ─────────────────────────────────────────────
        public Animal               Animal          { get; set; }
        public Employee             Veterinarian    { get; set; }
        public List<VisitMedicine>  VisitMedicines  { get; set; }

        // ─────────────────────────────────────────────
        //  Computed helpers
        // ─────────────────────────────────────────────

        /// <summary>Sum of all medicine line totals.</summary>
        public double MedicineCost =>
            VisitMedicines?.Sum(vm => vm.LineTotal) ?? 0.0;

        /// <summary>Formatted total cost for display.</summary>
        public string TotalCostDisplay => $"${TotalCost:F2}";

        /// <summary>Payment status label.</summary>
        public string PaymentStatus => IsPaid ? "Paid" : "Unpaid";

        /// <summary>True when the visit can still be edited (not completed/cancelled).</summary>
        public bool IsEditable =>
            Status == "Scheduled" || Status == "InProgress";

        /// <summary>Short one-line summary for grids.</summary>
        public string DisplaySummary =>
            $"{VisitDate:dd/MM/yyyy} — {Reason} [{Status}]";

        // ─────────────────────────────────────────────
        //  Constructors
        // ─────────────────────────────────────────────

        /// <summary>Default constructor — required for data-binding and ORM mapping.</summary>
        public Visit()
        {
            Reason         = string.Empty;
            Diagnosis      = string.Empty;
            Treatment      = string.Empty;
            Notes          = string.Empty;
            Status         = "Scheduled";
            TotalCost      = 0.0;
            IsPaid         = false;
            VisitDate      = DateTime.Today;
            VisitMedicines = new List<VisitMedicine>();
            CreatedAt      = DateTime.Now;
            UpdatedAt      = DateTime.Now;
        }

        /// <summary>Constructor for scheduling a new visit.</summary>
        public Visit(int animalId, int employeeId, DateTime visitDate, string reason)
        {
            AnimalId       = animalId;
            EmployeeId     = employeeId;
            VisitDate      = visitDate;
            Reason         = reason ?? throw new ArgumentNullException(nameof(reason));
            Diagnosis      = string.Empty;
            Treatment      = string.Empty;
            Notes          = string.Empty;
            Status         = "Scheduled";
            TotalCost      = 0.0;
            IsPaid         = false;
            VisitMedicines = new List<VisitMedicine>();
            CreatedAt      = DateTime.Now;
            UpdatedAt      = DateTime.Now;
        }

        // ─────────────────────────────────────────────
        //  Methods
        // ─────────────────────────────────────────────

        /// <summary>Marks the visit as completed and sets the final cost.</summary>
        public void Complete(double totalCost)
        {
            if (Status == "Cancelled")
                throw new InvalidOperationException("Cannot complete a cancelled visit.");

            Status    = "Completed";
            TotalCost = totalCost >= 0 ? totalCost
                        : throw new ArgumentOutOfRangeException(nameof(totalCost));
            UpdatedAt = DateTime.Now;
        }

        /// <summary>Cancels the visit.</summary>
        public void Cancel()
        {
            if (Status == "Completed")
                throw new InvalidOperationException("Cannot cancel a completed visit.");

            Status    = "Cancelled";
            UpdatedAt = DateTime.Now;
        }

        /// <summary>Marks the visit invoice as paid.</summary>
        public void MarkPaid()
        {
            IsPaid    = true;
            UpdatedAt = DateTime.Now;
        }

        // ─────────────────────────────────────────────
        //  Overrides
        // ─────────────────────────────────────────────
        public override string ToString() => DisplaySummary;

        public override bool Equals(object obj) =>
            obj is Visit other && VisitId == other.VisitId;

        public override int GetHashCode() => VisitId.GetHashCode();
    }
}
