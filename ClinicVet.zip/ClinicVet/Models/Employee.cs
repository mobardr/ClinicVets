using System;

namespace ClinicVets.Models
{
    /// <summary>
    /// Represents a clinic employee (Veterinarian, Technician, Receptionist, Manager).
    /// </summary>
    public class Employee
    {
        // ─────────────────────────────────────────────
        //  Properties
        // ─────────────────────────────────────────────
        public int EmployeeId { get; set; }
        public string Username { get; set; }   // 6-8 chars, max 2 digits
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Role { get; set; }   // Veterinarian | Secretary
        public string Phone { get; set; }
        public string Email { get; set; }
        public string EmployeeNumber { get; set; }   // exactly 4 digits
        public string IdNumber { get; set; }   // Israeli ID 9 digits
        public DateTime HireDate { get; set; }
        public bool IsActive { get; set; }
        public string PasswordHash { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime UpdatedAt { get; set; }

        // ─────────────────────────────────────────────
        //  Computed / display helpers
        // ─────────────────────────────────────────────
        /// <summary>Full name for display in UI controls.</summary>
        public string FullName => $"{FirstName} {LastName}";

        /// <summary>Display label including role, e.g. "Dr. Sarah Mitchell (Veterinarian)".</summary>
        public string DisplayLabel =>
            Role == "Veterinarian"
                ? $"Dr. {FullName} ({Role})"
                : $"{FullName} ({Role})";  // Secretary

        // ─────────────────────────────────────────────
        //  Constructors
        // ─────────────────────────────────────────────

        /// <summary>Default constructor — required for data-binding and ORM mapping.</summary>
        public Employee()
        {
            Username = string.Empty;
            FirstName = string.Empty;
            LastName = string.Empty;
            Role = "Secretary";
            Phone = string.Empty;
            Email = string.Empty;
            EmployeeNumber = string.Empty;
            IdNumber = string.Empty;
            PasswordHash = string.Empty;
            HireDate = DateTime.Today;
            IsActive = true;
            CreatedAt = DateTime.Now;
            UpdatedAt = DateTime.Now;
        }

        /// <summary>Full constructor for creating a new employee record.</summary>
        public Employee(string firstName, string lastName, string role,
                        string phone, string email, DateTime hireDate)
        {
            FirstName = firstName ?? throw new ArgumentNullException(nameof(firstName));
            LastName = lastName ?? throw new ArgumentNullException(nameof(lastName));
            Role = role ?? throw new ArgumentNullException(nameof(role));
            Phone = phone ?? string.Empty;
            Email = email ?? string.Empty;
            PasswordHash = string.Empty;
            HireDate = hireDate;
            IsActive = true;
            CreatedAt = DateTime.Now;
            UpdatedAt = DateTime.Now;
        }

        // ─────────────────────────────────────────────
        //  Overrides
        // ─────────────────────────────────────────────
        public override string ToString() => FullName;

        public override bool Equals(object obj) =>
            obj is Employee other && EmployeeId == other.EmployeeId;

        public override int GetHashCode() => EmployeeId.GetHashCode();
    }
}