using System;

namespace ClinicVets.Models
{
    /// <summary>
    /// Represents a category of animal (e.g. Dog, Cat, Bird).
    /// Used as a lookup / reference table.
    /// </summary>
    public class AnimalType
    {
        // ─────────────────────────────────────────────
        //  Properties
        // ─────────────────────────────────────────────
        public int    AnimalTypeId { get; set; }
        public string TypeName     { get; set; }
        public string Description  { get; set; }
        public DateTime CreatedAt  { get; set; }

        // ─────────────────────────────────────────────
        //  Constructors
        // ─────────────────────────────────────────────

        /// <summary>Default constructor — required for data-binding and ORM mapping.</summary>
        public AnimalType()
        {
            TypeName    = string.Empty;
            Description = string.Empty;
            CreatedAt   = DateTime.Now;
        }

        /// <summary>Constructor for creating a new animal type.</summary>
        public AnimalType(string typeName, string description = "")
        {
            TypeName    = typeName    ?? throw new ArgumentNullException(nameof(typeName));
            Description = description ?? string.Empty;
            CreatedAt   = DateTime.Now;
        }

        // ─────────────────────────────────────────────
        //  Overrides
        // ─────────────────────────────────────────────
        public override string ToString() => TypeName;

        public override bool Equals(object obj) =>
            obj is AnimalType other && AnimalTypeId == other.AnimalTypeId;

        public override int GetHashCode() => AnimalTypeId.GetHashCode();
    }
}
