using System;
using System.Collections.Generic;

namespace ClinicVets.Models
{
    /// <summary>
    /// Represents a patient animal belonging to a customer.
    /// </summary>
    public class Animal
    {
        // ─────────────────────────────────────────────
        //  Properties
        // ─────────────────────────────────────────────
        public int      AnimalId     { get; set; }
        public int      CustomerId   { get; set; }
        public int      AnimalTypeId { get; set; }
        public string   Name         { get; set; }
        public string   Breed        { get; set; }
        public DateTime? DateOfBirth { get; set; }
        public string   Gender       { get; set; }   // Male | Female | Unknown
        public double   Weight       { get; set; }   // kg
        public string   Color        { get; set; }
        public string   Microchip    { get; set; }
        public string   Notes        { get; set; }
        public bool     IsActive     { get; set; }
        public DateTime CreatedAt    { get; set; }
        public DateTime UpdatedAt    { get; set; }

        // ─────────────────────────────────────────────
        //  Navigation properties (populated by service)
        // ─────────────────────────────────────────────
        public Customer    Owner      { get; set; }
        public AnimalType  AnimalType { get; set; }
        public List<Visit> Visits     { get; set; }

        // ─────────────────────────────────────────────
        //  Computed helpers
        // ─────────────────────────────────────────────

        /// <summary>Age in whole years, or null if date of birth is unknown.</summary>
        public int? AgeYears
        {
            get
            {
                if (!DateOfBirth.HasValue) return null;
                var today = DateTime.Today;
                int age = today.Year - DateOfBirth.Value.Year;
                if (DateOfBirth.Value.Date > today.AddYears(-age)) age--;
                return age;
            }
        }

        /// <summary>Human-friendly age string, e.g. "3 years" or "8 months".</summary>
        public string AgeDisplay
        {
            get
            {
                if (!DateOfBirth.HasValue) return "Unknown";
                var months = ((DateTime.Today.Year - DateOfBirth.Value.Year) * 12)
                             + DateTime.Today.Month - DateOfBirth.Value.Month;
                if (months >= 12) return $"{months / 12} yr{(months / 12 == 1 ? "" : "s")}";
                return $"{months} mo{(months == 1 ? "" : "s")}";
            }
        }

        /// <summary>Short summary for grid / combo display.</summary>
        public string DisplayLabel =>
            $"{Name}" + (AnimalType != null ? $" ({AnimalType.TypeName})" : string.Empty);

        // ─────────────────────────────────────────────
        //  Constructors
        // ─────────────────────────────────────────────

        /// <summary>Default constructor — required for data-binding and ORM mapping.</summary>
        public Animal()
        {
            Name      = string.Empty;
            Breed     = string.Empty;
            Gender    = "Unknown";
            Color     = string.Empty;
            Microchip = string.Empty;
            Notes     = string.Empty;
            IsActive  = true;
            Visits    = new List<Visit>();
            CreatedAt = DateTime.Now;
            UpdatedAt = DateTime.Now;
        }

        /// <summary>Constructor for registering a new animal.</summary>
        public Animal(int customerId, int animalTypeId, string name,
                      string breed = "", string gender = "Unknown",
                      DateTime? dateOfBirth = null, double weight = 0)
        {
            CustomerId   = customerId;
            AnimalTypeId = animalTypeId;
            Name         = name   ?? throw new ArgumentNullException(nameof(name));
            Breed        = breed  ?? string.Empty;
            Gender       = gender ?? "Unknown";
            DateOfBirth  = dateOfBirth;
            Weight       = weight;
            Color        = string.Empty;
            Microchip    = string.Empty;
            Notes        = string.Empty;
            IsActive     = true;
            Visits       = new List<Visit>();
            CreatedAt    = DateTime.Now;
            UpdatedAt    = DateTime.Now;
        }

        // ─────────────────────────────────────────────
        //  Overrides
        // ─────────────────────────────────────────────
        public override string ToString() => DisplayLabel;

        public override bool Equals(object obj) =>
            obj is Animal other && AnimalId == other.AnimalId;

        public override int GetHashCode() => AnimalId.GetHashCode();
    }
}
