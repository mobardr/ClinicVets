using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace ClinicVets.UI
{
    /// <summary>
    /// ClinicVets centralised design system.
    ///
    /// Professional veterinary clinic aesthetic:
    ///   - Deep navy-teal foundation (trust + clinical authority)
    ///   - Warm sage-green accent (nature, health, vitality)
    ///   - Amber alert colour (urgency without panic)
    ///   - Crisp white text on rich dark surfaces
    ///   - "DM Sans" display pairing with "Segoe UI" body
    ///
    /// Usage:
    ///   UITheme.Apply(form);                  // bootstrap a Form
    ///   UITheme.StylePrimaryBtn(button);       // accent CTA
    ///   UITheme.StyleGrid(dgv);                // DataGridView skin
    ///   UITheme.MakeStatCard(panel, ...);      // stat tile
    ///
    /// All sizes/colours are defined as constants/statics so every
    /// form is pixel-perfect consistent without copy-pasting values.
    /// </summary>
    public static class UITheme
    {
        // ══════════════════════════════════════════════════════════════
        //  COLOUR PALETTE - Claude-inspired "Warm Paper" theme
        //
        //  Aesthetic:
        //    Warm cream paper foundation with terracotta accents.
        //    No pure white, no pure black - every surface has a slight
        //    warm undertone for a soft, readable, premium feel.
        //
        //  Background ramp (light theme):
        //    BgInput      #FAF7F1  (250,247,241)  - input field bg (lightest)
        //    BgRoot       #FBF9F6  (251,249,246)  - page canvas (paper)
        //    BgToolbar    #F7F2E9  (247,242,233)  - top/side bars
        //    BgSurface    #F4EFE6  (244,239,230)  - panels (warm sand)
        //    BgCard       #EFE8DC  (239,232,220)  - cards
        //    BgCardHover  #E8DFCE  (232,223,206)  - hover lift
        //
        //  Accent ramp (warm terracotta #D97756):
        //    AccentSoft   #EFD4C5  (239,212,197)  - bg tint
        //    AccentDim    #F5E4DB  (245,228,219)  - deep tint
        //    Accent       #D97756  (217,119, 86)  - primary CTA
        //    AccentHover  #C56841  (197,104, 65)  - hover
        //    AccentActive #B05A38  (176, 90, 56)  - pressed
        // ══════════════════════════════════════════════════════════════

        // ── Base surfaces ─────────────────────────────────────────────
        public static readonly Color BgRoot = Color.FromArgb(251, 249, 246);  // #FBF9F6 paper
        public static readonly Color BgToolbar = Color.FromArgb(247, 242, 233);  // #F7F2E9
        public static readonly Color BgSurface = Color.FromArgb(244, 239, 230);  // #F4EFE6 warm sand ★
        public static readonly Color BgCard = Color.FromArgb(239, 232, 220);  // #EFE8DC
        public static readonly Color BgCardHover = Color.FromArgb(232, 223, 206);  // #E8DFCE
        public static readonly Color BgInput = Color.FromArgb(255, 255, 255);  // #FFFFFF pure white - stands out clearly on cream card
        public static readonly Color BgAltRow = Color.FromArgb(247, 242, 233);  // #F7F2E9 alt row
        public static readonly Color BgOverlay = Color.FromArgb(170, 25, 25, 25);  // modal scrim

        // ── Primary accent - #D97756 Terracotta ────────────────────────
        public static readonly Color Accent = Color.FromArgb(217, 119, 86);  // #D97756 ★
        public static readonly Color AccentHover = Color.FromArgb(197, 104, 65);  // #C56841
        public static readonly Color AccentActive = Color.FromArgb(176, 90, 56);  // #B05A38 pressed
        public static readonly Color AccentSoft = Color.FromArgb(239, 212, 197);  // #EFD4C5
        public static readonly Color AccentDim = Color.FromArgb(245, 228, 219);  // #F5E4DB
        public static readonly Color AccentText = Color.FromArgb(184, 92, 55);  // #B85C37 readable on cream
        public static readonly Color AccentMuted = Color.FromArgb(217, 162, 138);  // for icons/dividers

        // ── Secondary accent - Muted Olive (info / secondary CTAs) ─────
        public static readonly Color AccentCyan = Color.FromArgb(122, 138, 88);  // #7A8A58 olive
        public static readonly Color AccentCyanDim = Color.FromArgb(232, 234, 216);  // #E8EAD8

        // ── Backward-compat aliases ────────────────────────────────────
        public static readonly Color AccentGreen = Accent;
        public static readonly Color AccentGreenHover = AccentHover;
        public static readonly Color AccentGreenDim = AccentDim;
        public static readonly Color AccentViolet = Accent;
        public static readonly Color AccentVioletDim = AccentDim;
        public static readonly Color AccentBlue = AccentCyan;
        public static readonly Color AccentBlueDim = AccentCyanDim;

        // ── Semantic - muted earth tones to match palette ──────────────
        public static readonly Color SemanticDanger = Color.FromArgb(181, 65, 58);  // #B5413A
        public static readonly Color SemanticDangerBg = Color.FromArgb(248, 224, 220);  // #F8E0DC
        public static readonly Color SemanticWarning = Color.FromArgb(176, 126, 42);  // #B07E2A
        public static readonly Color SemanticWarningBg = Color.FromArgb(248, 236, 210);  // #F8ECD2
        public static readonly Color SemanticSuccess = Color.FromArgb(74, 124, 79);  // #4A7C4F
        public static readonly Color SemanticSuccessBg = Color.FromArgb(225, 236, 220);  // #E1ECDC
        public static readonly Color SemanticAmber = SemanticWarning;

        // ── Text hierarchy - deep charcoal, never pure black ───────────
        public static readonly Color TextPrimary = Color.FromArgb(25, 25, 25);  // #191919 charcoal ★
        public static readonly Color TextSecondary = Color.FromArgb(61, 53, 40);  // #3D3528 warm brown
        public static readonly Color TextMuted = Color.FromArgb(122, 111, 94);  // #7A6F5E warm muted
        public static readonly Color TextDisabled = Color.FromArgb(176, 166, 151);  // #B0A697

        // ── Borders ────────────────────────────────────────────────────
        public static readonly Color BorderDefault = Color.FromArgb(180, 165, 140);  // #B4A58C - stronger warm border, clearly visible
        public static readonly Color BorderFocus = Accent;
        public static readonly Color BorderSubtle = Color.FromArgb(232, 223, 206);  // #E8DFCE
        public static readonly Color BorderAccent = Color.FromArgb(217, 162, 138);  // accent-tinted

        // ── DataGridView ───────────────────────────────────────────────
        public static readonly Color GridSelection = Color.FromArgb(242, 221, 208);  // #F2DDD0 soft terracotta

        // ── Navigation ─────────────────────────────────────────────────
        public static readonly Color NavActive = BgCard;
        public static readonly Color NavActiveFore = Accent;

        // ── Shadow / glow ──────────────────────────────────────────────
        public static readonly Color ShadowDark = Color.FromArgb(40, 25, 25, 25);  // soft charcoal shadow
        public static readonly Color GlowAccent = Color.FromArgb(70, 217, 119, 86);  // alpha=70, #D97756

        // ══════════════════════════════════════════════════════════════
        //  SPACING
        // ══════════════════════════════════════════════════════════════
        public const int SpaceXS = 4;
        public const int SpaceSM = 8;
        public const int SpaceMD = 16;
        public const int SpaceLG = 24;
        public const int SpaceXL = 36;
        public const int SpaceXXL = 52;

        public const int RadiusSM = 4;
        public const int RadiusMD = 8;
        public const int RadiusLG = 12;

        public const int ToolbarH = 58;
        public const int StatRowH = 74;
        public const int SearchBarH = 50;
        public const int InputH = 32;
        public const int GridRowH = 40;
        public const int GridHdrH = 40;

        // ══════════════════════════════════════════════════════════════
        //  RESPONSIVE LAYOUT SYSTEM
        //
        //  WinForms has no CSS. We implement responsive behaviour by:
        //    1. CentredContainer   - a Panel that keeps its child
        //       centred and constrained to a max width, expands to
        //       fill remaining space with BgRoot colour.
        //    2. ResponsiveCard     - a Panel that scales its width
        //       between minW and maxW as a % of the parent.
        //    3. CentreInParent     - utility to reposition a fixed-
        //       size child whenever the parent resizes.
        //    4. Breakpoints        - widths at which layout changes.
        // ══════════════════════════════════════════════════════════════

        // ── Breakpoints (container width, not screen) ──────────────────
        public const int BpSM = 900;   // "small"  - compact layout
        public const int BpMD = 1280;   // "medium" - default
        public const int BpLG = 1600;   // "large"  - wide / 1440p+

        // ── Card constraints ───────────────────────────────────────────
        public const int CardMinW = 420;   // never narrower than this
        public const int CardMaxW = 640;   // auth/form cards
        public const int CardWideW = 960;   // dashboard welcome card
        public const int CardMaxH = 720;

        // ── Content column constraints ─────────────────────────────────
        public const int ContentMinW = 600;
        public const int ContentMaxW = 1200;

        // ── Returns the best card width for the given container width ──
        /// <param name="containerW">Width of the panel the card lives in.</param>
        /// <param name="maxW">Upper cap (default CardMaxW).</param>
        /// <param name="pct">Target % of container (default 0.70).</param>
        public static int CardWidth(int containerW,
                                     int maxW = 640,
                                     float pct = 0.70f)
        {
            int raw = (int)(containerW * pct);
            return Math.Max(CardMinW, Math.Min(maxW, raw));
        }

        /// <summary>
        /// Creates a DockStyle.Fill panel that centres <paramref name="child"/>
        /// horizontally and vertically, clamping its width to
        /// <paramref name="maxW"/> and keeping BgRoot side gutters.
        /// Call this instead of manually writing Resize handlers everywhere.
        /// </summary>
        public static Panel CentredContainer(Control child,
                                              int maxW = 1200,
                                              int verticalPadding = 36)
        {
            var outer = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = BgRoot
            };

            void Recentre()
            {
                int w = Math.Min(outer.ClientSize.Width, maxW);
                int h = outer.ClientSize.Height - verticalPadding * 2;

                // Keep original size ratios if child has one
                if (child.Dock != DockStyle.None) child.Dock = DockStyle.None;

                child.Width = w;
                child.Height = Math.Max(1, h);
                child.Location = new System.Drawing.Point(
                    (outer.ClientSize.Width - w) / 2,
                    verticalPadding);
            }

            outer.Controls.Add(child);
            outer.Resize += (s, e) => Recentre();
            outer.HandleCreated += (s, e) => Recentre();
            return outer;
        }

        /// <summary>
        /// Centres <paramref name="inner"/> inside <paramref name="outer"/>
        /// both axes, clamped to <paramref name="maxW"/> × <paramref name="maxH"/>.
        /// Wires a Resize handler automatically.
        /// </summary>
        public static void CentreInParent(Control outer, Control inner,
                                           int maxW = 640,
                                           int maxH = 720,
                                           int topOffset = 0)
        {
            if (outer == null || inner == null) return;
            void Calc()
            {
                if (outer.Width < 1 || outer.Height < 1) return;
                int w = Math.Min(outer.Width, maxW);
                int h = Math.Min(outer.Height - topOffset, maxH);
                inner.Size = new System.Drawing.Size(Math.Max(CardMinW, w), Math.Max(200, h));
                inner.Location = new System.Drawing.Point(
                    (outer.Width - inner.Width) / 2,
                    topOffset + (outer.Height - topOffset - inner.Height) / 2);
            }
            outer.Resize += (s, e) => Calc();
            if (outer.IsHandleCreated) Calc();
            else outer.HandleCreated += (s, e) => Calc();
        }

        /// <summary>
        /// Creates a horizontal row of equally-spaced panels inside a
        /// container, redistributing space on resize.  Returns the row panel.
        /// </summary>
        public static Panel ResponsiveCardRow(Control[] cards,
                                               int cardH,
                                               int gap = SpaceLG,
                                               int padX = SpaceLG,
                                               int padY = SpaceLG)
        {
            var row = new Panel { Dock = DockStyle.Fill, BackColor = BgRoot };

            void Lay()
            {
                if (row.Width < 1 || cards.Length == 0) return;
                int avail = row.ClientSize.Width - padX * 2 - gap * (cards.Length - 1);
                int w = Math.Max(120, avail / cards.Length);
                for (int i = 0; i < cards.Length; i++)
                {
                    cards[i].Size = new System.Drawing.Size(w, cardH);
                    cards[i].Location = new System.Drawing.Point(
                        padX + i * (w + gap),
                        (row.ClientSize.Height - cardH) / 2);
                    if (!row.Controls.Contains(cards[i]))
                        row.Controls.Add(cards[i]);
                }
            }

            row.Resize += (s, e) => Lay();
            row.HandleCreated += (s, e) => Lay();
            return row;
        }

        // ── Typography scaling ─────────────────────────────────────────
        /// <summary>Returns a scaled font size based on container width.</summary>
        public static float ScaledFontSize(float baseSizePt, int containerW,
                                            int refW = BpMD)
        {
            float scale = Math.Max(0.80f, Math.Min(1.25f, (float)containerW / refW));
            return (float)Math.Round(baseSizePt * scale, 1);
        }


        public static string GetAnimalIcon(string typeName)
        {
            if (typeName == null) return "🐾";
            return typeName.ToLower() switch
            {
                "dog" => "🐕",
                "cat" => "🐈",
                "bird" => "🦜",
                "rabbit" => "🐇",
                "hamster" => "🐹",
                "reptile" => "🦎",
                "fish" => "🐟",
                "horse" => "🐎",
                "turtle" => "🐢",
                _ => "🐾"
            };
        }

        // ══════════════════════════════════════════════════════════════
        //  TYPOGRAPHY
        // ══════════════════════════════════════════════════════════════

        // WinForms falls back gracefully if DM Sans is absent
        public static readonly Font FontPageTitle = new Font("DM Sans", 16f, FontStyle.Bold);
        public static readonly Font FontSectionHdr = new Font("DM Sans", 11f, FontStyle.Bold);
        public static readonly Font FontLabel = new Font("Segoe UI", 8.5f, FontStyle.Bold);
        public static readonly Font FontBody = new Font("Segoe UI", 9.5f);
        public static readonly Font FontBodySmall = new Font("Segoe UI", 8.5f);
        public static readonly Font FontInput = new Font("Segoe UI", 10.5f);
        public static readonly Font FontBtnPrimary = new Font("DM Sans", 10f, FontStyle.Bold);
        public static readonly Font FontBtnSecond = new Font("Segoe UI", 9.5f);
        public static readonly Font FontGridHeader = new Font("Segoe UI", 8.5f, FontStyle.Bold);
        public static readonly Font FontGridCell = new Font("Segoe UI", 9.5f);
        public static readonly Font FontStat = new Font("DM Sans", 22f, FontStyle.Bold);
        public static readonly Font FontStatLabel = new Font("Segoe UI", 7.5f, FontStyle.Bold);
        public static readonly Font FontBadge = new Font("Segoe UI", 8f, FontStyle.Bold);
        public static readonly Font FontBrand = new Font("DM Sans", 20f, FontStyle.Bold);
        public static readonly Font FontMono = new Font("Cascadia Mono", 9.5f);

        // ── Convenience aliases ────────────────────────────────────────
        /// <summary>Alias for FontPageTitle - page headings.</summary>
        public static readonly Font FontTitle = FontPageTitle;
        /// <summary>Alias for FontSectionHdr - card subtitles.</summary>
        public static readonly Font FontSubtitle = FontSectionHdr;

        // ══════════════════════════════════════════════════════════════
        //  FORM BOOTSTRAP
        // ══════════════════════════════════════════════════════════════

        /// <summary>
        /// Applies root theme to a Form: background, font, border colour.
        /// Call in the constructor AFTER InitializeComponent().
        /// </summary>
        public static void Apply(Form form)
        {
            form.BackColor = BgRoot;
            form.Font = FontBody;
            form.ForeColor = TextPrimary;
        }

        /// <summary>
        /// Applies root theme to a UserControl panel.
        /// </summary>
        public static void Apply(UserControl uc)
        {
            uc.BackColor = BgRoot;
            uc.Font = FontBody;
            uc.ForeColor = TextPrimary;
        }

        // ══════════════════════════════════════════════════════════════
        //  BUTTON FACTORY
        // ══════════════════════════════════════════════════════════════

        /// <summary>Primary CTA - solid terracotta with cream text (Claude-style).</summary>
        public static void StylePrimaryBtn(Button btn, string text = null)
        {
            Apply(btn, Accent, BgRoot, AccentHover, text);
            btn.BackColor = Accent;
            btn.ForeColor = BgRoot;                    // cream on terracotta = strong contrast
            btn.Font = FontBtnPrimary;
            btn.FlatAppearance.BorderColor = AccentHover;
            btn.FlatAppearance.BorderSize = 0;
            btn.FlatAppearance.MouseOverBackColor = AccentHover;
            btn.FlatAppearance.MouseDownBackColor = AccentActive;
            btn.MouseEnter += (s, e) => ((Button)s).BackColor = AccentHover;
            btn.MouseLeave += (s, e) => ((Button)s).BackColor = Accent;
        }

        /// <summary>Cobalt blue secondary - Edit, View, Info.</summary>
        public static void StyleSecondaryBtn(Button btn, string text = null)
        {
            Apply(btn, AccentBlueDim, AccentBlue, AccentVioletDim, text);
            btn.Font = FontBtnSecond;
            btn.FlatAppearance.MouseOverBackColor = AccentVioletDim;
        }

        /// <summary>Danger / Delete.</summary>
        public static void StyleDangerBtn(Button btn, string text = null)
        {
            Apply(btn, SemanticDangerBg, SemanticDanger, SemanticDangerBg, text);
            btn.Font = FontBtnSecond;
            btn.FlatAppearance.MouseOverBackColor = SemanticDangerBg;
        }

        /// <summary>Ghost / Cancel - subtle, no fill.</summary>
        public static void StyleGhostBtn(Button btn, string text = null)
        {
            Apply(btn, BgSurface, TextSecondary, BorderDefault, text);
            btn.Font = FontBtnSecond;
            btn.FlatAppearance.MouseOverBackColor = BgCardHover;
            btn.MouseEnter += (s, e) => ((Button)s).ForeColor = TextPrimary;
            btn.MouseLeave += (s, e) => ((Button)s).ForeColor = TextSecondary;
        }

        /// <summary>Amber / Warning - Restock, Mark-paid.</summary>
        public static void StyleAmberBtn(Button btn, string text = null)
        {
            Apply(btn, SemanticWarningBg, SemanticAmber, SemanticWarningBg, text);
            btn.Font = FontBtnSecond;
            btn.FlatAppearance.MouseOverBackColor = SemanticWarningBg;
        }

        private static void Apply(Button btn, Color bg, Color fore, Color border, string text)
        {
            if (text != null) btn.Text = text;
            btn.BackColor = bg;
            btn.ForeColor = fore;
            btn.FlatStyle = FlatStyle.Flat;
            btn.Cursor = Cursors.Hand;
            btn.Height = 36;
            btn.FlatAppearance.BorderColor = border;
            btn.FlatAppearance.BorderSize = 1;
        }

        // ══════════════════════════════════════════════════════════════
        //  TEXTBOX STYLING
        // ══════════════════════════════════════════════════════════════

        public static void StyleInput(TextBox txt)
        {
            txt.BackColor = BgInput;
            txt.ForeColor = TextPrimary;
            txt.BorderStyle = BorderStyle.FixedSingle;
            txt.Font = FontInput;
            txt.Height = InputH;

            txt.GotFocus += (s, e) => ((TextBox)s).BackColor = BgCardHover;
            txt.LostFocus += (s, e) => ((TextBox)s).BackColor = BgInput;
        }

        public static void StyleComboBox(ComboBox cmb)
        {
            cmb.BackColor = BgInput;
            cmb.ForeColor = TextPrimary;
            cmb.FlatStyle = FlatStyle.Flat;
            cmb.Font = FontInput;
            cmb.DropDownStyle = ComboBoxStyle.DropDownList;
        }

        // ══════════════════════════════════════════════════════════════
        //  DATAGRIDVIEW STYLER
        // ══════════════════════════════════════════════════════════════

        /// <summary>
        /// Applies the full ClinicVets grid skin to a DataGridView.
        /// Call once after InitializeComponent(); row data population
        /// is unaffected.
        /// </summary>
        public static void StyleGrid(DataGridView dgv)
        {
            // Chrome
            dgv.BackgroundColor = BgSurface;
            dgv.BorderStyle = BorderStyle.None;
            dgv.CellBorderStyle = DataGridViewCellBorderStyle.None;
            dgv.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            dgv.EnableHeadersVisualStyles = false;
            dgv.GridColor = BorderSubtle;
            dgv.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgv.MultiSelect = false;
            dgv.ReadOnly = true;
            dgv.AllowUserToAddRows = false;
            dgv.AllowUserToDeleteRows = false;
            dgv.AllowUserToResizeRows = false;
            dgv.RowHeadersVisible = false;
            dgv.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgv.Font = FontGridCell;
            dgv.ColumnHeadersHeight = GridHdrH;
            dgv.RowTemplate.Height = GridRowH;
            dgv.ScrollBars = ScrollBars.Vertical;

            // Default cell style
            dgv.DefaultCellStyle = new DataGridViewCellStyle
            {
                BackColor = BgSurface,
                ForeColor = TextPrimary,
                SelectionBackColor = GridSelection,
                SelectionForeColor = TextPrimary,
                Padding = new Padding(SpaceMD, 0, SpaceSM, 0),
                WrapMode = DataGridViewTriState.False
            };

            // Header style
            dgv.ColumnHeadersDefaultCellStyle = new DataGridViewCellStyle
            {
                BackColor = BgCard,
                ForeColor = TextMuted,
                Font = FontGridHeader,
                Padding = new Padding(SpaceMD, 0, SpaceSM, 0),
                Alignment = DataGridViewContentAlignment.MiddleLeft,
                SelectionBackColor = BgCard,
                SelectionForeColor = TextMuted
            };

            // Alternating rows
            dgv.AlternatingRowsDefaultCellStyle = new DataGridViewCellStyle
            {
                BackColor = BgAltRow,
                SelectionBackColor = GridSelection
            };

            // Row paint: left accent stripe on selected row
            dgv.RowPrePaint += DgvRowPrePaint;
            dgv.CellPainting += DgvCellPainting;
        }

        private static void DgvRowPrePaint(object sender, DataGridViewRowPrePaintEventArgs e)
        {
            e.PaintParts &= ~DataGridViewPaintParts.Focus;
        }

        private static void DgvCellPainting(object sender, DataGridViewCellPaintingEventArgs e)
        {
            if (e.RowIndex < 0) return;
            var dgv = (DataGridView)sender;

            // Draw left accent stripe on selected row, first cell only
            if (e.ColumnIndex == 0 && dgv.Rows[e.RowIndex].Selected)
            {
                e.Paint(e.CellBounds, DataGridViewPaintParts.All);
                var brush = new SolidBrush(AccentGreen);
                e.Graphics.FillRectangle(brush,
                    e.CellBounds.Left, e.CellBounds.Top + 4,
                    3, e.CellBounds.Height - 8);
                e.Handled = true;
            }

            // Subtle bottom border on every cell
            if (e.RowIndex >= 0 && e.ColumnIndex >= 0 && !e.Handled)
            {
                e.Paint(e.CellBounds, DataGridViewPaintParts.All);
                var pen = new Pen(BorderSubtle, 1);
                e.Graphics.DrawLine(pen,
                    e.CellBounds.Left, e.CellBounds.Bottom - 1,
                    e.CellBounds.Right, e.CellBounds.Bottom - 1);
                e.Handled = true;
            }
        }

        // ══════════════════════════════════════════════════════════════
        //  STAT CARD FACTORY
        // ══════════════════════════════════════════════════════════════

        /// <summary>
        /// Creates a compact stat tile Panel with a coloured top-border accent,
        /// a label, and a large value label.
        /// Caller adds to parent container and positions it.
        /// </summary>
        public static Panel MakeStatCard(
            string label, string value, Color accent,
            int width = 170, int height = 62)
        {
            var p = new Panel
            {
                Size = new Size(width, height),
                BackColor = BgCard
            };

            // Top accent bar
            p.Paint += (s, e) =>
            {
                var accentBrush = new SolidBrush(accent);
                e.Graphics.FillRectangle(accentBrush, 0, 0, p.Width, 3);
                var borderPen = new Pen(BorderDefault, 1);
                e.Graphics.DrawRectangle(borderPen, 0, 0, p.Width - 1, p.Height - 1);
            };

            var lblLabel = new Label
            {
                Text = label.ToUpper(),
                Font = FontStatLabel,
                ForeColor = TextMuted,
                AutoSize = false,
                Size = new Size(width - 16, 16),
                Location = new Point(10, 10),
                BackColor = BgSurface
            };

            var lblValue = new Label
            {
                Text = value,
                Font = FontStat,
                ForeColor = accent,
                AutoSize = false,
                Size = new Size(width - 16, 32),
                Location = new Point(10, 26),
                BackColor = BgSurface,
                Tag = "stat_value"
            };

            p.Controls.AddRange(new Control[] { lblLabel, lblValue });
            return p;
        }

        /// <summary>Updates the value label inside a stat card created by MakeStatCard.</summary>
        public static void UpdateStatCard(Panel card, string value)
        {
            foreach (Control c in card.Controls)
                if (c.Tag?.ToString() == "stat_value") { c.Text = value; return; }
        }

        // ══════════════════════════════════════════════════════════════
        //  SECTION HEADER
        // ══════════════════════════════════════════════════════════════

        /// <summary>
        /// Returns a panel with a left-coloured accent strip and a section label.
        /// Width fills the parent; height is 34px.
        /// </summary>
        public static Panel MakeSectionHeader(string title, Color accent)
        {
            var p = new Panel
            {
                Height = 34,
                BackColor = BgCard,
                Dock = DockStyle.Top
            };
            p.Paint += (s, e) =>
            {
                var accentBrush = new SolidBrush(accent);
                e.Graphics.FillRectangle(accentBrush, 0, 0, 3, p.Height);
                var borderPen = new Pen(BorderDefault, 1);
                e.Graphics.DrawLine(borderPen, 0, p.Height - 1, p.Width, p.Height - 1);
            };
            p.Controls.Add(new Label
            {
                Text = title,
                Font = FontSectionHdr,
                ForeColor = TextPrimary,
                AutoSize = false,
                Size = new Size(500, 34),
                Location = new Point(14, 0),
                TextAlign = ContentAlignment.MiddleLeft,
                BackColor = BgSurface
            });
            return p;
        }

        // ══════════════════════════════════════════════════════════════
        //  BADGE / PILL FACTORY
        // ══════════════════════════════════════════════════════════════

        public enum BadgeStyle { Success, Warning, Danger, Info, Neutral }

        public static Label MakeBadge(string text, BadgeStyle style)
        {
            var (fg, bg) = style switch
            {
                BadgeStyle.Success => (SemanticSuccess, SemanticSuccessBg),
                BadgeStyle.Warning => (SemanticWarning, SemanticWarningBg),
                BadgeStyle.Danger => (SemanticDanger, SemanticDangerBg),
                BadgeStyle.Info => (AccentBlue, AccentBlueDim),
                _ => (TextSecondary, BgInput)
            };

            return new Label
            {
                Text = text,
                Font = FontBadge,
                ForeColor = fg,
                BackColor = bg,
                AutoSize = true,
                Padding = new Padding(6, 2, 6, 2),
                TextAlign = ContentAlignment.MiddleCenter
            };
        }

        // ══════════════════════════════════════════════════════════════
        //  TOOLBAR FACTORY
        // ══════════════════════════════════════════════════════════════

        /// <summary>
        /// Creates a styled toolbar Panel with:
        ///   - coloured left accent strip
        ///   - page title label
        ///   - right-docked FlowLayoutPanel for buttons
        /// Returns (toolbar, titleLabel, buttonsContainer).
        /// </summary>
        public static (Panel toolbar, Label title, FlowLayoutPanel btns)
            MakeToolbar(string pageTitle, Color accent)
        {
            var toolbar = new Panel
            {
                Dock = DockStyle.Top,
                Height = ToolbarH,
                BackColor = BgToolbar
            };
            toolbar.Paint += (s, e) =>
            {
                var accentBrush = new SolidBrush(accent);
                e.Graphics.FillRectangle(accentBrush, 0, ToolbarH - 2, toolbar.Width, 2);
                var borderPen = new Pen(BorderDefault, 1);
                e.Graphics.DrawLine(borderPen, 0, ToolbarH - 1, toolbar.Width, ToolbarH - 1);
            };

            // Left accent strip
            var strip = new Panel
            {
                Size = new Size(3, 28),
                Location = new Point(18, (ToolbarH - 28) / 2),
                BackColor = accent
            };

            var title = new Label
            {
                Text = pageTitle,
                Font = FontPageTitle,
                ForeColor = TextPrimary,
                AutoSize = false,
                Size = new Size(320, ToolbarH),
                Location = new Point(28, 0),
                TextAlign = ContentAlignment.MiddleLeft,
                BackColor = BgSurface
            };

            var btns = new FlowLayoutPanel
            {
                Dock = DockStyle.Right,
                Width = 500,
                Height = ToolbarH,
                BackColor = BgSurface,
                FlowDirection = FlowDirection.LeftToRight,
                Padding = new Padding(0, (ToolbarH - 36) / 2, SpaceMD, 0),
                WrapContents = false,
                AutoSize = false
            };

            toolbar.Controls.AddRange(new Control[] { strip, title, btns });
            return (toolbar, title, btns);
        }

        // ══════════════════════════════════════════════════════════════
        //  FIELD + ERROR LABEL PAIR
        // ══════════════════════════════════════════════════════════════

        /// <summary>
        /// Creates a labelled TextBox with an inline error label beneath it.
        /// Returns (fieldLabel, textBox, errorLabel).
        /// </summary>
        public static (Label lbl, TextBox txt, Label err) MakeInputField(
            string labelText, int x, int y, int width = 300)
        {
            var lbl = new Label
            {
                Text = labelText,
                Font = FontLabel,
                ForeColor = TextMuted,
                AutoSize = false,
                Size = new Size(width, 17),
                Location = new Point(x, y),
                BackColor = BgSurface
            };

            var txt = new TextBox
            {
                Size = new Size(width, InputH),
                Location = new Point(x, y + 19),
                Font = FontInput,
                BorderStyle = BorderStyle.FixedSingle,
                BackColor = BgInput,
                ForeColor = TextPrimary
            };

            // Focus glow
            txt.GotFocus += (s, e) => { txt.BackColor = BgCardHover; };
            txt.LostFocus += (s, e) => { txt.BackColor = BgInput; };

            var err = new Label
            {
                Text = string.Empty,
                Font = FontBodySmall,
                ForeColor = SemanticDanger,
                AutoSize = false,
                Size = new Size(width, 15),
                Location = new Point(x, y + 19 + InputH + 2),
                Visible = false,
                BackColor = BgSurface
            };

            return (lbl, txt, err);
        }

        // ══════════════════════════════════════════════════════════════
        //  SEARCH BAR FACTORY
        // ══════════════════════════════════════════════════════════════

        /// <summary>
        /// Creates a styled search bar panel.
        /// Returns (panel, searchInput, searchButton, clearButton, statusLabel).
        /// </summary>
        public static (Panel panel, TextBox input, Button search, Button clear, Label status)
            MakeSearchBar(string placeholder = "Search…")
        {
            var panel = new Panel
            {
                Dock = DockStyle.Top,
                Height = SearchBarH,
                BackColor = BgSurface
            };
            panel.Paint += (s, e) =>
            {
                var pen = new Pen(BorderDefault, 1);
                e.Graphics.DrawLine(pen, 0, SearchBarH - 1, panel.Width, SearchBarH - 1);
            };

            var iconLbl = new Label
            {
                Text = "🔍",
                Font = new Font("Segoe UI Emoji", 10f),
                AutoSize = false,
                Size = new Size(30, SearchBarH),
                Location = new Point(SpaceMD, 0),
                TextAlign = ContentAlignment.MiddleCenter,
                BackColor = BgSurface,
                ForeColor = TextMuted
            };

            var input = new TextBox
            {
                Size = new Size(280, InputH),
                Location = new Point(50, (SearchBarH - InputH) / 2),
                Font = FontInput,
                BorderStyle = BorderStyle.FixedSingle,
                BackColor = BgInput,
                ForeColor = TextPrimary,
            };

            var searchBtn = new Button
            {
                Text = "Search",
                Font = FontBtnPrimary,
                Size = new Size(88, InputH),
                Location = new Point(340, (SearchBarH - InputH) / 2),
                Height = InputH
            };
            StylePrimaryBtn(searchBtn);

            var clearBtn = new Button
            {
                Text = "Clear",
                Font = FontBtnSecond,
                Size = new Size(70, InputH),
                Location = new Point(436, (SearchBarH - InputH) / 2),
                Height = InputH
            };
            StyleGhostBtn(clearBtn);

            var status = new Label
            {
                Text = string.Empty,
                Font = new Font("Segoe UI", 8.5f, FontStyle.Italic),
                ForeColor = AccentGreen,
                AutoSize = false,
                Size = new Size(260, SearchBarH),
                Location = new Point(514, 0),
                TextAlign = ContentAlignment.MiddleLeft,
                BackColor = BgSurface
            };

            panel.Controls.AddRange(new Control[] { iconLbl, input, searchBtn, clearBtn, status });
            return (panel, input, searchBtn, clearBtn, status);
        }

        // ══════════════════════════════════════════════════════════════
        //  SIDEBAR FACTORY
        // ══════════════════════════════════════════════════════════════

        /// <summary>
        /// Styled navigation button for the sidebar.
        /// icon: emoji or short glyph. text: display name.
        /// accentColor: highlight when active.
        /// </summary>
        public static Button MakeNavButton(string icon, string text, Color accent)
        {
            var btn = new Button
            {
                Text = $"  {icon}   {text}",
                Font = new Font("Segoe UI", 10.5f),
                Size = new Size(220, 46),
                FlatStyle = FlatStyle.Flat,
                BackColor = BgSurface,
                ForeColor = TextSecondary,
                Cursor = Cursors.Hand,
                TextAlign = ContentAlignment.MiddleLeft,
                Padding = new Padding(SpaceMD, 0, 0, 0)
            };
            btn.FlatAppearance.BorderSize = 0;
            btn.FlatAppearance.MouseOverBackColor = BgCard;

            btn.MouseEnter += (s, e) => { if (!IsNavActive(btn)) btn.ForeColor = TextPrimary; };
            btn.MouseLeave += (s, e) => { if (!IsNavActive(btn)) btn.ForeColor = TextSecondary; };

            btn.Tag = new NavButtonState { Accent = accent, Active = false };
            return btn;
        }

        public static void SetNavActive(Button btn, bool active)
        {
            if (btn.Tag is NavButtonState state)
            {
                state.Active = active;
                btn.BackColor = active ? BgCard : BgSurface;
                btn.ForeColor = active ? TextPrimary : TextSecondary;
            }
        }

        private static bool IsNavActive(Button btn) =>
            btn.Tag is NavButtonState s && s.Active;

        public class NavButtonState
        {
            public Color Accent { get; set; }
            public bool Active { get; set; }
        }

        // ══════════════════════════════════════════════════════════════
        //  RESTOCK / QUICK-ACTION PANEL
        // ══════════════════════════════════════════════════════════════

        /// <summary>
        /// Creates the restock quick-action panel used in MedicineStockForm.
        /// Returns the Panel; caller adds Add/Set button handlers.
        /// </summary>
        public static Panel MakeRestockPanel(
            out TextBox qtyInput, out Button addBtn, out Button setBtn)
        {
            var panel = new Panel
            {
                Height = 90,
                BackColor = BgCard
            };
            panel.Paint += (s, e) =>
            {
                var accentBrush = new SolidBrush(SemanticAmber);
                e.Graphics.FillRectangle(accentBrush, 0, 0, 3, panel.Height);
                var borderPen = new Pen(BorderDefault, 1);
                e.Graphics.DrawRectangle(borderPen, 0, 0, panel.Width - 1, panel.Height - 1);
            };

            var title = new Label
            {
                Text = "⚡  Quick Restock",
                Font = FontSectionHdr,
                ForeColor = TextPrimary,
                AutoSize = false,
                Size = new Size(300, 24),
                Location = new Point(14, 10),
                BackColor = BgSurface
            };

            var lbl = new Label
            {
                Text = "Quantity:",
                Font = FontLabel,
                ForeColor = TextMuted,
                AutoSize = false,
                Size = new Size(70, InputH),
                Location = new Point(14, 42),
                TextAlign = ContentAlignment.MiddleLeft,
                BackColor = BgSurface
            };

            qtyInput = new TextBox
            {
                Size = new Size(90, InputH),
                Location = new Point(88, 42),
                Font = FontInput,
                BorderStyle = BorderStyle.FixedSingle,
                BackColor = BgInput,
                ForeColor = TextPrimary,
            };

            addBtn = new Button
            {
                Text = "＋ Add",
                Size = new Size(80, InputH),
                Location = new Point(186, 42),
                Height = InputH
            };
            StylePrimaryBtn(addBtn);

            setBtn = new Button
            {
                Text = "Set",
                Size = new Size(64, InputH),
                Location = new Point(274, 42),
                Height = InputH
            };
            StyleAmberBtn(setBtn);

            panel.Controls.AddRange(new Control[] { title, lbl, qtyInput, addBtn, setBtn });
            return panel;
        }

        // ══════════════════════════════════════════════════════════════
        //  FORM-LEVEL HELPERS
        // ══════════════════════════════════════════════════════════════

        /// <summary>Marks a TextBox as having a validation error.</summary>
        public static void MarkError(TextBox txt, Label errLabel, string message)
        {
            txt.BackColor = SemanticDangerBg;
            errLabel.Text = "⚠  " + message;
            errLabel.Visible = true;
        }

        /// <summary>Clears a validation error on a TextBox.</summary>
        public static void ClearError(TextBox txt, Label errLabel)
        {
            txt.BackColor = BgInput;
            errLabel.Visible = false;
            errLabel.Text = string.Empty;
        }

        /// <summary>
        /// Draws a rounded rectangle path - utility for custom-paint panels.
        /// </summary>
        public static GraphicsPath RoundedRect(Rectangle bounds, int radius)
        {
            int diameter = radius * 2;
            var path = new GraphicsPath();
            path.AddArc(bounds.X, bounds.Y, diameter, diameter, 180, 90);
            path.AddArc(bounds.Right - diameter, bounds.Y, diameter, diameter, 270, 90);
            path.AddArc(bounds.Right - diameter, bounds.Bottom - diameter, diameter, diameter, 0, 90);
            path.AddArc(bounds.X, bounds.Bottom - diameter, diameter, diameter, 90, 90);
            path.CloseFigure();
            return path;
        }

        // ══════════════════════════════════════════════════════════════
        //  WIN32 HELPERS
        // ══════════════════════════════════════════════════════════════

        [DllImport("Gdi32.dll")]
        public static extern IntPtr CreateRoundRectRgn(
            int nLeftRect, int nTopRect, int nRightRect, int nBottomRect,
            int nWidthEllipse, int nHeightEllipse);

        /// <summary>Enables dark-mode title bar on Windows 10/11 (optional cosmetic).</summary>
        public static void EnableDarkTitleBar(IntPtr hwnd)
        {
            try
            {
                const int DWMWA_USE_IMMERSIVE_DARK_MODE = 20;
                int value = 1;
                DwmSetWindowAttribute(hwnd, DWMWA_USE_IMMERSIVE_DARK_MODE,
                    ref value, sizeof(int));
            }
            catch { /* non-critical - silently skip on older Windows */ }
        }

        [DllImport("dwmapi.dll")]
        private static extern int DwmSetWindowAttribute(
            IntPtr hwnd, int attr, ref int attrValue, int attrSize);
    }
}