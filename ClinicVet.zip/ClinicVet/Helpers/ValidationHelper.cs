using System;
using System.Text.RegularExpressions;

namespace ClinicVets.Helpers
{
    /// <summary>
    /// Centralised validation rules per project specification.
    /// </summary>
    public static class ValidationHelper
    {
        // ── Username ──────────────────────────────────────────────────────────
        // 6-8 characters, maximum 2 digits, rest must be English letters (a-z A-Z)
        public static bool IsValidUsername(string username, out string error)
        {
            error = "";
            if (string.IsNullOrWhiteSpace(username))
            { error = "Username is required."; return false; }

            if (username.Length < 6 || username.Length > 8)
            { error = "Username must be 6-8 characters."; return false; }

            if (!Regex.IsMatch(username, @"^[a-zA-Z0-9]+$"))
            { error = "Username may only contain English letters and digits."; return false; }

            int digitCount = 0;
            foreach (char c in username)
                if (char.IsDigit(c)) digitCount++;

            if (digitCount > 2)
            { error = "Username may contain at most 2 digits."; return false; }

            int letterCount = username.Length - digitCount;
            if (letterCount < 1)
            { error = "Username must contain at least one letter."; return false; }

            return true;
        }

        // ── Password ──────────────────────────────────────────────────────────
        // 8-10 characters, at least 1 letter, 1 digit, 1 special char (! $ # ()
        public static bool IsValidPassword(string password, out string error)
        {
            error = "";
            if (string.IsNullOrWhiteSpace(password))
            { error = "Password is required."; return false; }

            if (password.Length < 8 || password.Length > 10)
            { error = "Password must be 8-10 characters."; return false; }

            if (!Regex.IsMatch(password, @"[a-zA-Z]"))
            { error = "Password must contain at least one letter."; return false; }

            if (!Regex.IsMatch(password, @"[0-9]"))
            { error = "Password must contain at least one digit."; return false; }

            if (!Regex.IsMatch(password, @"[!$#(]"))
            { error = "Password must contain at least one special character: ! $ # ("; return false; }

            return true;
        }

        // ── Employee Number ───────────────────────────────────────────────────
        // Exactly 4 digits
        public static bool IsValidEmployeeNumber(string empNum, out string error)
        {
            error = "";
            if (string.IsNullOrWhiteSpace(empNum))
            { error = "Employee number is required."; return false; }

            if (!Regex.IsMatch(empNum, @"^\d{4}$"))
            { error = "Employee number must be exactly 4 digits."; return false; }

            return true;
        }

        // ── Israeli ID Number (ת"ז) ───────────────────────────────────────────
        // 9 digits, valid Luhn checksum
        public static bool IsValidIdNumber(string id, out string error)
        {
            error = "";
            if (string.IsNullOrWhiteSpace(id))
            { error = "ID number is required."; return false; }

            id = id.Trim();

            if (!Regex.IsMatch(id, @"^\d{9}$"))
            { error = "ID number must be exactly 9 digits."; return false; }

            return true;
        }

        // ── Email ─────────────────────────────────────────────────────────────
        public static bool IsValidEmail(string email, out string error)
        {
            error = "";
            if (string.IsNullOrWhiteSpace(email))
            { error = "Email is required."; return false; }

            if (!Regex.IsMatch(email.Trim(),
                @"^[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}$"))
            { error = "Please enter a valid email address."; return false; }

            return true;
        }

        // ── Name (first / last) ───────────────────────────────────────────────
        public static bool IsValidName(string name, out string error)
        {
            error = "";
            if (string.IsNullOrWhiteSpace(name))
            { error = "This field is required."; return false; }

            if (!Regex.IsMatch(name.Trim(), @"^[\p{L}\s\-']+$"))
            { error = "Letters only."; return false; }

            return true;
        }
    }
}