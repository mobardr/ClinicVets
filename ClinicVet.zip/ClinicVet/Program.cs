﻿using System;
using System.Windows.Forms;
using ClinicVets.Data;

namespace ClinicVets
{
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            // ── Global exception handlers ─────────────────────────────────────
            Application.SetUnhandledExceptionMode(UnhandledExceptionMode.CatchException);
            Application.ThreadException += (s, e) =>
            {
                MessageBox.Show(
                    $"An unexpected error occurred:\n\n{e.Exception.Message}",
                    "ClinicVets — Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            };
            AppDomain.CurrentDomain.UnhandledException += (s, e) =>
            {
                MessageBox.Show(
                    $"A fatal error occurred:\n\n{e.ExceptionObject}",
                    "ClinicVets — Fatal Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            };

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // ── Initialise SQLite database ────────────────────────────────────
            try
            {
                _ = DatabaseHelper.Instance;
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    $"Failed to initialise the database:\n\n{ex.Message}\n\n" +
                    "The application cannot start.",
                    "ClinicVets — Startup Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                return;
            }

            // ── Launch the main landing page ──────────────────────────────────
            Application.Run(new Forms.MainPageForm());
        }
    }
}