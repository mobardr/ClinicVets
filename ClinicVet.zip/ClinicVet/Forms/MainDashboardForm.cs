using System;
using System.Drawing;
using System.Windows.Forms;
using ClinicVets.Models;
using ClinicVets.UI;

namespace ClinicVets.Forms
{
    /// <summary>
    /// Main application shell shown after login.
    /// Hosts the sidebar navigation and swaps UserControl panels into pnlContent.
    /// Role-based access is enforced per nav section.
    /// </summary>
    public partial class MainDashboardForm : Form
    {
        // ─────────────────────────────────────────────
        //  State
        // ─────────────────────────────────────────────
        private readonly Employee _currentEmployee;
        private Button _activeNavButton;

        // ─────────────────────────────────────────────
        //  Constructor
        // ─────────────────────────────────────────────
        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams cp = base.CreateParams;
                cp.ExStyle |= 0x02000000; // WS_EX_COMPOSITED
                return cp;
            }
        }

        public MainDashboardForm(Employee employee)
        {
            _currentEmployee = employee
                ?? throw new ArgumentNullException(nameof(employee));

            InitializeComponent();
            WireEvents();
        }

        // ─────────────────────────────────────────────
        //  Event wiring
        // ─────────────────────────────────────────────
        private void WireEvents()
        {
            this.Load += MainDashboardForm_Load;
            btnNavCustomers.Click += BtnNavCustomers_Click;
            btnNavAnimals.Click += BtnNavAnimals_Click;
            btnNavVisits.Click += BtnNavVisits_Click;
            btnNavMedicines.Click += BtnNavMedicines_Click;
            btnNavAnimalTypes.Click += BtnNavAnimalTypes_Click;
            btnLogout.Click += BtnLogout_Click;
        }

        // ─────────────────────────────────────────────
        //  Form Load
        // ─────────────────────────────────────────────
        private void MainDashboardForm_Load(object sender, EventArgs e)
        {
            ApplyEmployeeInfo();
            ApplyRoleRestrictions();
            ShowWelcomePage();
        }

        // ─────────────────────────────────────────────
        //  Employee info
        // ─────────────────────────────────────────────
        private void ApplyEmployeeInfo()
        {
            lblEmpName.Text = _currentEmployee.FullName;
            lblEmpRole.Text = _currentEmployee.Role;

            lblEmpRole.ForeColor = _currentEmployee.Role == "Veterinarian"
                ? UITheme.Accent
                : UITheme.SemanticWarning;

            // Repaint avatar circle with initials
            pnlAvatar.Invalidate();
        }

        // ─────────────────────────────────────────────
        //  Role-based access
        // ─────────────────────────────────────────────
        private void ApplyRoleRestrictions()
        {
            bool isVet = _currentEmployee.Role == "Veterinarian";
            bool isSecretary = _currentEmployee.Role == "Secretary";

            // Customers - visible to all, but Secretary-only for add/edit/delete
            // (restriction enforced inside CustomerForm)
            SetNavAccess(btnNavCustomers, true);

            // Animals - all staff can view and manage
            SetNavAccess(btnNavAnimals, true);

            // Visits - Veterinarian only
            SetNavAccess(btnNavVisits, isVet,
                "Visit management is for Veterinarians only.");

            // Medicines - all staff can view
            SetNavAccess(btnNavMedicines, true);

            // Animal Types - all staff
            SetNavAccess(btnNavAnimalTypes, true);
        }

        private void SetNavAccess(Button btn, bool allowed, string tooltip = "")
        {
            btn.Enabled = allowed;
            btn.Cursor = allowed ? Cursors.Hand : Cursors.No;

            if (!allowed && !string.IsNullOrEmpty(tooltip))
            {
                new ToolTip().SetToolTip(btn, tooltip);
                btn.ForeColor = UITheme.TextMuted;
            }
        }

        // ─────────────────────────────────────────────
        //  Navigation click handlers
        // ─────────────────────────────────────────────
        private void BtnNavCustomers_Click(object sender, EventArgs e)
        {
            SetActiveNav(btnNavCustomers);
            lblPageTitle.Text = "Customers";
            SafeLoadContent(() => new CustomerForm(_currentEmployee));
        }

        private void BtnNavAnimals_Click(object sender, EventArgs e)
        {
            SetActiveNav(btnNavAnimals);
            lblPageTitle.Text = "Animals";
            SafeLoadContent(() => new AnimalForm(_currentEmployee));
        }

        private void BtnNavVisits_Click(object sender, EventArgs e)
        {
            SetActiveNav(btnNavVisits);
            lblPageTitle.Text = "Visits";
            SafeLoadContent(() => new VisitForm(_currentEmployee));
        }

        private void BtnNavMedicines_Click(object sender, EventArgs e)
        {
            if (!btnNavMedicines.Enabled) return;
            SetActiveNav(btnNavMedicines);
            lblPageTitle.Text = "Medicine Stock";
            SafeLoadContent(() => new MedicineStockForm());
        }

        private void BtnNavAnimalTypes_Click(object sender, EventArgs e)
        {
            SetActiveNav(btnNavAnimalTypes);
            lblPageTitle.Text = "Animal Types";
            SafeLoadContent(() => new AnimalTypesForm());
        }

        private void BtnLogout_Click(object sender, EventArgs e)
        {
            var r = MessageBox.Show(
                $"Sign out of ClinicVets, {_currentEmployee.FirstName}?",
                "Confirm Sign Out",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question,
                MessageBoxDefaultButton.Button2);

            if (r == DialogResult.Yes)
                Application.Restart();
        }

        // ─────────────────────────────────────────────
        //  Active nav highlight
        // ─────────────────────────────────────────────
        private void SetActiveNav(Button clicked)
        {
            // Reset previous active
            if (_activeNavButton != null)
            {
                _activeNavButton.BackColor = UITheme.BgSurface;
                _activeNavButton.ForeColor = UITheme.TextSecondary;
                _activeNavButton.Font = new Font("Segoe UI", 9.5f);
                _activeNavButton.Tag = null;
            }
            // Highlight new active
            clicked.BackColor = UITheme.BgCard;
            clicked.ForeColor = UITheme.TextPrimary;
            clicked.Font = new Font("Segoe UI", 9.5f, FontStyle.Bold);
            clicked.Tag = "active";
            _activeNavButton = clicked;
        }

        private void SetNavIndicator(Button btn, bool active) { /* replaced by SetActiveNav */ }

        // ─────────────────────────────────────────────
        //  Content area swap - safe version
        // ─────────────────────────────────────────────
        private void SafeLoadContent(Func<UserControl> factory)
        {
            UserControl uc = null;
            try
            {
                // Construct the UserControl inside try - catches InitializeComponent errors
                uc = factory();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    $"Failed to create panel:\n\n{ex.Message}\n\n{ex.InnerException?.Message}",
                    "Navigation Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                return;
            }

            LoadContent(uc);
        }

        private void LoadContent(UserControl uc)
        {
            try
            {
                pnlContent.SuspendLayout();
                pnlContent.Controls.Clear();
                uc.Dock = DockStyle.Fill;
                pnlContent.Controls.Add(uc);
                pnlContent.ResumeLayout();
            }
            catch (Exception ex)
            {
                pnlContent.ResumeLayout();
                MessageBox.Show(
                    $"Failed to load panel:\n\n{ex.Message}\n\n{ex.InnerException?.Message}",
                    "Navigation Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        // ─────────────────────────────────────────────
        //  Welcome dashboard
        // ─────────────────────────────────────────────
        private void ShowWelcomePage()
        {
            lblPageTitle.Text = "Dashboard";

            UserControl welcome = new UserControl();
            welcome.Dock = DockStyle.Fill;
            welcome.BackColor = UITheme.BgRoot;

            // Greeting bar
            Panel pnlGreetRow = new Panel();
            pnlGreetRow.Dock = DockStyle.Top;
            pnlGreetRow.Height = 80;
            pnlGreetRow.BackColor = UITheme.BgSurface;

            Panel pnlGreetAccent = new Panel();
            pnlGreetAccent.Size = new Size(4, 80);
            pnlGreetAccent.Location = new Point(0, 0);
            pnlGreetAccent.BackColor = UITheme.Accent;

            Label lblPaw = new Label();
            lblPaw.Text = "🐾";
            lblPaw.Font = new Font("Segoe UI Emoji", 22f);
            lblPaw.AutoSize = false;
            lblPaw.Size = new Size(52, 80);
            lblPaw.Location = new Point(14, 0);
            lblPaw.TextAlign = ContentAlignment.MiddleCenter;
            lblPaw.BackColor = UITheme.BgSurface;

            string hour = DateTime.Now.Hour < 12 ? "Good morning"
                        : DateTime.Now.Hour < 17 ? "Good afternoon"
                        : "Good evening";

            Label lblGreet = new Label();
            lblGreet.Text = hour + ", " + _currentEmployee.FirstName;
            lblGreet.Font = UITheme.FontTitle;
            lblGreet.ForeColor = UITheme.TextPrimary;
            lblGreet.AutoSize = false;
            lblGreet.Size = new Size(800, 44);
            lblGreet.Location = new Point(74, 6);
            lblGreet.BackColor = UITheme.BgSurface;

            Label lblSub = new Label();
            lblSub.Text = "Signed in as " + _currentEmployee.Role + "  •  Select a section to get started";
            lblSub.Font = UITheme.FontBody;
            lblSub.ForeColor = UITheme.TextMuted;
            lblSub.AutoSize = false;
            lblSub.Size = new Size(800, 20);
            lblSub.Location = new Point(74, 52);
            lblSub.BackColor = UITheme.BgSurface;

            Label _lblGreetRef = lblGreet;
            Label _lblSubRef = lblSub;
            pnlGreetRow.Resize += delegate (object s, EventArgs e)
            {
                int w = Math.Max(300, pnlGreetRow.Width - 100);
                _lblGreetRef.Width = w;
                _lblSubRef.Width = w;
            };

            pnlGreetRow.Controls.Add(pnlGreetAccent);
            pnlGreetRow.Controls.Add(lblPaw);
            pnlGreetRow.Controls.Add(lblGreet);
            pnlGreetRow.Controls.Add(lblSub);

            // Scroll area
            Panel pnlScroll = new Panel();
            pnlScroll.Dock = DockStyle.Fill;
            pnlScroll.BackColor = UITheme.BgRoot;
            pnlScroll.AutoScroll = true;

            // Cards
            string[] icons = { "👤", "🐾", "📋", "💊" };
            string[] titles = { "Customers", "Animals", "Visits", "Medicines" };
            string[] descs = { "Manage pet owners & contacts", "Patient records & health data", "Appointments, diagnoses & notes", "Inventory, pricing & stock" };
            Color[] accents = { UITheme.Accent, UITheme.SemanticSuccess, UITheme.SemanticWarning, UITheme.AccentCyan };
            Button[] navBtns = { btnNavCustomers, btnNavAnimals, btnNavVisits, btnNavMedicines };

            Panel pnlCardRow = new Panel();
            pnlCardRow.BackColor = UITheme.BgRoot;
            pnlCardRow.Height = 204;
            pnlCardRow.Dock = DockStyle.Top;

            Panel[] cardControls = new Panel[4];
            for (int i = 0; i < 4; i++)
            {
                Panel card = new Panel();
                card.BackColor = UITheme.BgCard;
                card.Cursor = Cursors.Hand;

                Color ac = accents[i];
                Button nav = navBtns[i];
                Color normalBg = UITheme.BgCard;
                Color hoverBg = UITheme.BgCardHover;

                Panel bar = new Panel();
                bar.Size = new Size(200, 3);
                bar.Location = new Point(0, 0);
                bar.BackColor = ac;

                Label lIcon = new Label();
                lIcon.Text = icons[i];
                lIcon.Font = new Font("Segoe UI Emoji", 24f);
                lIcon.AutoSize = false;
                lIcon.Dock = DockStyle.Top;
                lIcon.Height = 64;
                lIcon.TextAlign = ContentAlignment.MiddleCenter;
                lIcon.BackColor = normalBg;

                Label lTitle = new Label();
                lTitle.Text = titles[i];
                lTitle.Font = new Font("Segoe UI", 11f, FontStyle.Bold);
                lTitle.ForeColor = UITheme.TextPrimary;
                lTitle.AutoSize = false;
                lTitle.Dock = DockStyle.Top;
                lTitle.Height = 26;
                lTitle.TextAlign = ContentAlignment.MiddleCenter;
                lTitle.BackColor = normalBg;

                Label lDesc = new Label();
                lDesc.Text = descs[i];
                lDesc.Font = new Font("Segoe UI", 8f);
                lDesc.ForeColor = UITheme.TextMuted;
                lDesc.AutoSize = false;
                lDesc.Dock = DockStyle.Fill;
                lDesc.TextAlign = ContentAlignment.TopCenter;
                lDesc.BackColor = normalBg;
                lDesc.Padding = new Padding(4, 4, 4, 0);

                Panel _card = card;
                Panel _bar = bar;
                Label _lIcon = lIcon; Label _lTitle = lTitle; Label _lDesc = lDesc;
                Color _ac = ac; Color _n = normalBg; Color _h = hoverBg;
                Button _nav = nav;

                _card.MouseEnter += delegate { _card.BackColor = _h; _lIcon.BackColor = _h; _lTitle.BackColor = _h; _lDesc.BackColor = _h; _bar.BackColor = _ac; };
                _card.MouseLeave += delegate { _card.BackColor = _n; _lIcon.BackColor = _n; _lTitle.BackColor = _n; _lDesc.BackColor = _n; _bar.BackColor = _ac; };
                _card.Click += delegate { _nav.PerformClick(); };
                _lIcon.MouseEnter += delegate { _card.BackColor = _h; _lIcon.BackColor = _h; _lTitle.BackColor = _h; _lDesc.BackColor = _h; };
                _lIcon.MouseLeave += delegate { _card.BackColor = _n; _lIcon.BackColor = _n; _lTitle.BackColor = _n; _lDesc.BackColor = _n; };
                _lIcon.Click += delegate { _nav.PerformClick(); };
                _lTitle.MouseEnter += delegate { _card.BackColor = _h; _lIcon.BackColor = _h; _lTitle.BackColor = _h; _lDesc.BackColor = _h; };
                _lTitle.MouseLeave += delegate { _card.BackColor = _n; _lIcon.BackColor = _n; _lTitle.BackColor = _n; _lDesc.BackColor = _n; };
                _lTitle.Click += delegate { _nav.PerformClick(); };
                _lDesc.MouseEnter += delegate { _card.BackColor = _h; _lIcon.BackColor = _h; _lTitle.BackColor = _h; _lDesc.BackColor = _h; };
                _lDesc.MouseLeave += delegate { _card.BackColor = _n; _lIcon.BackColor = _n; _lTitle.BackColor = _n; _lDesc.BackColor = _n; };
                _lDesc.Click += delegate { _nav.PerformClick(); };

                Panel _barRef = bar;
                _card.Resize += delegate { _barRef.Width = _card.Width; };

                card.Controls.Add(lDesc);
                card.Controls.Add(lTitle);
                card.Controls.Add(lIcon);
                card.Controls.Add(bar);
                cardControls[i] = card;
            }

            Panel _pnlCardRow = pnlCardRow;
            Panel[] _cardControls = cardControls;
            EventHandler layCards = null;
            layCards = delegate (object s, EventArgs e)
            {
                if (_pnlCardRow.Width < 1) return;
                int pad = UITheme.SpaceLG;
                int gap = UITheme.SpaceMD;
                int avail = _pnlCardRow.Width - pad * 2 - gap * 3;
                int w = Math.Max(160, avail / 4);
                int h = 156;
                _pnlCardRow.Height = h + pad * 2;
                for (int i = 0; i < 4; i++)
                {
                    _cardControls[i].Size = new Size(w, h);
                    _cardControls[i].Location = new Point(pad + i * (w + gap), pad);
                    if (!_pnlCardRow.Controls.Contains(_cardControls[i]))
                        _pnlCardRow.Controls.Add(_cardControls[i]);
                }
            };
            pnlCardRow.Resize += layCards;

            // Stats row
            string[] statLabels = { "Total Customers", "Total Animals", "Today's Visits", "Medicines" };
            string[] statVals = { "-", "-", "-", "-" };
            Color[] statColors = { UITheme.Accent, UITheme.SemanticSuccess, UITheme.SemanticWarning, UITheme.AccentCyan };

            Panel pnlStatRow = new Panel();
            pnlStatRow.Dock = DockStyle.Top;
            pnlStatRow.Height = 72;
            pnlStatRow.BackColor = UITheme.BgRoot;

            Panel[] statPanels = new Panel[4];
            for (int i = 0; i < 4; i++)
            {
                Color c2 = statColors[i];
                Panel stat = new Panel();
                stat.BackColor = UITheme.BgCard;

                Panel dot = new Panel();
                dot.Size = new Size(3, 56);
                dot.Location = new Point(0, 0);
                dot.BackColor = c2;

                Label lv = new Label();
                lv.Text = statLabels[i];
                lv.Font = new Font("Segoe UI", 8f);
                lv.ForeColor = UITheme.TextMuted;
                lv.AutoSize = false;
                lv.Size = new Size(180, 20);
                lv.Location = new Point(12, 8);
                lv.BackColor = UITheme.BgCard;

                Label lk = new Label();
                lk.Text = statVals[i];
                lk.Font = new Font("Segoe UI", 14f, FontStyle.Bold);
                lk.ForeColor = c2;
                lk.AutoSize = false;
                lk.Size = new Size(180, 28);
                lk.Location = new Point(12, 28);
                lk.BackColor = UITheme.BgCard;

                Label _lv = lv; Label _lk = lk;
                stat.Resize += delegate (object s, EventArgs e)
                {
                    _lv.Width = Math.Max(60, stat.Width - 20);
                    _lk.Width = _lv.Width;
                };

                stat.Controls.Add(dot);
                stat.Controls.Add(lv);
                stat.Controls.Add(lk);
                statPanels[i] = stat;
            }

            Panel _pnlStatRow = pnlStatRow;
            Panel[] _statPanels = statPanels;
            EventHandler layStats = null;
            layStats = delegate (object s, EventArgs e)
            {
                if (_pnlStatRow.Width < 1) return;
                int pad = UITheme.SpaceLG;
                int gap = UITheme.SpaceMD;
                int avail = _pnlStatRow.Width - pad * 2 - gap * 3;
                int w = Math.Max(100, avail / 4);
                int h = 56;
                _pnlStatRow.Height = h + UITheme.SpaceMD * 2;
                for (int i = 0; i < 4; i++)
                {
                    _statPanels[i].Size = new Size(w, h);
                    _statPanels[i].Location = new Point(pad + i * (w + gap), UITheme.SpaceMD);
                    if (!_pnlStatRow.Controls.Contains(_statPanels[i]))
                        _pnlStatRow.Controls.Add(_statPanels[i]);
                }
            };
            pnlStatRow.Resize += layStats;

            // Hint
            Panel pnlHint = new Panel();
            pnlHint.Dock = DockStyle.Top;
            pnlHint.Height = 36;
            pnlHint.BackColor = UITheme.BgRoot;

            Label lblHint = new Label();
            lblHint.Text = "Click any card or use the sidebar to navigate";
            lblHint.Font = new Font("Segoe UI", 8.5f);
            lblHint.ForeColor = UITheme.TextDisabled;
            lblHint.Dock = DockStyle.Fill;
            lblHint.TextAlign = ContentAlignment.MiddleCenter;
            lblHint.BackColor = UITheme.BgRoot;
            pnlHint.Controls.Add(lblHint);

            pnlScroll.Controls.Add(pnlHint);
            pnlScroll.Controls.Add(pnlStatRow);
            pnlScroll.Controls.Add(pnlCardRow);

            welcome.Controls.Add(pnlScroll);
            welcome.Controls.Add(pnlGreetRow);

            Panel _cr = pnlCardRow; Panel _sr = pnlStatRow;
            welcome.HandleCreated += delegate (object s, EventArgs e)
            {
                _cr.PerformLayout();
                _sr.PerformLayout();
            };

            LoadContent(welcome);
        }
    }
}