using System;
using System.Data;
using System.Data.SQLite;
using System.Drawing;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using ClinicVets.Data;
using ClinicVets.Models;

namespace ClinicVets.Forms
{
    /// <summary>
    /// MainPageForm - single-window application shell.
    ///
    /// Three views, all inside the same window:
    ///   pnlWelcome    - landing / hero card  (default)
    ///   pnlAuthLogin  - sign-in form
    ///   pnlAuthReg    - register form
    ///
    /// No second window ever opens.
    /// </summary>
    public partial class MainPageForm : Form
    {
        // ─────────────────────────────────────────────
        //  View enum
        // ─────────────────────────────────────────────
        private enum View { Welcome, Login, Register }

        // ─────────────────────────────────────────────
        //  State
        // ─────────────────────────────────────────────
        private bool _loginPasswordVisible = false;
        private bool _regPasswordVisible = false;
        private bool _regConfirmVisible = false;
        private int _failedAttempts = 0;
        private const int MaxAttempts = 5;

        // ─────────────────────────────────────────────
        //  WS_EX_COMPOSITED - eliminates startup and
        //  panel-swap flicker at the Windows GDI level.
        //  All child controls are painted into an
        //  off-screen buffer first, then blitted at once.
        // ─────────────────────────────────────────────
        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams cp = base.CreateParams;
                cp.ExStyle |= 0x02000000;  // WS_EX_COMPOSITED
                return cp;
            }
        }

        // ─────────────────────────────────────────────
        //  Constructor
        // ─────────────────────────────────────────────
        public MainPageForm()
        {
            InitializeComponent();
            WireEvents();
        }

        // ─────────────────────────────────────────────
        //  Event wiring
        // ─────────────────────────────────────────────
        private void WireEvents()
        {
            this.Load += (s, e) =>
            {
                this.SuspendLayout();
                pnlWelcome.Visible = true;
                pnlAuthLogin.Visible = false;
                pnlAuthReg.Visible = false;
                pnlNavRight.Visible = true;
                this.ResumeLayout(true);
                CentreAuthCard();
                this.Invalidate();
            };

            // Navbar buttons
            btnSignIn.Click += (s, e) => ShowView(View.Login);
            btnRegister.Click += (s, e) => ShowView(View.Register);

            // Login panel
            btnDoLogin.Click += BtnDoLogin_Click;
            btnEyeLogin.Click += (s, e) => ToggleEye(txtLoginPw, ref _loginPasswordVisible, btnEyeLogin);
            lnkGoRegister.Click += (s, e) => ShowView(View.Register);
            lnkBackFromLogin.Click += (s, e) => ShowView(View.Welcome);
            txtLoginEmail.KeyDown += AuthKeyDown;
            txtLoginPw.KeyDown += AuthKeyDown;

            // Register panel
            btnDoRegister.Click += BtnDoRegister_Click;
            btnEyeRegPw.Click += (s, e) => ToggleEye(txtRegPw, ref _regPasswordVisible, btnEyeRegPw);
            btnEyeRegConfirm.Click += (s, e) => ToggleEye(txtRegConfirm, ref _regConfirmVisible, btnEyeRegConfirm);
            lnkGoLogin.Click += (s, e) => ShowView(View.Login);
            lnkBackFromReg.Click += (s, e) => ShowView(View.Welcome);
        }

        // ═════════════════════════════════════════════
        //  VIEW SWITCHING - flicker-free alpha blend
        //
        //  Strategy:
        //   • Capture outgoing snapshot BEFORE any panel changes.
        // ═════════════════════════════════════════════
        //  VIEW SWITCHING - instant swap
        // ═════════════════════════════════════════════
        private View _currentView = View.Welcome;

        private void ShowView(View v)
        {
            this.SuspendLayout();

            pnlNavRight.Visible = v == View.Welcome;
            pnlWelcome.Visible = v == View.Welcome;
            pnlAuthLogin.Visible = v == View.Login;
            pnlAuthReg.Visible = v == View.Register;

            _currentView = v;

            // Centre cards while layout is suspended - position is correct
            // before the first pixel is painted
            CentreAuthCard();

            this.ResumeLayout(true);

            if (v == View.Login) { ClearLoginErrors(); txtLoginEmail.Focus(); }
            if (v == View.Register) { ClearRegErrors(); txtRegFirstName.Focus(); }
        }

        // ═════════════════════════════════════════════
        //  SIGN IN LOGIC
        // ═════════════════════════════════════════════
        private void AuthKeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter) { e.SuppressKeyPress = true; BtnDoLogin_Click(sender, e); }
        }

        private void BtnDoLogin_Click(object sender, EventArgs e)
        {
            if (_failedAttempts >= MaxAttempts)
            { ShowLoginError("Account locked - too many failed attempts."); return; }

            string email = txtLoginEmail.Text.Trim();  // now username
            string pw = txtLoginPw.Text;

            if (string.IsNullOrWhiteSpace(email))
            { ShowLoginError("Please enter your username."); txtLoginEmail.Focus(); return; }
            if (string.IsNullOrWhiteSpace(pw))
            { ShowLoginError("Please enter your password."); txtLoginPw.Focus(); return; }
            // Username validation - no @ check needed

            btnDoLogin.Enabled = false;
            btnDoLogin.Text = "Verifying…";

            try
            {
                var emp = VerifyCredentials(email, pw);
                if (emp != null)
                {
                    _failedAttempts = 0;
                    var dash = new MainDashboardForm(emp);
                    this.Hide();
                    dash.FormClosed += (s2, e2) => this.Close();
                    dash.Show();
                }
                else
                {
                    _failedAttempts++;
                    int left = MaxAttempts - _failedAttempts;
                    ShowLoginError(left > 0
                        ? $"Invalid email or password. {left} attempt{(left == 1 ? "" : "s")} remaining."
                        : "Account locked - too many failed attempts.");
                    txtLoginPw.Clear();
                    txtLoginPw.Focus();
                }
            }
            catch (Exception ex)
            {
                ShowLoginError($"Database error: {ex.Message}");
            }
            finally
            {
                btnDoLogin.Enabled = true;
                btnDoLogin.Text = "Sign In";
            }
        }

        private Employee VerifyCredentials(string email, string password)
        {
            string hash = HashSha256(password);
            const string sql = @"
                SELECT EmployeeId, Username, FirstName, LastName, Role, Phone, Email,
                       EmployeeNumber, IdNumber,
                       HireDate, IsActive, CreatedAt, UpdatedAt
                FROM   Employees
                WHERE  LOWER(Username) = LOWER(@Email)
                  AND  PasswordHash = @Hash
                  AND  IsActive     = 1 LIMIT 1;";

            DataTable dt = DatabaseHelper.Instance.ExecuteQuery(sql,
                new SQLiteParameter("@Email", email),  // holds username
                new SQLiteParameter("@Hash", hash));

            if (dt.Rows.Count == 0) return null;
            var r = dt.Rows[0];
            return new Employee
            {
                EmployeeId = Convert.ToInt32(r["EmployeeId"]),
                Username = r["Username"].ToString(),
                FirstName = r["FirstName"].ToString(),
                LastName = r["LastName"].ToString(),
                Role = r["Role"].ToString(),
                Phone = r["Phone"].ToString(),
                Email = r["Email"].ToString(),
                EmployeeNumber = r["EmployeeNumber"].ToString(),
                IdNumber = r["IdNumber"].ToString(),
                HireDate = DateTime.Parse(r["HireDate"].ToString()),
                IsActive = Convert.ToBoolean(r["IsActive"]),
                CreatedAt = DateTime.Parse(r["CreatedAt"].ToString()),
                UpdatedAt = DateTime.Parse(r["UpdatedAt"].ToString())
            };
        }

        private void ShowLoginError(string msg)
        {
            lblLoginError.Text = "⚠  " + msg;
            lblLoginError.Visible = true;
        }
        private void ClearLoginErrors() { lblLoginError.Visible = false; }

        // ═════════════════════════════════════════════
        //  REGISTER LOGIC
        // ═════════════════════════════════════════════
        private void BtnDoRegister_Click(object sender, EventArgs e)
        {
            if (!ValidateRegister()) return;

            try
            {
                const string sql = @"
                    INSERT INTO Employees
                        (Username,FirstName,LastName,Role,Phone,Email,
                         EmployeeNumber,IdNumber,HireDate,IsActive,PasswordHash)
                    VALUES (@User,@FN,@LN,@Role,@Phone,@Email,
                            @EmpNum,@IdNum,DATE('now'),1,@Hash);";

                DatabaseHelper.Instance.ExecuteNonQuery(sql,
                    new SQLiteParameter("@User", txtRegUsername.Text.Trim()),
                    new SQLiteParameter("@FN", txtRegFirstName.Text.Trim()),
                    new SQLiteParameter("@LN", txtRegLastName.Text.Trim()),
                    new SQLiteParameter("@Role", cmbRegRole.SelectedItem.ToString()),
                    new SQLiteParameter("@Phone", txtRegPhone.Text.Trim()),
                    new SQLiteParameter("@Email", txtRegEmail.Text.Trim()),
                    new SQLiteParameter("@EmpNum", txtRegEmpNum.Text.Trim()),
                    new SQLiteParameter("@IdNum", txtRegIdNumber.Text.Trim()),
                    new SQLiteParameter("@Hash", HashSha256(txtRegPw.Text)));

                MessageBox.Show(
                    $"Account created for {txtRegFirstName.Text.Trim()} {txtRegLastName.Text.Trim()}.\n\nYou can now sign in.",
                    "Registration Successful", MessageBoxButtons.OK, MessageBoxIcon.Information);

                // Pre-fill email and switch to login
                txtLoginEmail.Text = txtRegUsername.Text.Trim();
                txtLoginPw.Clear();
                ShowView(View.Login);
            }
            catch (SQLiteException ex) when (ex.Message.Contains("UNIQUE"))
            {
                ShowRegError(lblErrRegEmail, "An account with this email already exists.");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Registration failed:\n\n{ex.Message}",
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private bool ValidateRegister()
        {
            ClearRegErrors();
            bool ok = true;

            if (string.IsNullOrWhiteSpace(txtRegFirstName.Text))
            { ShowRegError(lblErrRegFN, "Required."); ok = false; }
            else if (!Regex.IsMatch(txtRegFirstName.Text.Trim(), @"^[\p{L}\s\-']+$"))
            { ShowRegError(lblErrRegFN, "Letters only."); ok = false; }

            if (string.IsNullOrWhiteSpace(txtRegLastName.Text))
            { ShowRegError(lblErrRegLN, "Required."); ok = false; }

            if (cmbRegRole.SelectedIndex < 0)
            { ShowRegError(lblErrRegRole, "Please select a role."); ok = false; }

            string em = txtRegEmail.Text.Trim();
            if (string.IsNullOrWhiteSpace(em))
            { ShowRegError(lblErrRegEmail, "Required."); ok = false; }
            else if (!Regex.IsMatch(em, @"^[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}$"))
            { ShowRegError(lblErrRegEmail, "Invalid email format."); ok = false; }

            string pw = txtRegPw.Text;
            if (string.IsNullOrEmpty(pw))
            { ShowRegError(lblErrRegPw, "Required."); ok = false; }
            else if (pw.Length < 8 || pw.Length > 10)
            { ShowRegError(lblErrRegPw, "8-10 characters required."); ok = false; }
            else if (!Regex.IsMatch(pw, @"[a-zA-Z]"))
            { ShowRegError(lblErrRegPw, "Must contain a letter."); ok = false; }
            else if (!Regex.IsMatch(pw, @"[0-9]"))
            { ShowRegError(lblErrRegPw, "Must contain a digit."); ok = false; }
            else if (!Regex.IsMatch(pw, @"[!@#$%^&*()\-_=+\[\]{};:',.<>?/\\|`~""]"))
            { ShowRegError(lblErrRegPw, "Must contain a special character."); ok = false; }

            if (txtRegConfirm.Text != txtRegPw.Text)
            { ShowRegError(lblErrRegConfirm, "Passwords do not match."); ok = false; }

            if (!ok)
                MessageBox.Show("Please fix the highlighted fields.",
                    "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);

            return ok;
        }

        private void ShowRegError(Label lbl, string msg)
        { lbl.Text = "⚠ " + msg; lbl.Visible = true; }

        private void ClearRegErrors()
        {
            foreach (var l in new[] { lblErrRegFN, lblErrRegLN,
                                      lblErrRegUsername, lblErrRegEmpNum, lblErrRegIdNumber,
                                      lblErrRegEmail, lblErrRegPw, lblErrRegConfirm, lblErrRegRole })
            { l.Text = ""; l.Visible = false; }
        }

        // ─────────────────────────────────────────────
        //  Helpers
        // ─────────────────────────────────────────────
        private static void ToggleEye(TextBox txt, ref bool visible, Button btn)
        {
            visible = !visible;
            txt.UseSystemPasswordChar = !visible;
            btn.Text = visible ? "🙈" : "👁";
        }

        private static string HashSha256(string input)
        {
            var sha = SHA256.Create();
            var bytes = sha.ComputeHash(Encoding.UTF8.GetBytes(input));
            var sb = new StringBuilder();
            foreach (var b in bytes) sb.Append(b.ToString("x2"));
            return sb.ToString();
        }
    }
}