using System;
using System.Data;
using System.Data.SQLite;
using System.Windows.Forms;
using System.Drawing;
using ClinicVets.Data;
using ClinicVets.Models;
using ClinicVets.UI;

namespace ClinicVets.Forms
{
    /// <summary>
    /// VisitForm - records a clinic visit for an animal.
    /// Handles medicine selection, quantity, price calculation,
    /// vaccine overdue warnings, and SQLite persistence.
    /// Embedded as a UserControl inside MainDashboardForm.
    /// </summary>
    public partial class VisitForm : UserControl
    {
        // ─────────────────────────────────────────────
        //  State
        // ─────────────────────────────────────────────
        private readonly Employee _currentEmployee;
        private int _selectedVisitId = -1;
        private bool _isEditing = false;
        private decimal _consultationFee = 80m;  // base fee
        private System.Windows.Forms.Timer _clockTimer;

        // ─────────────────────────────────────────────
        //  Constructor
        // ─────────────────────────────────────────────
        public VisitForm(Employee employee)
        {
            _currentEmployee = employee;
            InitializeComponent();
            WireEvents();
            ApplyVetRestrictions();
        }

        // ─────────────────────────────────────────────
        //  Veterinarian-only access control
        // ─────────────────────────────────────────────
        private void ApplyVetRestrictions()
        {
            bool isVet = _currentEmployee?.Role == "Veterinarian";

            // Only Veterinarians can create/save/delete visits
            btnNewVisit.Enabled = isVet;
            btnSaveVisit.Enabled = isVet;
            btnDeleteVisit.Enabled = false; // enabled only when row selected + isVet

            if (!isVet)
            {
                // Show read-only warning for non-veterinarians
                var warn = new System.Windows.Forms.Label
                {
                    Text = "⚠  View only — visit management requires Veterinarian role",
                    Font = new System.Drawing.Font("Segoe UI", 9f),
                    ForeColor = UITheme.SemanticWarning,
                    AutoSize = true,
                    Location = new System.Drawing.Point(0, 0)
                };
            }
        }

        // ─────────────────────────────────────────────
        //  Event wiring
        // ─────────────────────────────────────────────
        private void WireEvents()
        {
            this.Load += VisitForm_Load;
            btnNewVisit.Click += BtnNewVisit_Click;
            btnSaveVisit.Click += BtnSaveVisit_Click;
            btnCancelVisit.Click += BtnCancelVisit_Click;
            btnDeleteVisit.Click += BtnDeleteVisit_Click;
            btnAddMedicine.Click += BtnAddMedicine_Click;
            btnRemoveMedicine.Click += BtnRemoveMedicine_Click;
            btnMarkPaid.Click += BtnMarkPaid_Click;
            cmbAnimal.SelectedIndexChanged += CmbAnimal_SelectedIndexChanged;
            cmbMedicine.SelectedIndexChanged += CmbMedicine_SelectedIndexChanged;
            txtMedicineQty.TextChanged += (s, e) => RecalculateMedicineLineTotal();
            txtMedicineQty.TextChanged += (s, e) => RecalculateMedicineLineTotal();
            dgvVisits.SelectionChanged += DgvVisits_SelectionChanged;
            dgvMedicines.CellEndEdit += DgvMedicines_CellEndEdit;
        }

        // ─────────────────────────────────────────────
        //  Form Load
        // ─────────────────────────────────────────────
        private void VisitForm_Load(object sender, EventArgs e)
        {
            try
            {
                LoadAnimals();
                LoadVeterinarians();
                LoadMedicineCombo();
                SetupClock();
                SetFormMode(FormMode.View);
                LoadAllVisits();

                // Pre-select current logged-in employee if vet
                if (_currentEmployee?.Role == "Veterinarian")
                {
                    foreach (object item in cmbVeterinarian.Items)
                    {
                        if (item is DataRowView drv &&
                            Convert.ToInt32(drv["EmployeeId"]) == _currentEmployee.EmployeeId)
                        {
                            cmbVeterinarian.SelectedItem = item;
                            break;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Failed to load Visits:\n\n{ex.Message}",
                    "Load Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // ─────────────────────────────────────────────
        //  Live clock
        // ─────────────────────────────────────────────
        private void SetupClock()
        {
            _clockTimer = new System.Windows.Forms.Timer { Interval = 1000 };
            _clockTimer.Tick += (s, e) =>
                lblCurrentDateTime.Text = DateTime.Now.ToString("dddd, dd MMMM yyyy   HH:mm:ss");
            _clockTimer.Start();
            lblCurrentDateTime.Text = DateTime.Now.ToString("dddd, dd MMMM yyyy   HH:mm:ss");
        }

        // ─────────────────────────────────────────────
        //  ComboBox loaders
        // ─────────────────────────────────────────────
        private void LoadAnimals()
        {
            try
            {
                DataTable dt = DatabaseHelper.Instance.ExecuteQuery(
                    @"SELECT a.AnimalId,
                             a.Name || ' (' || t.TypeName || ') - ' ||
                             c.FirstName || ' ' || c.LastName AS Display,
                             a.VaccineDate
                      FROM   Animals a
                      JOIN   AnimalTypes t ON a.AnimalTypeId = t.AnimalTypeId
                      JOIN   Customers   c ON a.CustomerId   = c.CustomerId
                      WHERE  a.IsActive = 1
                      ORDER  BY a.Name;");

                cmbAnimal.DataSource = dt;
                cmbAnimal.DisplayMember = "Display";
                cmbAnimal.ValueMember = "AnimalId";
                cmbAnimal.SelectedIndex = -1;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Failed to load animals:\n{ex.Message}",
                    "Load Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LoadVeterinarians()
        {
            try
            {
                DataTable dt = DatabaseHelper.Instance.ExecuteQuery(
                    @"SELECT EmployeeId,
                             'Dr. ' || FirstName || ' ' || LastName AS Display
                      FROM   Employees
                      WHERE  IsActive = 1
                        AND  Role IN ('Veterinarian','Technician')
                      ORDER  BY LastName;");

                cmbVeterinarian.DataSource = dt;
                cmbVeterinarian.DisplayMember = "Display";
                cmbVeterinarian.ValueMember = "EmployeeId";
                cmbVeterinarian.SelectedIndex = -1;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Failed to load veterinarians:\n{ex.Message}",
                    "Load Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LoadMedicineCombo()
        {
            try
            {
                DataTable dt = DatabaseHelper.Instance.ExecuteQuery(
                    @"SELECT MedicineId,
                             Name || '  [' || StockQty || ' ' || Unit || ' in stock]' AS Display,
                             UnitPrice,
                             StockQty,
                             Unit,
                             Name
                      FROM   Medicines
                      WHERE  IsActive  = 1
                        AND  StockQty  > 0
                      ORDER  BY Name;");

                cmbMedicine.DataSource = dt;
                cmbMedicine.DisplayMember = "Display";
                cmbMedicine.ValueMember = "MedicineId";
                cmbMedicine.SelectedIndex = -1;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Failed to load medicines:\n{ex.Message}",
                    "Load Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // ─────────────────────────────────────────────
        //  Animal selection → vaccine warning
        // ─────────────────────────────────────────────
        private void CmbAnimal_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbAnimal.SelectedValue == null) return;

            // Fetch vaccine date for selected animal
            try
            {
                DataTable dt = DatabaseHelper.Instance.ExecuteQuery(
                    "SELECT VaccineDate FROM Animals WHERE AnimalId = @Id;",
                    new SQLiteParameter("@Id", cmbAnimal.SelectedValue));

                if (dt.Rows.Count == 0) return;

                string rawDate = dt.Rows[0]["VaccineDate"]?.ToString();
                CheckVaccineWarning(rawDate);
            }
            catch { /* non-critical */ }
        }

        private void CheckVaccineWarning(string rawVaccineDate)
        {
            pnlVaccineWarning.Visible = false;

            if (string.IsNullOrWhiteSpace(rawVaccineDate)) return;
            if (!DateTime.TryParse(rawVaccineDate, out DateTime lastVax)) return;

            int monthsSinceVax = ((DateTime.Today.Year - lastVax.Year) * 12)
                               + (DateTime.Today.Month - lastVax.Month);

            if (monthsSinceVax >= 12)  // annual vaccine due
            {
                string urgency = monthsSinceVax >= 13 ? "OVERDUE" : "DUE SOON";
                lblVaccineWarning.Text =
                    $"⚠  Vaccine {urgency}  - last vaccination was {monthsSinceVax} month(s) ago " +
                    $"({lastVax:dd/MM/yyyy}).  Recommend scheduling a booster.";
                pnlVaccineWarning.BackColor = monthsSinceVax >= 13
                    ? UITheme.SemanticDangerBg
                    : UITheme.SemanticWarningBg;
                lblVaccineWarning.ForeColor = monthsSinceVax >= 13
                    ? UITheme.SemanticDanger
                    : UITheme.SemanticWarning;
                pnlVaccineWarning.Visible = true;
            }
        }

        // ─────────────────────────────────────────────
        //  Medicine ComboBox → fill unit price
        // ─────────────────────────────────────────────
        private void CmbMedicine_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbMedicine.SelectedValue == null) return;

            DataRowView drv = cmbMedicine.SelectedItem as DataRowView;
            if (drv == null) return;

            // Auto-fill price from database
            decimal unitPrice = Convert.ToDecimal(drv["UnitPrice"]);
            txtMedicinePrice.Text = $"{unitPrice:F2}";
            txtMedicinePrice.ReadOnly = true;
            txtMedicinePrice.BackColor = UITheme.BgSurface;

            // Reset quantity to 1
            txtMedicineQty.Text = "1";
            txtMedicineQty.Focus();
            txtMedicineQty.SelectAll();

            RecalculateMedicineLineTotal();
        }

        private void RecalculateMedicineLineTotal()
        {
            if (!decimal.TryParse(txtMedicinePrice.Text, out decimal price)) return;
            if (!decimal.TryParse(txtMedicineQty.Text, out decimal qty)) return;
            decimal total = price * qty;
            lblMedicineLineTotal.Text = $"Line Total:  ₪{total:F2}";
            lblMedicineLineTotal.ForeColor = UITheme.Accent;
        }

        // ─────────────────────────────────────────────
        //  Medicine grid events
        // ─────────────────────────────────────────────
        private void BtnAddMedicine_Click(object sender, EventArgs e)
        {
            if (cmbMedicine.SelectedValue == null)
            {
                MessageBox.Show("Please select a medicine to add.",
                    "No Medicine", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            if (!decimal.TryParse(txtMedicineQty.Text, out decimal qty) || qty <= 0)
            {
                MessageBox.Show("Please enter a valid quantity (> 0).",
                    "Invalid Quantity", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DataRowView drv = cmbMedicine.SelectedItem as DataRowView;
            int medicineId = Convert.ToInt32(drv["MedicineId"]);
            string medicineName = drv["Name"].ToString();
            decimal unitPrice = Convert.ToDecimal(drv["UnitPrice"]);
            decimal stockQty = Convert.ToDecimal(drv["StockQty"]);
            string unit = drv["Unit"].ToString();

            // Check stock
            if (qty > stockQty)
            {
                MessageBox.Show(
                    $"Insufficient stock for {medicineName}.\n" +
                    $"Available: {stockQty} {unit}   Requested: {qty} {unit}",
                    "Stock Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Check for duplicate row
            foreach (DataGridViewRow row in dgvMedicines.Rows)
            {
                if (Convert.ToInt32(row.Cells["dgvMedId"].Value) == medicineId)
                {
                    MessageBox.Show("This medicine has already been added to the visit.\nUpdate the quantity in the grid directly.",
                        "Duplicate Medicine", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
            }

            decimal lineTotal = qty * unitPrice;
            dgvMedicines.Rows.Add(medicineId, medicineName, unitPrice, qty, unit, lineTotal,
                txtMedicineDosage.Text.Trim(), txtMedicineInstructions.Text.Trim());

            RecalculateTotalPrice();
            cmbMedicine.SelectedIndex = -1;
            txtMedicineQty.Text = "1";
            txtMedicinePrice.Text = string.Empty;
            lblMedicineLineTotal.Text = string.Empty;
            txtMedicineDosage.Text = string.Empty;
            txtMedicineInstructions.Text = string.Empty;
        }

        private void BtnRemoveMedicine_Click(object sender, EventArgs e)
        {
            if (dgvMedicines.SelectedRows.Count == 0)
            {
                MessageBox.Show("Select a medicine row to remove.",
                    "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            dgvMedicines.Rows.Remove(dgvMedicines.SelectedRows[0]);
            RecalculateTotalPrice();
        }

        private void DgvMedicines_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            // Recalculate line total when qty is changed directly in grid
            if (dgvMedicines.Columns[e.ColumnIndex].Name == "dgvMedQty")
            {
                var row = dgvMedicines.Rows[e.RowIndex];
                if (decimal.TryParse(row.Cells["dgvMedUnitPrice"].Value?.ToString(), out decimal up) &&
                    decimal.TryParse(row.Cells["dgvMedQty"].Value?.ToString(), out decimal q))
                {
                    row.Cells["dgvMedLineTotal"].Value = Math.Round(up * q, 2);
                    RecalculateTotalPrice();
                }
            }
        }

        // ─────────────────────────────────────────────
        //  Price calculation
        // ─────────────────────────────────────────────
        private void RecalculateTotalPrice()
        {
            decimal medicineTotal = 0m;
            foreach (DataGridViewRow row in dgvMedicines.Rows)
            {
                if (decimal.TryParse(row.Cells["dgvMedLineTotal"].Value?.ToString(), out decimal lt))
                    medicineTotal += lt;
            }

            decimal total = _consultationFee + medicineTotal;
            lblConsultationFee.Text = $"₪{_consultationFee:F2}";
            lblMedicinesTotal.Text = $"₪{medicineTotal:F2}";
            lblGrandTotal.Text = $"₪{total:F2}";
        }

        // ─────────────────────────────────────────────
        //  Visit list grid
        // ─────────────────────────────────────────────
        private void DgvVisits_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvVisits.SelectedRows.Count == 0) return;

            var row = dgvVisits.SelectedRows[0];
            _selectedVisitId = Convert.ToInt32(row.Cells["colVisitId"].Value);

            LoadVisitDetail(_selectedVisitId);
            btnDeleteVisit.Enabled = (_currentEmployee?.Role == "Veterinarian");
            btnMarkPaid.Enabled = row.Cells["colIsPaid"].Value?.ToString() == "0";
        }

        private void LoadVisitDetail(int visitId)
        {
            try
            {
                // Visit header
                DataTable vt = DatabaseHelper.Instance.ExecuteQuery(
                    @"SELECT v.*,
                             a.Name || ' (' || t.TypeName || ')' AS AnimalDisplay,
                             'Dr. ' || e.FirstName || ' ' || e.LastName AS VetDisplay
                      FROM   Visits v
                      JOIN   Animals   a ON v.AnimalId   = a.AnimalId
                      JOIN   AnimalTypes t ON a.AnimalTypeId = t.AnimalTypeId
                      JOIN   Employees  e ON v.EmployeeId = e.EmployeeId
                      WHERE  v.VisitId = @Id;",
                    new SQLiteParameter("@Id", visitId));

                if (vt.Rows.Count == 0) return;
                DataRow vr = vt.Rows[0];

                cmbAnimal.SelectedValue = vr["AnimalId"];
                cmbVeterinarian.SelectedValue = vr["EmployeeId"];
                txtReason.Text = vr["Reason"].ToString();
                txtDiagnosis.Text = vr["Diagnosis"].ToString();
                txtTreatment.Text = vr["Treatment"].ToString();
                txtNotes.Text = vr["Notes"].ToString();
                cmbStatus.SelectedItem = vr["Status"].ToString();

                // Visit medicines
                DataTable mt = DatabaseHelper.Instance.ExecuteQuery(
                    @"SELECT vm.MedicineId, m.Name, vm.UnitPrice, vm.Quantity,
                             m.Unit, vm.Quantity * vm.UnitPrice AS LineTotal,
                             vm.Dosage, vm.Instructions
                      FROM   VisitMedicines vm
                      JOIN   Medicines m ON vm.MedicineId = m.MedicineId
                      WHERE  vm.VisitId = @Id;",
                    new SQLiteParameter("@Id", visitId));

                dgvMedicines.Rows.Clear();
                foreach (DataRow mr in mt.Rows)
                {
                    dgvMedicines.Rows.Add(
                        mr["MedicineId"], mr["Name"], mr["UnitPrice"],
                        mr["Quantity"], mr["Unit"], mr["LineTotal"],
                        mr["Dosage"], mr["Instructions"]);
                }

                RecalculateTotalPrice();
                CheckVaccineWarning(null); // reset warning when loading old visit
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Failed to load visit details:\n{ex.Message}",
                    "Load Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // ─────────────────────────────────────────────
        //  CRUD handlers
        // ─────────────────────────────────────────────
        private void BtnNewVisit_Click(object sender, EventArgs e)
        {
            ClearForm();
            _selectedVisitId = -1;
            _isEditing = false;
            SetFormMode(FormMode.Edit);
            cmbAnimal.Focus();
        }

        private void BtnSaveVisit_Click(object sender, EventArgs e)
        {
            if (!ValidateVisit()) return;

            try
            {
                if (_isEditing) UpdateVisit();
                else InsertVisit();

                MessageBox.Show("Visit saved successfully.",
                    "Saved", MessageBoxButtons.OK, MessageBoxIcon.Information);

                SetFormMode(FormMode.View);
                LoadAllVisits();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Failed to save visit:\n\n{ex.Message}",
                    "Save Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnCancelVisit_Click(object sender, EventArgs e)
        {
            _isEditing = false;
            SetFormMode(FormMode.View);
            ClearForm();
        }

        private void BtnDeleteVisit_Click(object sender, EventArgs e)
        {
            if (_selectedVisitId < 0) return;

            var confirm = MessageBox.Show(
                "Delete this visit record?\n\nAll associated medicines will also be removed.",
                "Confirm Delete",
                MessageBoxButtons.YesNo, MessageBoxIcon.Warning,
                MessageBoxDefaultButton.Button2);

            if (confirm != DialogResult.Yes) return;

            try
            {
                // VisitMedicines CASCADE delete handled by FK
                DatabaseHelper.Instance.ExecuteNonQuery(
                    "UPDATE Visits SET Status = 'Cancelled', UpdatedAt = DATETIME('now') WHERE VisitId = @Id;",
                    new SQLiteParameter("@Id", _selectedVisitId));

                MessageBox.Show("Visit cancelled.", "Cancelled",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);

                ClearForm();
                SetFormMode(FormMode.View);
                LoadAllVisits();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Failed to cancel visit:\n{ex.Message}",
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnMarkPaid_Click(object sender, EventArgs e)
        {
            if (_selectedVisitId < 0) return;

            DatabaseHelper.Instance.ExecuteNonQuery(
                "UPDATE Visits SET IsPaid = 1, UpdatedAt = DATETIME('now') WHERE VisitId = @Id;",
                new SQLiteParameter("@Id", _selectedVisitId));

            MessageBox.Show("Visit marked as paid.", "Payment",
                MessageBoxButtons.OK, MessageBoxIcon.Information);

            LoadAllVisits();
            btnMarkPaid.Enabled = false;
        }

        // ─────────────────────────────────────────────
        //  Database operations
        // ─────────────────────────────────────────────
        private void InsertVisit()
        {
            decimal total = GetGrandTotal();

            const string sql = @"
                INSERT INTO Visits
                    (AnimalId, EmployeeId, VisitDate, VisitTime, Reason, Diagnosis,
                     Treatment, Notes, TotalCost, IsPaid, Status)
                VALUES
                    (@AnimalId, @EmpId, DATE('now'), @Reason, @Diagnosis,
                     @Treatment, @Notes, @Total, 0, @Status);";

            DatabaseHelper.Instance.ExecuteNonQuery(sql,
                new SQLiteParameter("@AnimalId", cmbAnimal.SelectedValue),
                new SQLiteParameter("@EmpId", cmbVeterinarian.SelectedValue),
                new SQLiteParameter("@Reason", txtReason.Text.Trim()),
                new SQLiteParameter("@Diagnosis", txtDiagnosis.Text.Trim()),
                new SQLiteParameter("@Treatment", txtTreatment.Text.Trim()),
                new SQLiteParameter("@Notes", txtNotes.Text.Trim()),
                new SQLiteParameter("@Total", total),
                new SQLiteParameter("@Status", cmbStatus.SelectedItem?.ToString() ?? "Completed"));

            long visitId = DatabaseHelper.Instance.GetLastInsertId();
            SaveVisitMedicines((int)visitId);
        }

        private void UpdateVisit()
        {
            decimal total = GetGrandTotal();

            const string sql = @"
                UPDATE Visits SET
                    AnimalId  = @AnimalId,  EmployeeId = @EmpId,
                    Reason    = @Reason,    Diagnosis  = @Diagnosis,
                    Treatment = @Treatment, Notes      = @Notes,
                    TotalCost = @Total,     Status     = @Status,
                    UpdatedAt = DATETIME('now')
                WHERE VisitId = @Id;";

            DatabaseHelper.Instance.ExecuteNonQuery(sql,
                new SQLiteParameter("@AnimalId", cmbAnimal.SelectedValue),
                new SQLiteParameter("@EmpId", cmbVeterinarian.SelectedValue),
                new SQLiteParameter("@Reason", txtReason.Text.Trim()),
                new SQLiteParameter("@Diagnosis", txtDiagnosis.Text.Trim()),
                new SQLiteParameter("@Treatment", txtTreatment.Text.Trim()),
                new SQLiteParameter("@Notes", txtNotes.Text.Trim()),
                new SQLiteParameter("@Total", total),
                new SQLiteParameter("@Status", cmbStatus.SelectedItem?.ToString() ?? "Completed"),
                new SQLiteParameter("@Id", _selectedVisitId));

            // Replace all medicines
            DatabaseHelper.Instance.ExecuteNonQuery(
                "DELETE FROM VisitMedicines WHERE VisitId = @Id;",
                new SQLiteParameter("@Id", _selectedVisitId));

            SaveVisitMedicines(_selectedVisitId);
        }

        private void SaveVisitMedicines(int visitId)
        {
            const string sql = @"
                INSERT INTO VisitMedicines
                    (VisitId, MedicineId, Quantity, UnitPrice, Dosage, Instructions)
                VALUES
                    (@VisitId, @MedId, @Qty, @Price, @Dosage, @Instr);";

            foreach (DataGridViewRow row in dgvMedicines.Rows)
            {
                DatabaseHelper.Instance.ExecuteNonQuery(sql,
                    new SQLiteParameter("@VisitId", visitId),
                    new SQLiteParameter("@MedId", row.Cells["dgvMedId"].Value),
                    new SQLiteParameter("@Qty", row.Cells["dgvMedQty"].Value),
                    new SQLiteParameter("@Price", row.Cells["dgvMedUnitPrice"].Value),
                    new SQLiteParameter("@Dosage", row.Cells["dgvMedDosage"].Value ?? DBNull.Value),
                    new SQLiteParameter("@Instr", row.Cells["dgvMedInstructions"].Value ?? DBNull.Value));

                // Deduct stock
                DatabaseHelper.Instance.ExecuteNonQuery(
                    "UPDATE Medicines SET StockQty = StockQty - @Qty, UpdatedAt = DATETIME('now') WHERE MedicineId = @Id;",
                    new SQLiteParameter("@Qty", row.Cells["dgvMedQty"].Value),
                    new SQLiteParameter("@Id", row.Cells["dgvMedId"].Value));
            }
        }

        // ─────────────────────────────────────────────
        //  Load visit list
        // ─────────────────────────────────────────────
        private void LoadAllVisits()
        {
            try
            {
                DataTable dt = DatabaseHelper.Instance.ExecuteQuery(
                    @"SELECT v.VisitId,
                             v.VisitDate,
                             a.Name                                    AS AnimalName,
                             t.TypeName,
                             'Dr. '||e.FirstName||' '||e.LastName      AS VetName,
                             v.Reason,
                             v.TotalCost,
                             v.IsPaid,
                             v.Status
                      FROM   Visits   v
                      JOIN   Animals  a ON v.AnimalId   = a.AnimalId
                      JOIN   AnimalTypes t ON a.AnimalTypeId = t.AnimalTypeId
                      JOIN   Employees e ON v.EmployeeId = e.EmployeeId
                      WHERE  v.Status <> 'Cancelled'
                      ORDER  BY v.VisitDate DESC, v.VisitId DESC;");

                dgvVisits.Rows.Clear();
                foreach (DataRow row in dt.Rows)
                {
                    bool paid = Convert.ToInt32(row["IsPaid"]) == 1;
                    string status = row["Status"].ToString();
                    decimal cost = Convert.ToDecimal(row["TotalCost"]);

                    int idx = dgvVisits.Rows.Add(
                        row["VisitId"],
                        DateTime.Parse(row["VisitDate"].ToString()).ToString("dd/MM/yyyy"),
                        row["AnimalName"],
                        row["TypeName"],
                        row["VetName"],
                        row["Reason"],
                        $"₪{cost:F2}",
                        paid ? "✔ Paid" : "Unpaid",
                        row["IsPaid"],
                        status);

                    // Status colour
                    var r = dgvVisits.Rows[idx];
                    r.DefaultCellStyle.BackColor = idx % 2 == 0
                        ? UITheme.BgCard
                        : UITheme.BgInput;

                    r.Cells["colPaid"].Style.ForeColor = paid
                        ? UITheme.SemanticSuccess
                        : UITheme.SemanticWarning;

                    r.Cells["colStatus"].Style.ForeColor = status switch
                    {
                        "Completed" => UITheme.SemanticSuccess,
                        "Scheduled" => UITheme.AccentViolet,
                        "InProgress" => UITheme.SemanticWarning,
                        _ => UITheme.TextSecondary
                    };
                }

                lblVisitCount.Text = $"{dt.Rows.Count} visit{(dt.Rows.Count != 1 ? "s" : "")}";
                btnDeleteVisit.Enabled = false;
                btnMarkPaid.Enabled = false;
                _selectedVisitId = -1;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Failed to load visits:\n{ex.Message}",
                    "Load Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // ─────────────────────────────────────────────
        //  Validation
        // ─────────────────────────────────────────────
        private bool ValidateVisit()
        {
            if (cmbAnimal.SelectedValue == null)
            { MessageBox.Show("Please select an animal.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning); return false; }

            if (cmbVeterinarian.SelectedValue == null)
            { MessageBox.Show("Please select a veterinarian.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning); return false; }

            if (string.IsNullOrWhiteSpace(txtReason.Text))
            { MessageBox.Show("Visit reason is required.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning); txtReason.Focus(); return false; }

            return true;
        }

        // ─────────────────────────────────────────────
        //  Helpers
        // ─────────────────────────────────────────────
        private decimal GetGrandTotal()
        {
            decimal med = 0m;
            foreach (DataGridViewRow r in dgvMedicines.Rows)
                if (decimal.TryParse(r.Cells["dgvMedLineTotal"].Value?.ToString(), out decimal lt))
                    med += lt;
            return _consultationFee + med;
        }

        private enum FormMode { View, Edit }

        private void SetFormMode(FormMode mode)
        {
            bool editing = mode == FormMode.Edit;

            cmbAnimal.Enabled = editing;
            cmbVeterinarian.Enabled = editing;
            txtReason.ReadOnly = !editing;
            txtDiagnosis.ReadOnly = !editing;
            txtTreatment.ReadOnly = !editing;
            txtNotes.ReadOnly = !editing;
            cmbStatus.Enabled = editing;
            pnlMedicineAdd.Visible = editing;

            btnNewVisit.Visible = !editing;
            btnDeleteVisit.Visible = !editing;
            btnMarkPaid.Visible = !editing;
            btnSaveVisit.Visible = editing;
            btnCancelVisit.Visible = editing;

            dgvVisits.Enabled = !editing;

            lblFormTitle.Text = editing
                ? (_isEditing ? "✏  Edit Visit" : "📋  New Visit")
                : "Visit Details";
        }

        private void ClearForm()
        {
            // Reset date/time to now
            if (dtpVisitDate != null) dtpVisitDate.Value = DateTime.Today;
            if (txtVisitTime != null) txtVisitTime.Text = DateTime.Now.ToString("HH:mm");
            cmbAnimal.SelectedIndex = -1;
            cmbVeterinarian.SelectedIndex = -1;
            txtReason.Clear();
            txtDiagnosis.Clear();
            txtTreatment.Clear();
            txtNotes.Clear();
            cmbStatus.SelectedIndex = 0;
            dgvMedicines.Rows.Clear();
            cmbMedicine.SelectedIndex = -1;
            txtMedicineQty.Text = "1";
            txtMedicinePrice.Text = string.Empty;
            lblMedicineLineTotal.Text = string.Empty;
            txtMedicineDosage.Clear();
            txtMedicineInstructions.Clear();
            pnlVaccineWarning.Visible = false;
            RecalculateTotalPrice();
        }
    }
}