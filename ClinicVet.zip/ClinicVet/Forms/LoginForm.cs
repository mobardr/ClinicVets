using System;
using System.Data;
using System.Data.SQLite;
using System.Drawing;
using System.Security.Cryptography;
using System.Text;
using System.Windows.Forms;
using ClinicVets.Data;
using ClinicVets.Helpers;
using ClinicVets.Models;
using ClinicVets.UI;

namespace ClinicVets.Forms
{
    public partial class LoginForm : Form
    {
        public Employee LoggedInEmployee { get; private set; }

        private int _failedAttempts = 0;
        private const int MaxAttempts = 5;
        private bool _loginPasswordVisible = false;
        private bool _registerPasswordVisible = false;
        private bool _registerConfirmVisible = false;

        public LoginForm()
        {
            InitializeComponent();
            FixLayout();
            WireEvents();
        }

        // ── Runtime layout fix (bypasses Designer file completely) ──────────
        private void FixLayout()
        {
            int CARD_W = 520;
            int CARD_H = 560;
            int pad = 44;
            int cw = CARD_W - pad * 2;
            int cx = pad;

            pnlCard.Size = new Size(CARD_W, CARD_H);
            pnlCard.BackColor = UITheme.BgCard;

            EventHandler centre = delegate (object s, EventArgs e)
            {
                if (pnlOuter.Width < 1) return;
                pnlCard.Location = new Point(
                    (pnlOuter.Width - pnlCard.Width) / 2,
                    Math.Max(20, (pnlOuter.Height - pnlCard.Height) / 2));
            };
            pnlOuter.Resize += centre;
            this.Load += centre;

            // ── Login panel ─────────────────────────────────────────────────
            pnlLoginView.Size = new Size(CARD_W, CARD_H - 4);
            pnlLoginView.Location = new Point(0, 4);
            pnlLoginView.BackColor = UITheme.BgCard;
            pnlLoginView.Controls.Clear();

            int ly = 24;

            var lblTitle = MkCentredLabel("Welcome back",
                new Font("Segoe UI", 24f, FontStyle.Bold),
                UITheme.TextPrimary, CARD_W, 52, 0, ly);
            ly += 58;

            var lblSub = MkCentredLabel("Sign in to your account",
                new Font("Segoe UI", 9.5f),
                UITheme.TextMuted, CARD_W, 20, 0, ly);
            ly += 26;

            var div0 = MkDivider(cx, ly, cw); ly += 14;

            // Username label + input
            var lblUser = MkFieldLabel("Username", cx, ly, cw); ly += 20;
            txtLoginEmail.Size = new Size(cw, 30);
            txtLoginEmail.Location = new Point(cx, ly);
            txtLoginEmail.Font = new Font("Segoe UI", 10f);
            txtLoginEmail.BorderStyle = BorderStyle.FixedSingle;
            txtLoginEmail.BackColor = Color.White;
            txtLoginEmail.ForeColor = UITheme.TextPrimary;
            ly += 42;

            // Password label + input
            var lblPwd = MkFieldLabel("Password", cx, ly, cw); ly += 20;
            txtLoginPassword.Size = new Size(cw - 36, 30);
            txtLoginPassword.Location = new Point(cx, ly);
            txtLoginPassword.Font = new Font("Segoe UI", 10f);
            txtLoginPassword.BorderStyle = BorderStyle.FixedSingle;
            txtLoginPassword.BackColor = Color.White;
            txtLoginPassword.ForeColor = UITheme.TextPrimary;
            txtLoginPassword.UseSystemPasswordChar = true;
            btnEyeLogin.Size = new Size(34, 30);
            btnEyeLogin.Location = new Point(cx + cw - 34, ly);
            btnEyeLogin.BackColor = Color.White;
            ly += 42;

            lblLoginError.Size = new Size(cw, 24);
            lblLoginError.Location = new Point(cx, ly);
            lblLoginError.Visible = false;
            ly += 4;

            UITheme.StylePrimaryBtn(btnLogin, "Sign In");
            btnLogin.Size = new Size(cw, 44);
            btnLogin.Location = new Point(cx, ly);
            ly += 56;

            var div1 = MkDivider(cx, ly, cw); ly += 14;

            lnkGoToRegister.Size = new Size(CARD_W, 20);
            lnkGoToRegister.Location = new Point(0, ly);
            lnkGoToRegister.TextAlign = ContentAlignment.MiddleCenter;
            lnkGoToRegister.BackColor = UITheme.BgCard;
            ly += 28;

            lnkBackFromLogin.Size = new Size(CARD_W, 20);
            lnkBackFromLogin.Location = new Point(0, ly);
            lnkBackFromLogin.TextAlign = ContentAlignment.MiddleCenter;
            lnkBackFromLogin.BackColor = UITheme.BgCard;
            lnkBackFromLogin.ForeColor = UITheme.TextMuted;

            lblVersion.Size = new Size(CARD_W, 16);
            lblVersion.Location = new Point(0, CARD_H - 28);
            lblVersion.TextAlign = ContentAlignment.MiddleCenter;
            lblVersion.BackColor = UITheme.BgCard;

            pnlLoginView.Controls.AddRange(new Control[]
            {
                lblTitle, lblSub, div0,
                lblUser, txtLoginEmail,
                lblPwd, txtLoginPassword, btnEyeLogin,
                lblLoginError, btnLogin, div1,
                lnkGoToRegister, lnkBackFromLogin, lblVersion
            });

            // ── Register panel ──────────────────────────────────────────────
            // Card grows when register shows
            int RC = 600;
            int RH = 640;
            int rPad = (RC - (256 + 14 + 256)) / 2;  // 37px each side
            int rCol = 256;
            int rGap = 14;
            int rFull = rCol * 2 + rGap;
            int rx = rPad;
            int rx2 = rPad + rCol + rGap;

            pnlRegisterView.Size = new Size(RC, RH - 4);
            pnlRegisterView.Location = new Point(0, 4);
            pnlRegisterView.BackColor = UITheme.BgCard;
            pnlRegisterView.AutoScroll = true;
            pnlRegisterView.Controls.Clear();

            int ry = 16;

            var rTitle = MkCentredLabel("Create Account",
                new Font("Segoe UI", 22f, FontStyle.Bold),
                UITheme.TextPrimary, RC, 48, 0, ry);
            ry += 54;

            var rSub = MkCentredLabel("Register a new clinic employee",
                new Font("Segoe UI", 9.5f),
                UITheme.TextMuted, RC, 20, 0, ry);
            ry += 26;

            var rDiv = MkDivider(rx, ry, rFull); ry += 14;

            // Row 1: First Name | Last Name
            AddFieldToPanel(pnlRegisterView, "First Name *",
                rx, ry, rCol, out Label lFN, out _, out Label eFN);
            AddFieldToPanel(pnlRegisterView, "Last Name *",
                rx2, ry, rCol, out Label lLN, out _, out Label eLN);
            lblRegFirstName = lFN; lblErrRegFirstName = eFN;
            lblRegLastName = lLN; lblErrRegLastName = eLN;
            ry += 64;

            // Row 2: Username | Employee Number
            AddFieldToPanel(pnlRegisterView, "Username (6-8 chars, max 2 digits)",
                rx, ry, rCol, out Label lUN, out TextBox tUN, out Label eUN);
            AddFieldToPanel(pnlRegisterView, "Employee Number (4 digits)",
                rx2, ry, rCol, out Label lEN, out TextBox tEN, out Label eEN);
            lblRegUsername = lUN; txtRegUsername = tUN; lblErrRegUsername = eUN;
            lblRegEmpNum = lEN; txtRegEmpNum = tEN; lblErrRegEmpNum = eEN;
            ry += 64;

            // Row 3: ID Number | Phone
            AddFieldToPanel(pnlRegisterView, "ID Number - ת\"ז (9 digits)",
                rx, ry, rCol, out Label lID, out TextBox tID, out Label eID);
            AddFieldToPanel(pnlRegisterView, "Phone",
                rx2, ry, rCol, out Label lPH, out TextBox tPH, out Label ePH);
            lblRegIdNumber = lID; txtRegIdNumber = tID; lblErrRegIdNumber = eID;
            lblRegPhone = lPH; txtRegPhone = tPH;
            ry += 64;

            // Row 4: Email (full width)
            AddFieldToPanel(pnlRegisterView, "Email Address *",
                rx, ry, rFull, out Label lEM, out TextBox tEM, out Label eEM);
            lblRegEmail = lEM; txtRegEmail = tEM; lblErrRegEmail = eEM;
            ry += 64;

            // Row 5: Role (full width dropdown)
            var lblRoleL = MkFieldLabel("Role *", rx, ry, rFull);
            pnlRegisterView.Controls.Add(lblRoleL);
            cmbRegRole = new ComboBox
            {
                Size = new Size(rFull, 30),
                Location = new Point(rx, ry + 20),
                Font = UITheme.FontInput,
                FlatStyle = FlatStyle.Flat,
                BackColor = Color.White,
                ForeColor = UITheme.TextPrimary,
                DropDownStyle = ComboBoxStyle.DropDownList
            };
            cmbRegRole.Items.AddRange(new object[] { "Veterinarian", "Secretary" });
            lblErrRegRole = MkErrLabel(rx, ry + 52, rFull);
            pnlRegisterView.Controls.Add(cmbRegRole);
            pnlRegisterView.Controls.Add(lblErrRegRole);
            ry += 70;

            // Row 6: Password | Confirm
            var lblPW = MkFieldLabel("Password * (8-10, letter+digit+special !$#()",
                rx, ry, rCol);
            txtRegPassword = new TextBox
            {
                Size = new Size(rCol - 36, 30),
                Location = new Point(rx, ry + 20),
                Font = new Font("Segoe UI", 10f),
                BorderStyle = BorderStyle.FixedSingle,
                BackColor = Color.White,
                ForeColor = UITheme.TextPrimary,
                UseSystemPasswordChar = true
            };
            btnEyeRegPassword = MkEyeBtn(rx + rCol - 34, ry + 20);
            lblErrRegPassword = MkErrLabel(rx, ry + 52, rCol);

            var lblCF = MkFieldLabel("Confirm Password *", rx2, ry, rCol);
            txtRegConfirm = new TextBox
            {
                Size = new Size(rCol - 36, 30),
                Location = new Point(rx2, ry + 20),
                Font = new Font("Segoe UI", 10f),
                BorderStyle = BorderStyle.FixedSingle,
                BackColor = Color.White,
                ForeColor = UITheme.TextPrimary,
                UseSystemPasswordChar = true
            };
            btnEyeRegConfirm = MkEyeBtn(rx2 + rCol - 34, ry + 20);
            lblErrRegConfirm = MkErrLabel(rx2, ry + 52, rCol);
            lblRegPassword = lblPW; lblRegConfirm = lblCF;

            pnlRegisterView.Controls.AddRange(new Control[]
            {
                lblPW, txtRegPassword, btnEyeRegPassword, lblErrRegPassword,
                lblCF, txtRegConfirm, btnEyeRegConfirm, lblErrRegConfirm
            });
            ry += 70;

            // Create Account button
            btnRegister = new Button();
            UITheme.StylePrimaryBtn(btnRegister, "Create Account");
            btnRegister.Size = new Size(rFull, 44);
            btnRegister.Location = new Point(rx, ry);
            ry += 54;

            lnkGoToLogin = new Label
            {
                Text = "Already have an account? Sign In",
                Font = new Font("Segoe UI", 9f, FontStyle.Underline),
                ForeColor = UITheme.Accent,
                AutoSize = false,
                Size = new Size(RC, 20),
                Location = new Point(0, ry),
                TextAlign = ContentAlignment.MiddleCenter,
                Cursor = Cursors.Hand,
                BackColor = UITheme.BgCard
            };
            lnkGoToLogin.MouseEnter += (s, e) => lnkGoToLogin.ForeColor = UITheme.AccentHover;
            lnkGoToLogin.MouseLeave += (s, e) => lnkGoToLogin.ForeColor = UITheme.Accent;

            pnlRegisterView.Controls.AddRange(new Control[]
            {
                rTitle, rSub, rDiv, rDiv,
                btnRegister, lnkGoToLogin
            });

            // Register panel uses a wider card
            pnlRegisterView.Tag = RC;
        }

        // ── Show login / register ────────────────────────────────────────────
        private void ShowLoginView()
        {
            pnlCard.Size = new Size(520, 560);
            pnlRegisterView.Visible = false;
            pnlLoginView.Visible = true;
            lblLoginError.Visible = false;
            txtLoginEmail.Focus();
            // Re-centre
            pnlOuter.PerformLayout();
            if (pnlOuter.Width > 0)
                pnlCard.Location = new Point(
                    (pnlOuter.Width - pnlCard.Width) / 2,
                    Math.Max(20, (pnlOuter.Height - pnlCard.Height) / 2));
        }

        private void ShowRegisterView()
        {
            pnlCard.Size = new Size(600, 640);
            pnlLoginView.Visible = false;
            pnlRegisterView.Visible = true;
            ClearRegisterForm();
            if (txtRegUsername != null) txtRegUsername.Focus();
            if (pnlOuter.Width > 0)
                pnlCard.Location = new Point(
                    (pnlOuter.Width - pnlCard.Width) / 2,
                    Math.Max(20, (pnlOuter.Height - pnlCard.Height) / 2));
        }

        public void SwitchToRegister() => ShowRegisterView();

        // ── Event wiring ─────────────────────────────────────────────────────
        private void WireEvents()
        {
            this.Load += (s, e) => ShowLoginView();

            btnLogin.Click += BtnLogin_Click;
            btnEyeLogin.Click += BtnEyeLogin_Click;
            lnkGoToRegister.Click += (s, e) => ShowRegisterView();
            txtLoginEmail.KeyDown += Input_KeyDown;
            txtLoginPassword.KeyDown += Input_KeyDown;
            txtLoginEmail.GotFocus += (s, e) => lblLoginError.Visible = false;

            btnRegister.Click += BtnRegister_Click;
            btnEyeRegPassword.Click += BtnEyeRegPassword_Click;
            btnEyeRegConfirm.Click += BtnEyeRegConfirm_Click;
            lnkGoToLogin.Click += (s, e) => ShowLoginView();
        }

        // ── Login logic ──────────────────────────────────────────────────────
        private void BtnLogin_Click(object sender, EventArgs e) => AttemptLogin();

        private void Input_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter) { e.SuppressKeyPress = true; AttemptLogin(); }
        }

        private void BtnEyeLogin_Click(object sender, EventArgs e)
        {
            _loginPasswordVisible = !_loginPasswordVisible;
            txtLoginPassword.UseSystemPasswordChar = !_loginPasswordVisible;
            btnEyeLogin.Text = _loginPasswordVisible ? "x" : "o";
        }

        private void AttemptLogin()
        {
            if (_failedAttempts >= MaxAttempts)
            { ShowLoginError("Account locked - too many failed attempts."); SetLoginEnabled(false); return; }

            string username = txtLoginEmail.Text.Trim();
            string password = txtLoginPassword.Text;

            if (string.IsNullOrWhiteSpace(username))
            { ShowLoginError("Please enter your username."); txtLoginEmail.Focus(); return; }
            if (string.IsNullOrWhiteSpace(password))
            { ShowLoginError("Please enter your password."); txtLoginPassword.Focus(); return; }

            try
            {
                Employee emp = VerifyCredentials(username, password);
                if (emp != null)
                {
                    LoggedInEmployee = emp;
                    _failedAttempts = 0;
                    this.DialogResult = DialogResult.OK;
                    this.Close();
                }
                else
                {
                    _failedAttempts++;
                    int rem = MaxAttempts - _failedAttempts;
                    ShowLoginError(rem > 0
                        ? $"Invalid username or password. {rem} attempt(s) remaining."
                        : "Account locked - too many failed attempts.");
                    if (rem <= 0) SetLoginEnabled(false);
                    txtLoginPassword.Clear();
                    txtLoginPassword.Focus();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Database error:\n\n" + ex.Message,
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private Employee VerifyCredentials(string username, string password)
        {
            string hash = HashPassword(password);
            const string sql = @"
                SELECT EmployeeId, Username, FirstName, LastName, Role, Phone,
                       Email, EmployeeNumber, IdNumber,
                       HireDate, IsActive, CreatedAt, UpdatedAt
                FROM   Employees
                WHERE  LOWER(Username) = LOWER(@User)
                  AND  PasswordHash    = @Hash
                  AND  IsActive        = 1
                LIMIT  1;";

            DataTable dt = DatabaseHelper.Instance.ExecuteQuery(sql,
                new SQLiteParameter("@User", username),
                new SQLiteParameter("@Hash", hash));

            if (dt.Rows.Count == 0) return null;
            DataRow r = dt.Rows[0];
            return new Employee
            {
                EmployeeId = Convert.ToInt32(r["EmployeeId"]),
                Username = r["Username"].ToString(),
                FirstName = r["FirstName"].ToString(),
                LastName = r["LastName"].ToString(),
                Role = r["Role"].ToString(),
                Phone = r["Phone"].ToString(),
                Email = r["Email"].ToString(),
                EmployeeNumber = r["EmployeeNumber"].ToString(),
                IdNumber = r["IdNumber"].ToString(),
                HireDate = DateTime.Parse(r["HireDate"].ToString()),
                IsActive = Convert.ToBoolean(r["IsActive"]),
                CreatedAt = DateTime.Parse(r["CreatedAt"].ToString()),
                UpdatedAt = DateTime.Parse(r["UpdatedAt"].ToString())
            };
        }

        private void ShowLoginError(string msg)
        { lblLoginError.Text = "  " + msg; lblLoginError.Visible = true; }

        private void SetLoginBusy(bool b)
        { btnLogin.Enabled = !b; btnLogin.Text = b ? "Verifying..." : "Sign In"; }

        private void SetLoginEnabled(bool en)
        { txtLoginEmail.Enabled = en; txtLoginPassword.Enabled = en; btnLogin.Enabled = en; }

        // ── Register logic ───────────────────────────────────────────────────
        private void BtnEyeRegPassword_Click(object s, EventArgs e)
        {
            _registerPasswordVisible = !_registerPasswordVisible;
            txtRegPassword.UseSystemPasswordChar = !_registerPasswordVisible;
            btnEyeRegPassword.Text = _registerPasswordVisible ? "x" : "o";
        }
        private void BtnEyeRegConfirm_Click(object s, EventArgs e)
        {
            _registerConfirmVisible = !_registerConfirmVisible;
            txtRegConfirm.UseSystemPasswordChar = !_registerConfirmVisible;
            btnEyeRegConfirm.Text = _registerConfirmVisible ? "x" : "o";
        }

        private void BtnRegister_Click(object sender, EventArgs e)
        {
            if (!ValidateRegister()) return;
            try
            {
                InsertEmployee();
                MessageBox.Show(
                    $"Employee \"{txtRegFirstName.Text.Trim()} {txtRegLastName.Text.Trim()}\" registered successfully!\n\nYou can now sign in.",
                    "Registration Successful", MessageBoxButtons.OK, MessageBoxIcon.Information);
                ShowLoginView();
                txtLoginEmail.Text = txtRegUsername.Text.Trim();
                txtLoginPassword.Focus();
            }
            catch (SQLiteException ex) when (ex.Message.Contains("UNIQUE"))
            {
                MessageBox.Show("An employee with this username, email, employee number, or ID already exists.",
                    "Duplicate Entry", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Registration failed:\n\n" + ex.Message,
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private bool ValidateRegister()
        {
            ClearRegisterErrors();
            bool ok = true;

            // First name
            if (!ValidationHelper.IsValidName(txtRegFirstName.Text, out string eFN))
            { SetRegError(lblErrRegFirstName, eFN); ok = false; }

            // Last name
            if (!ValidationHelper.IsValidName(txtRegLastName.Text, out string eLN))
            { SetRegError(lblErrRegLastName, eLN); ok = false; }

            // Username: 6-8 chars, max 2 digits, rest English letters
            if (!ValidationHelper.IsValidUsername(txtRegUsername.Text.Trim(), out string eUN))
            { SetRegError(lblErrRegUsername, eUN); ok = false; }

            // Employee number: exactly 4 digits
            if (!ValidationHelper.IsValidEmployeeNumber(txtRegEmpNum.Text.Trim(), out string eEN))
            { SetRegError(lblErrRegEmpNum, eEN); ok = false; }

            // ID number: Israeli 9-digit Luhn
            if (!ValidationHelper.IsValidIdNumber(txtRegIdNumber.Text.Trim(), out string eID))
            { SetRegError(lblErrRegIdNumber, eID); ok = false; }

            // Email
            if (!ValidationHelper.IsValidEmail(txtRegEmail.Text.Trim(), out string eEM))
            { SetRegError(lblErrRegEmail, eEM); ok = false; }

            // Role
            if (cmbRegRole.SelectedIndex < 0)
            { SetRegError(lblErrRegRole, "Please select a role."); ok = false; }

            // Password: 8-10, letter, digit, special !$#(
            if (!ValidationHelper.IsValidPassword(txtRegPassword.Text, out string ePW))
            { SetRegError(lblErrRegPassword, ePW); ok = false; }

            // Confirm password
            if (txtRegConfirm.Text != txtRegPassword.Text)
            { SetRegError(lblErrRegConfirm, "Passwords do not match."); ok = false; }

            if (!ok)
                MessageBox.Show("Please fix the highlighted fields.",
                    "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return ok;
        }

        private void InsertEmployee()
        {
            const string sql = @"
                INSERT INTO Employees
                    (Username, FirstName, LastName, Role, Phone, Email,
                     EmployeeNumber, IdNumber, HireDate, IsActive, PasswordHash)
                VALUES
                    (@User, @FN, @LN, @Role, @Phone, @Email,
                     @EmpNum, @IdNum, DATE('now'), 1, @Hash);";

            DatabaseHelper.Instance.ExecuteNonQuery(sql,
                new SQLiteParameter("@User", txtRegUsername.Text.Trim()),
                new SQLiteParameter("@FN", txtRegFirstName.Text.Trim()),
                new SQLiteParameter("@LN", txtRegLastName.Text.Trim()),
                new SQLiteParameter("@Role", cmbRegRole.SelectedItem.ToString()),
                new SQLiteParameter("@Phone", txtRegPhone.Text.Trim()),
                new SQLiteParameter("@Email", txtRegEmail.Text.Trim()),
                new SQLiteParameter("@EmpNum", txtRegEmpNum.Text.Trim()),
                new SQLiteParameter("@IdNum", txtRegIdNumber.Text.Trim()),
                new SQLiteParameter("@Hash", HashPassword(txtRegPassword.Text)));
        }

        private void SetRegError(Label lbl, string msg)
        { lbl.Text = "! " + msg; lbl.Visible = true; }

        private void ClearRegisterErrors()
        {
            foreach (var l in new[] {
                lblErrRegFirstName, lblErrRegLastName, lblErrRegUsername,
                lblErrRegEmpNum, lblErrRegIdNumber, lblErrRegEmail,
                lblErrRegPassword, lblErrRegConfirm, lblErrRegRole })
            { if (l != null) { l.Text = ""; l.Visible = false; } }
        }

        private void ClearRegisterForm()
        {
            if (txtRegFirstName != null) txtRegFirstName.Clear();
            if (txtRegLastName != null) txtRegLastName.Clear();
            if (txtRegUsername != null) txtRegUsername.Clear();
            if (txtRegEmpNum != null) txtRegEmpNum.Clear();
            if (txtRegIdNumber != null) txtRegIdNumber.Clear();
            if (txtRegEmail != null) txtRegEmail.Clear();
            if (txtRegPhone != null) txtRegPhone.Clear();
            if (txtRegPassword != null) txtRegPassword.Clear();
            if (txtRegConfirm != null) txtRegConfirm.Clear();
            if (cmbRegRole != null) cmbRegRole.SelectedIndex = -1;
            ClearRegisterErrors();
        }

        // ── SHA-256 ──────────────────────────────────────────────────────────
        private static string HashPassword(string password)
        {
            using (var sha = SHA256.Create())
            {
                byte[] bytes = sha.ComputeHash(Encoding.UTF8.GetBytes(password));
                var sb = new StringBuilder();
                foreach (byte b in bytes) sb.Append(b.ToString("x2"));
                return sb.ToString();
            }
        }

        // ── Private UI helpers ───────────────────────────────────────────────
        private static Label MkCentredLabel(string text, Font font, Color fore,
                                             int w, int h, int x, int y) =>
            new Label
            {
                Text = text,
                Font = font,
                ForeColor = fore,
                AutoSize = false,
                Size = new Size(w, h),
                Location = new Point(x, y),
                TextAlign = ContentAlignment.MiddleCenter,
                BackColor = UITheme.BgCard
            };

        private static Label MkFieldLabel(string text, int x, int y, int w) =>
            new Label
            {
                Text = text,
                Font = new Font("Segoe UI", 8.5f, FontStyle.Bold),
                ForeColor = UITheme.TextSecondary,
                AutoSize = false,
                Size = new Size(w, 18),
                Location = new Point(x, y),
                BackColor = UITheme.BgCard
            };

        private static Panel MkDivider(int x, int y, int w) =>
            new Panel
            {
                Size = new Size(w, 1),
                Location = new Point(x, y),
                BackColor = UITheme.BorderDefault
            };

        private static Label MkErrLabel(int x, int y, int w) =>
            new Label
            {
                Text = "",
                Font = new Font("Segoe UI", 7.8f),
                ForeColor = UITheme.SemanticDanger,
                AutoSize = false,
                Size = new Size(w, 14),
                Location = new Point(x, y),
                BackColor = UITheme.BgCard,
                Visible = false
            };

        private static Button MkEyeBtn(int x, int y) =>
            new Button
            {
                Text = "o",
                Font = new Font("Segoe UI", 9f),
                Size = new Size(34, 30),
                Location = new Point(x, y),
                FlatStyle = FlatStyle.Flat,
                BackColor = Color.White,
                ForeColor = UITheme.TextMuted,
                Cursor = Cursors.Hand,
                TabStop = false
            };

        private static void AddFieldToPanel(Panel panel, string caption,
            int x, int y, int w,
            out Label lbl, out TextBox txt, out Label err)
        {
            lbl = MkFieldLabel(caption, x, y, w);
            txt = new TextBox
            {
                Size = new Size(w, 30),
                Location = new Point(x, y + 20),
                Font = new Font("Segoe UI", 10f),
                BorderStyle = BorderStyle.FixedSingle,
                BackColor = Color.White,
                ForeColor = UITheme.TextPrimary
            };
            err = MkErrLabel(x, y + 52, w);
            panel.Controls.AddRange(new Control[] { lbl, txt, err });
        }
    }
}