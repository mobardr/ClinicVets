using System.Drawing;
using System.Windows.Forms;
using ClinicVets.UI;

namespace ClinicVets.Forms
{
    partial class CustomerForm
    {
        private System.ComponentModel.IContainer components = null;

        private Label lblSearchStatus;
        private Label lblRecordCount;

        // ── Toolbar ───────────────────────────────────
        private Panel pnlToolbar;
        private Label lblPageTitle;
        private Button btnAdd, btnEdit, btnDelete, btnSave, btnCancel, btnViewAnimals;
        private Button btnNew => btnAdd;  // alias

        // ── Search bar ────────────────────────────────
        private Panel pnlSearch;
        private TextBox txtSearchById;
        private Button btnSearchById;
        private TextBox txtSearchByPhone;
        private Button btnSearchByPhone;
        private Button btnClearSearch;

        // ── Split layout ──────────────────────────────
        private Panel pnlMain;
        private Panel pnlLeft;
        private Panel pnlSplitter;
        private Panel pnlRight;

        // ── Grid ──────────────────────────────────────
        private DataGridView dgvCustomers;
        private DataGridViewTextBoxColumn colId;
        private DataGridViewTextBoxColumn colFirstName;
        private DataGridViewTextBoxColumn colLastName;
        private DataGridViewTextBoxColumn colFullName;
        private DataGridViewTextBoxColumn colPhone;
        private DataGridViewTextBoxColumn colEmail;
        private DataGridViewTextBoxColumn colAddress;
        private DataGridViewTextBoxColumn colCity;
        private DataGridViewTextBoxColumn colNationalId;
        private DataGridViewTextBoxColumn colNotes;

        // ── Detail form ───────────────────────────────
        private Panel pnlForm;
        private Label lblFormTitle;
        private Label lblFN, lblLN, lblPhone, lblEmail;
        private Label lblAddress, lblCity, lblNationalId, lblNotes;
        private TextBox txtFirstName, txtLastName, txtPhone, txtEmail;
        private TextBox txtAddress, txtCity, txtNationalId;
        private RichTextBox txtNotes;
        private Label lblErrFirstName, lblErrLastName, lblErrPhone;
        private Label lblErrEmail, lblErrNationalId;

        protected override void Dispose(bool disposing)
        {
            if (disposing && components != null) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {


            // ── Root ──────────────────────────────────
            this.BackColor = UITheme.BgRoot;
            this.Dock = DockStyle.Fill;
            this.Font = UITheme.FontBody;
            this.DoubleBuffered = true;
            this.SetStyle(
                ControlStyles.OptimizedDoubleBuffer |
                ControlStyles.AllPaintingInWmPaint, true);

            // ══════════════════════════════════════════
            //  TOOLBAR  (top bar, no Paint handler)
            // ══════════════════════════════════════════
            pnlToolbar = new Panel
            {
                Dock = DockStyle.Top,
                Height = UITheme.ToolbarH,
                BackColor = UITheme.BgToolbar
            };

            lblPageTitle = new Label
            {
                Text = "Customers",
                Font = UITheme.FontTitle,
                ForeColor = UITheme.TextPrimary,
                AutoSize = false,
                Size = new Size(260, UITheme.ToolbarH),
                Location = new Point(UITheme.SpaceLG, 0),
                TextAlign = System.Drawing.ContentAlignment.MiddleLeft,
                BackColor = UITheme.BgToolbar
            };

            btnAdd = new Button(); UITheme.StylePrimaryBtn(btnAdd, "＋  Add New");
            btnEdit = new Button(); UITheme.StyleSecondaryBtn(btnEdit, "✏  Edit");
            btnDelete = new Button(); UITheme.StyleDangerBtn(btnDelete, "🗑  Delete");
            btnViewAnimals = new Button(); UITheme.StyleSecondaryBtn(btnViewAnimals, "🐾 View Animals");
            btnViewAnimals.Enabled = false;
            btnSave = new Button(); UITheme.StylePrimaryBtn(btnSave, "✔  Save");
            btnCancel = new Button(); UITheme.StyleGhostBtn(btnCancel, "✕  Cancel");

            foreach (var b in new[] { btnAdd, btnEdit, btnDelete, btnViewAnimals, btnSave, btnCancel })
            {
                b.Size = new Size(112, 34);
                b.Anchor = AnchorStyles.Right | AnchorStyles.Top;
                b.TabIndex = 0;
            }

            btnSave.Visible = false;
            btnCancel.Visible = false;

            void PosBtn(Button b, int fromRight)
            {
                b.Location = new Point(pnlToolbar.Width - fromRight, (UITheme.ToolbarH - 34) / 2);
                b.Anchor = AnchorStyles.Right | AnchorStyles.Top;
            }

            pnlToolbar.SizeChanged += (s, e) =>
            {
                PosBtn(btnAdd, 128);
                PosBtn(btnEdit, 248);
                PosBtn(btnDelete, 368);
                PosBtn(btnViewAnimals, 510);
                PosBtn(btnSave, 128);
                PosBtn(btnCancel, 248);
            };

            pnlToolbar.Controls.AddRange(new Control[]
                { lblPageTitle, btnAdd, btnEdit, btnDelete, btnSave, btnCancel });

            // ══════════════════════════════════════════
            //  SEARCH BAR  (no Paint handler)
            // ══════════════════════════════════════════
            pnlSearch = new Panel
            {
                Dock = DockStyle.Top,
                Height = UITheme.SearchBarH,
                BackColor = UITheme.BgSurface
            };

            var lblSId = new Label
            {
                Text = "Search by ID:",
                Font = UITheme.FontLabel,
                ForeColor = UITheme.TextSecondary,
                AutoSize = false,
                Size = new Size(90, UITheme.SearchBarH),
                Location = new Point(UITheme.SpaceLG, 0),
                TextAlign = System.Drawing.ContentAlignment.MiddleRight,
                BackColor = UITheme.BgSurface
            };

            txtSearchById = new TextBox
            {
                Size = new Size(160, UITheme.InputH),
                Location = new Point(118, (UITheme.SearchBarH - UITheme.InputH) / 2),
                Font = UITheme.FontInput,
                BorderStyle = BorderStyle.FixedSingle,
                BackColor = UITheme.BgInput,
                ForeColor = UITheme.TextPrimary,
            };

            btnSearchById = new Button();
            UITheme.StyleSecondaryBtn(btnSearchById, "Search");
            btnSearchById.Size = new Size(76, UITheme.InputH);
            btnSearchById.Location = new Point(286, (UITheme.SearchBarH - UITheme.InputH) / 2);

            var lblSPh = new Label
            {
                Text = "Phone:",
                Font = UITheme.FontLabel,
                ForeColor = UITheme.TextSecondary,
                AutoSize = false,
                Size = new Size(52, UITheme.SearchBarH),
                Location = new Point(374, 0),
                TextAlign = System.Drawing.ContentAlignment.MiddleRight,
                BackColor = UITheme.BgSurface
            };

            txtSearchByPhone = new TextBox
            {
                Size = new Size(160, UITheme.InputH),
                Location = new Point(434, (UITheme.SearchBarH - UITheme.InputH) / 2),
                Font = UITheme.FontInput,
                BorderStyle = BorderStyle.FixedSingle,
                BackColor = UITheme.BgInput,
                ForeColor = UITheme.TextPrimary,
            };

            btnSearchByPhone = new Button();
            UITheme.StyleSecondaryBtn(btnSearchByPhone, "Search");
            btnSearchByPhone.Size = new Size(76, UITheme.InputH);
            btnSearchByPhone.Location = new Point(602, (UITheme.SearchBarH - UITheme.InputH) / 2);

            btnClearSearch = new Button();
            UITheme.StyleGhostBtn(btnClearSearch, "✕  Clear");
            btnClearSearch.Size = new Size(86, UITheme.InputH);
            btnClearSearch.Location = new Point(688, (UITheme.SearchBarH - UITheme.InputH) / 2);

            lblSearchStatus = new Label
            {
                Text = "",
                Font = UITheme.FontLabel,
                ForeColor = UITheme.TextMuted,
                AutoSize = false,
                Size = new Size(200, UITheme.SearchBarH),
                Location = new Point(786, 0),
                TextAlign = System.Drawing.ContentAlignment.MiddleLeft,
                BackColor = UITheme.BgSurface
            };
            lblRecordCount = new Label
            {
                Text = "",
                Font = UITheme.FontLabel,
                ForeColor = UITheme.Accent,
                AutoSize = false,
                Size = new Size(120, UITheme.SearchBarH),
                Location = new Point(990, 0),
                TextAlign = System.Drawing.ContentAlignment.MiddleLeft,
                BackColor = UITheme.BgSurface
            };

            pnlSearch.Controls.AddRange(new Control[]
            {
                lblSId, txtSearchById, btnSearchById,
                lblSPh, txtSearchByPhone, btnSearchByPhone, btnClearSearch,
                lblSearchStatus, lblRecordCount
            });

            // ══════════════════════════════════════════
            //  MAIN CONTENT  (grid | splitter | form)
            // ══════════════════════════════════════════
            pnlMain = new Panel { Dock = DockStyle.Fill, BackColor = UITheme.BgRoot };

            // Grid column
            pnlLeft = new Panel
            {
                Dock = DockStyle.Left,
                Width = 620,
                BackColor = UITheme.BgSurface
            };
            pnlMain.Resize += (s, e) =>
            {
                if (pnlMain.Width < 1) return;
                int lw = System.Math.Max(620, System.Math.Min(
                    (int)(pnlMain.Width * 0.58f), pnlMain.Width - 280));
                pnlLeft.Width = lw;
            };

            dgvCustomers = new DataGridView { Dock = DockStyle.Fill };
            UITheme.StyleGrid(dgvCustomers);

            colId = MakeCol("colId", "ID", 50, false);
            colFullName = MakeCol("colFullName", "Full Name", 160, true);
            colPhone = MakeCol("colPhone", "Phone", 130, true);
            colEmail = MakeCol("colEmail", "Email", 180, true);
            colCity = MakeCol("colCity", "City", 100, true);
            colNationalId = MakeCol("colNationalId", "National ID", 110, true);
            colFirstName = MakeCol("colFirstName", "First Name", 0, false);
            colLastName = MakeCol("colLastName", "Last Name", 0, false);
            colAddress = MakeCol("colAddress", "Address", 0, false);
            colNotes = MakeCol("colNotes", "Notes", 0, false);

            dgvCustomers.Columns.AddRange(new DataGridViewColumn[]
            {
                colId, colFullName, colPhone, colEmail, colCity, colNationalId,
                colFirstName, colLastName, colAddress, colNotes
            });

            pnlLeft.Controls.Add(dgvCustomers);

            // Splitter
            pnlSplitter = new Panel
            {
                Dock = DockStyle.Left,
                Width = 1,
                BackColor = UITheme.BorderDefault
            };

            // Detail form panel
            pnlRight = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = UITheme.BgSurface
            };

            // Scroll container for the form
            pnlForm = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = UITheme.BgSurface,
                AutoScroll = true,
                Padding = new Padding(UITheme.SpaceLG)
            };

            lblFormTitle = new Label
            {
                Text = "Customer Details",
                Font = UITheme.FontSubtitle,
                ForeColor = UITheme.TextPrimary,
                AutoSize = false,
                Size = new Size(340, 32),
                Location = new Point(0, 0),
                BackColor = UITheme.BgSurface
            };

            int fy = 40, fw = 340;

            (lblFN, txtFirstName, lblErrFirstName) = MakeField("First Name *", 0, fy, fw); fy += 62;
            (lblLN, txtLastName, lblErrLastName) = MakeField("Last Name *", 0, fy, fw); fy += 62;
            (lblNationalId, txtNationalId, lblErrNationalId) = MakeField("National ID *", 0, fy, fw); fy += 62;
            (lblPhone, txtPhone, lblErrPhone) = MakeField("Phone Number *", 0, fy, fw); fy += 62;
            (lblEmail, txtEmail, lblErrEmail) = MakeField("Email Address", 0, fy, fw); fy += 62;
            (lblAddress, txtAddress, _) = MakeField("Address", 0, fy, fw); fy += 62;
            (lblCity, txtCity, _) = MakeField("City", 0, fy, fw); fy += 62;

            lblNotes = new Label
            {
                Text = "Notes",
                Font = UITheme.FontLabel,
                ForeColor = UITheme.TextSecondary,
                AutoSize = false,
                Size = new Size(fw, 18),
                Location = new Point(0, fy),
                BackColor = UITheme.BgSurface
            };
            fy += 20;

            txtNotes = new RichTextBox
            {
                Size = new Size(fw, 80),
                Location = new Point(0, fy),
                Font = UITheme.FontInput,
                BorderStyle = BorderStyle.FixedSingle,
                BackColor = UITheme.BgInput,
                ForeColor = UITheme.TextPrimary,
                ScrollBars = RichTextBoxScrollBars.Vertical
            };

            pnlForm.Controls.AddRange(new Control[]
            {
                lblFormTitle,
                lblFN, txtFirstName, lblErrFirstName,
                lblLN, txtLastName, lblErrLastName,
                lblNationalId, txtNationalId, lblErrNationalId,
                lblPhone, txtPhone, lblErrPhone,
                lblEmail, txtEmail, lblErrEmail,
                lblAddress, txtAddress,
                lblCity, txtCity,
                lblNotes, txtNotes
            });

            pnlRight.Controls.Add(pnlForm);

            pnlMain.Controls.Add(pnlRight);
            pnlMain.Controls.Add(pnlSplitter);
            pnlMain.Controls.Add(pnlLeft);

            this.Controls.AddRange(new Control[] { pnlMain, pnlSearch, pnlToolbar });
        }

        // ─────────────────────────────────────────────
        private static DataGridViewTextBoxColumn MakeCol(
            string name, string header, int minW, bool visible)
        {
            return new DataGridViewTextBoxColumn
            {
                Name = name,
                HeaderText = header,
                MinimumWidth = minW > 0 ? minW : 40,
                Visible = visible,
                SortMode = DataGridViewColumnSortMode.Automatic,
                Resizable = DataGridViewTriState.True
            };
        }

        private static (Label lbl, TextBox txt, Label err) MakeField(
            string label, int x, int y, int w)
        {
            var lbl = new Label
            {
                Text = label,
                Font = UITheme.FontLabel,
                ForeColor = UITheme.TextSecondary,
                AutoSize = false,
                Size = new Size(w, 18),
                Location = new Point(x, y),
                BackColor = UITheme.BgSurface
            };
            var txt = new TextBox
            {
                Size = new Size(w, UITheme.InputH),
                Location = new Point(x, y + 20),
                Font = UITheme.FontInput,
                BorderStyle = BorderStyle.FixedSingle,
                BackColor = UITheme.BgInput,
                ForeColor = UITheme.TextPrimary
            };
            var err = new Label
            {
                Text = "",
                Font = new Font("Segoe UI", 7.8f),
                ForeColor = UITheme.SemanticDanger,
                AutoSize = false,
                Size = new Size(w, 14),
                Location = new Point(x, y + 20 + UITheme.InputH + 1),
                BackColor = UITheme.BgSurface,
                Visible = false
            };
            return (lbl, txt, err);
        }

        private sealed class BufferedPanel : Panel
        {
            public BufferedPanel()
            {
                this.SetStyle(
                    ControlStyles.OptimizedDoubleBuffer |
                    ControlStyles.AllPaintingInWmPaint |
                    ControlStyles.ResizeRedraw |
                    ControlStyles.UserPaint, true);
                this.UpdateStyles();
            }
        }
    }
}