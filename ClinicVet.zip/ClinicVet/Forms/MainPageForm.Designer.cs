using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
using ClinicVets.UI;

namespace ClinicVets.Forms
{
    partial class MainPageForm
    {
        private System.ComponentModel.IContainer components = null;

        // ── Palette constants (used in both InitializeComponent and MainPageForm.cs)
        internal static readonly Color clrAccent = UITheme.AccentViolet;
        internal static readonly Color clrAccentSoft = UITheme.AccentHover;
        internal static readonly Color clrText = UITheme.TextPrimary;
        internal static readonly Color clrBtnOutlineBg = UITheme.BgCard;

        // ── Navbar ────────────────────────────────────
        private Button btnSignIn;
        private Button btnRegister;
        private FlowLayoutPanel pnlNavRight;

        // ── Three view panels ─────────────────────────
        private Panel pnlWelcome;    // hero / landing card
        private Panel pnlAuthLogin;  // sign-in form
        private Panel pnlAuthReg;    // register form
        private Panel pnlLoginCard;  // login inner card
        private Panel pnlRegCard;    // register inner card

        // ── Welcome card (inside pnlWelcome) ──────────
        private Panel pnlCentreCard;
        private Panel pnlTopBar;

        // ── Login panel controls ──────────────────────
        private TextBox txtLoginEmail;
        private TextBox txtLoginPw;
        private Button btnEyeLogin;
        private Label lblLoginError;
        private Button btnDoLogin;
        private Label lnkGoRegister;
        private Label lnkBackFromLogin;

        // ── Register panel controls ───────────────────
        private TextBox txtRegFirstName;
        private TextBox txtRegLastName;
        private TextBox txtRegUsername;
        private TextBox txtRegEmpNum;
        private TextBox txtRegIdNumber;
        private ComboBox cmbRegRole;
        private TextBox txtRegPhone;
        private TextBox txtRegEmail;
        private TextBox txtRegPw;
        private Button btnEyeRegPw;
        private TextBox txtRegConfirm;
        private Button btnEyeRegConfirm;
        private Button btnDoRegister;
        private Label lnkGoLogin;
        private Label lnkBackFromReg;

        // ── Register error labels ─────────────────────
        private Label lblErrRegFN;
        private Label lblErrRegLN;
        private Label lblErrRegUsername;
        private Label lblErrRegEmpNum;
        private Label lblErrRegIdNumber;
        private Label lblErrRegRole;
        private Label lblErrRegEmail;
        private Label lblErrRegPw;
        private Label lblErrRegConfirm;

        // ─────────────────────────────────────────────
        protected override void Dispose(bool disposing)
        {
            if (disposing && components != null) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            // ── Palette ───────────────────────────────
            var clrBg = UITheme.BgRoot;   // deep navy root
            var clrCard = UITheme.BgCard;   // card surface
            var clrCardBorder = UITheme.BorderDefault;   // card border
            var clrAccent = UITheme.AccentViolet;   // indigo
            var clrAccentSoft = UITheme.AccentHover;   // indigo hover
            var clrText = UITheme.TextPrimary;   // primary text
            var clrMuted = UITheme.TextMuted;   // muted text
            var clrSubtle = UITheme.TextMuted;   // very muted

            // ══════════════════════════════════════════
            //  FORM
            // ══════════════════════════════════════════
            this.Text = "ClinicVets - Veterinary Clinic Management";
            this.Size = new Size(1280, 800);
            this.MinimumSize = new Size(900, 600);
            this.FormBorderStyle = FormBorderStyle.Sizable;
            this.MaximizeBox = true;
            this.WindowState = FormWindowState.Maximized;
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = clrBg;

            // Decorative background - warm circles and shapes
            this.Paint += delegate (object s2, System.Windows.Forms.PaintEventArgs pe)
            {
                var g = pe.Graphics;
                g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
                int W = this.ClientSize.Width;
                int H = this.ClientSize.Height;

                // Large soft circle top-right
                using (var br = new System.Drawing.SolidBrush(System.Drawing.Color.FromArgb(18, 217, 119, 86)))
                    g.FillEllipse(br, W - 320, -120, 400, 400);

                // Medium circle bottom-left
                using (var br = new System.Drawing.SolidBrush(System.Drawing.Color.FromArgb(14, 217, 119, 86)))
                    g.FillEllipse(br, -100, H - 280, 360, 360);

                // Small accent circle top-left
                using (var br = new System.Drawing.SolidBrush(System.Drawing.Color.FromArgb(20, 61, 53, 40)))
                    g.FillEllipse(br, 60, 80, 120, 120);

                // Tiny dots scattered
                using (var br = new System.Drawing.SolidBrush(System.Drawing.Color.FromArgb(25, 217, 119, 86)))
                {
                    g.FillEllipse(br, W - 80, H / 2, 24, 24);
                    g.FillEllipse(br, W - 140, H / 2 + 60, 14, 14);
                    g.FillEllipse(br, 40, H / 3, 18, 18);
                    g.FillEllipse(br, W / 4, H - 60, 20, 20);
                }

                // Subtle horizontal line near top
                using (var pen = new System.Drawing.Pen(System.Drawing.Color.FromArgb(30, 217, 119, 86), 1))
                    g.DrawLine(pen, 0, this.ClientSize.Height - 3, W, this.ClientSize.Height - 3);
            };
            this.Font = new Font("Segoe UI", 9.5f);
            this.DoubleBuffered = true;
            this.AutoScroll = false;


            // ══════════════════════════════════════════
            //  NAVBAR - clean professional top bar
            // ══════════════════════════════════════════
            pnlTopBar = new Panel
            {
                Dock = DockStyle.Top,
                Height = 72,
                BackColor = UITheme.BgRoot
            };
            // Bottom accent bar - solid panel, no Paint handler needed
            var pnlTopAccent = new Panel
            {
                Dock = DockStyle.Bottom,
                Height = 2,
                BackColor = clrAccent
            };
            pnlTopBar.Controls.Add(pnlTopAccent);

            // ── Logo / brand (left) ───────────────────
            var pnlBrandLeft = new Panel
            {
                Size = new Size(340, 72),
                Location = new Point(0, 0),
                BackColor = UITheme.BgRoot
            };

            var lblPawLogo = new Label
            {
                Text = "🐾",
                Font = new Font("Segoe UI Emoji", 22f),
                AutoSize = false,
                Size = new Size(46, 72),
                Location = new Point(24, 0),
                TextAlign = ContentAlignment.MiddleCenter,
                BackColor = UITheme.BgRoot
            };

            var lblBrand = new Label
            {
                Text = "ClinicVets",
                Font = new Font("Segoe UI", 15f, FontStyle.Bold),
                ForeColor = clrText,
                AutoSize = false,
                Size = new Size(160, 40),
                Location = new Point(76, 8),
                TextAlign = ContentAlignment.BottomLeft,
                BackColor = UITheme.BgRoot
            };

            var lblTagline = new Label
            {
                Text = "Veterinary Clinic Management",
                Font = new Font("Segoe UI", 8f),
                ForeColor = UITheme.TextMuted,
                AutoSize = false,
                Size = new Size(220, 22),
                Location = new Point(77, 46),
                TextAlign = ContentAlignment.TopLeft,
                BackColor = UITheme.BgRoot
            };

            pnlBrandLeft.Controls.AddRange(new Control[] { lblPawLogo, lblBrand, lblTagline });

            // ── Nav buttons (right) ───────────────────
            pnlNavRight = new FlowLayoutPanel
            {
                Dock = DockStyle.Right,
                Width = 290,
                Height = 72,
                BackColor = UITheme.BgRoot,
                FlowDirection = FlowDirection.LeftToRight,
                Padding = new Padding(0, 17, 28, 0),
                WrapContents = false
            };

            btnSignIn = new Button
            {
                Text = "Sign In",
                Font = new Font("Segoe UI", 10f, FontStyle.Bold),
                Size = new Size(116, 38),
                FlatStyle = FlatStyle.Flat,
                BackColor = UITheme.BgCard,
                ForeColor = clrText,
                Cursor = Cursors.Hand,
                Margin = new Padding(0, 0, 12, 0)
            };
            btnSignIn.FlatAppearance.BorderColor = clrAccent;
            btnSignIn.FlatAppearance.BorderSize = 1;
            btnSignIn.FlatAppearance.MouseOverBackColor = UITheme.BorderDefault;
            btnSignIn.MouseEnter += (s, e) => { btnSignIn.ForeColor = UITheme.TextPrimary; };
            btnSignIn.MouseLeave += (s, e) => { btnSignIn.ForeColor = clrText; };

            btnRegister = new Button
            {
                Text = "Register",
                Font = new Font("Segoe UI", 10f, FontStyle.Bold),
                Size = new Size(116, 38),
                FlatStyle = FlatStyle.Flat,
                BackColor = clrAccent,
                ForeColor = UITheme.TextPrimary,
                Cursor = Cursors.Hand,
                Margin = new Padding(0)
            };
            btnRegister.FlatAppearance.BorderSize = 0;
            btnRegister.FlatAppearance.MouseOverBackColor = clrAccentSoft;
            btnRegister.MouseEnter += (s, e) => btnRegister.BackColor = clrAccentSoft;
            btnRegister.MouseLeave += (s, e) => btnRegister.BackColor = clrAccent;

            pnlNavRight.Controls.AddRange(new Control[] { btnSignIn, btnRegister });
            pnlTopBar.Controls.AddRange(new Control[] { pnlBrandLeft, pnlNavRight });

            // ══════════════════════════════════════════
            //  CENTRE CARD - big, prominent, professional
            // ══════════════════════════════════════════
            pnlCentreCard = new BufferedPanel
            {
                Size = new Size(760, 420),
                BackColor = UITheme.BgCard
            };

            // Card paint: multi-layer border + top accent

            // ── Paw icon ──────────────────────────────
            var lblCardIcon = new Label
            {
                Text = "🐾",
                Font = new Font("Segoe UI Emoji", 58f),
                AutoSize = false,
                Size = new Size(760, 120),
                Location = new Point(0, 30),
                TextAlign = ContentAlignment.MiddleCenter,
                Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right,
                BackColor = UITheme.BgCard
            };

            // ── Main title ────────────────────────────
            var lblWelcome = new Label
            {
                Text = "Welcome to ClinicVets",
                Font = new Font("Segoe UI", 30f, FontStyle.Bold),
                ForeColor = clrText,
                AutoSize = false,
                Size = new Size(760, 62),
                Location = new Point(0, 152),
                TextAlign = ContentAlignment.MiddleCenter,
                Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right,
                BackColor = UITheme.BgCard
            };

            // ── Professional subtitle ─────────────────
            var lblSubtitle = new Label
            {
                Text = "Smart Veterinary Clinic Management System",
                Font = new Font("Segoe UI", 13f),
                ForeColor = UITheme.AccentViolet,
                AutoSize = false,
                Size = new Size(760, 30),
                Location = new Point(0, 216),
                TextAlign = ContentAlignment.MiddleCenter,
                Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right,
                BackColor = UITheme.BgCard
            };

            // ── Thin divider ──────────────────────────
            var pnlCardDiv = new Panel
            {
                Size = new Size(280, 1),
                Location = new Point(240, 258),
                BackColor = UITheme.BorderDefault
            };

            // ── Description text ──────────────────────
            var lblDesc = new Label
            {
                Text = "Manage patients, visits, medicines and your team\n" +
                            "from one professional platform.",
                Font = new Font("Segoe UI", 10f),
                ForeColor = UITheme.TextMuted,
                AutoSize = false,
                Size = new Size(760, 52),
                Location = new Point(0, 270),
                TextAlign = ContentAlignment.MiddleCenter,
                BackColor = UITheme.BgCard
            };

            // ── Feature badges row ────────────────────
            var featureDefs = new[]
            {
                ("🐕", "Patients"),
                ("📋", "Visits"),
                ("💊", "Medicines"),
                ("👨‍⚕️", "Staff")
            };

            int badgeY = 334;
            int badgeW = 120;
            int badgeH = 32;
            int totalBW = featureDefs.Length * badgeW + (featureDefs.Length - 1) * 12;
            int badgeStartX = (720 - totalBW) / 2;

            for (int i = 0; i < featureDefs.Length; i++)
            {
                var (bIcon, bText) = featureDefs[i];
                int bx = badgeStartX + i * (badgeW + 12);

                var badge = new Panel
                {
                    Size = new Size(badgeW, badgeH),
                    Location = new Point(bx, badgeY),
                    BackColor = UITheme.AccentVioletDim
                };

                badge.Paint += (s2, pe2) =>
                {
                    var bp = new Pen(UITheme.BorderDefault, 1);
                    pe2.Graphics.DrawRectangle(bp, 0, 0, badge.Width - 1, badge.Height - 1);
                };

                var badgeLbl = new Label
                {
                    Text = $"{bIcon}  {bText}",
                    Font = new Font("Segoe UI", 8.5f),
                    ForeColor = UITheme.TextMuted,
                    AutoSize = false,
                    Size = new Size(badgeW, badgeH),
                    TextAlign = ContentAlignment.MiddleCenter,
                    BackColor = UITheme.AccentSoft
                };

                badge.Controls.Add(badgeLbl);
                pnlCentreCard.Controls.Add(badge);
            }

            // ── Hint text to use top-right buttons ───
            var lblHint = new Label
            {
                Text = "Use the Sign In or Register buttons in the top-right corner to get started.",
                Font = new Font("Segoe UI", 8f, FontStyle.Italic),
                ForeColor = UITheme.BorderDefault,
                AutoSize = false,
                Size = new Size(720, 22),
                Location = new Point(0, 374),
                TextAlign = ContentAlignment.MiddleCenter,
                BackColor = UITheme.BgCard
            };

            pnlCentreCard.Controls.AddRange(new Control[]
            {
                lblCardIcon, lblWelcome, lblSubtitle,
                pnlCardDiv, lblDesc, lblHint
            });

            // -- Wrap centre card in pnlWelcome --------
            pnlWelcome = new BufferedPanel { BackColor = UITheme.BgRoot };
            pnlWelcome.Controls.Add(pnlCentreCard);

            // Card: fixed elegant size, perfectly centered
            int _cardW = 760;
            int _cardH = 420;
            Panel _pw = pnlWelcome; Panel _pc = pnlCentreCard;
            EventHandler centreCard = delegate (object s2, System.EventArgs e2)
            {
                if (_pw.Width < 1 || _pw.Height < 1) return;
                _pc.Size = new System.Drawing.Size(_cardW, _cardH);
                _pc.Location = new System.Drawing.Point(
                    (_pw.Width - _cardW) / 2,
                    (_pw.Height - _cardH) / 2);
                // Keep all full-width children at card width
                foreach (System.Windows.Forms.Control child in _pc.Controls)
                    if (child.Location.X == 0 && child.Tag == null)
                        child.Width = _cardW;
            };
            pnlWelcome.Resize += centreCard;

            // ══════════════════════════════════════════
            //  LOGIN PANEL - same card style as welcome
            // ══════════════════════════════════════════
            pnlAuthLogin = new BufferedPanel { BackColor = UITheme.BgRoot, Visible = false };

            pnlLoginCard = new BufferedPanel { Size = new Size(520, 480), BackColor = UITheme.BgCard };
            pnlLoginCard.Paint += delegate (object s2, System.Windows.Forms.PaintEventArgs pe)
            {
                pe.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
                using (var pen = new System.Drawing.Pen(UITheme.BorderDefault, 1))
                    pe.Graphics.DrawRectangle(pen, 0, 0, pnlLoginCard.Width - 1, pnlLoginCard.Height - 1);
            };

            // Top accent stripe
            var pnlLoginAccent = new System.Windows.Forms.Panel
            {
                Size = new System.Drawing.Size(520, 4),
                Location = new System.Drawing.Point(0, 0),
                BackColor = UITheme.Accent
            };

            // Title
            var lblLoginTitle = MakeCardLabel("Welcome back", 520, 36f, FontStyle.Bold, clrText, 0, 26);
            var lblLoginSub = MakeCardLabel("Sign in with your username and password", 520, 10f, FontStyle.Regular,
                UITheme.TextMuted, 0, 70);

            // Username
            var lblEmailLbl = MakeFieldLabel("Username", 60, 108, 400);
            txtLoginEmail = MakeInput(60, 126, 400, 34, "Enter your username");

            // Password
            var lblPwLbl = MakeFieldLabel("Password", 60, 176, 400);
            txtLoginPw = MakeInput(60, 194, 364, 34, "Enter your password");
            txtLoginPw.UseSystemPasswordChar = true;
            btnEyeLogin = MakeEyeBtn(428, 194);

            // Error
            lblLoginError = new Label
            {
                Text = "",
                Font = new Font("Segoe UI", 8.5f),
                ForeColor = UITheme.SemanticDanger,
                AutoSize = false,
                Size = new Size(400, 30),
                Location = new Point(60, 238),
                Visible = false,
                BackColor = UITheme.BgCard
            };

            // Sign In button
            btnDoLogin = MakePrimaryBtn("Sign In", 60, 280, 400, 44);

            // Divider
            var pnlLD = new Panel { Size = new Size(400, 1), Location = new Point(60, 340), BackColor = UITheme.BorderDefault };
            var lblLDOr = new Label
            {
                Text = "or",
                Font = new Font("Segoe UI", 8f),
                ForeColor = UITheme.BorderSubtle,
                AutoSize = false,
                Size = new Size(28, 12),
                Location = new Point(246, 334),
                TextAlign = ContentAlignment.MiddleCenter,
                BackColor = UITheme.BgSurface
            };

            // Links
            lnkGoRegister = MakeLink("New employee? Register here →", 0, 356, 520);
            lnkBackFromLogin = MakeLink("← Back to Home", 0, 384, 520);
            lnkBackFromLogin.ForeColor = UITheme.BorderDefault;
            lnkBackFromLogin.Font = new Font("Segoe UI", 8f, FontStyle.Regular);

            // Version
            var lblLVer = MakeCardLabel("ClinicVets v1.0  •  © 2025", 520, 7.5f, FontStyle.Regular,
                UITheme.BorderDefault, 0, 432);

            pnlLoginCard.Controls.AddRange(new Control[]
            {
                pnlLoginAccent, lblLoginTitle, lblLoginSub,
                lblEmailLbl, txtLoginEmail,
                lblPwLbl, txtLoginPw, btnEyeLogin,
                lblLoginError, btnDoLogin,
                pnlLD, lblLDOr,
                lnkGoRegister, lnkBackFromLogin, lblLVer
            });

            pnlAuthLogin.Controls.Add(pnlLoginCard);

            // Centring handled by CentreAuthCard() via SizePanels()

            // ══════════════════════════════════════════
            //  REGISTER PANEL
            // ══════════════════════════════════════════
            pnlAuthReg = new BufferedPanel { BackColor = UITheme.BgRoot, Visible = false };

            pnlRegCard = new BufferedPanel { Size = new Size(540, 720), BackColor = UITheme.BgCard };
            pnlRegCard.Paint += delegate (object s2, System.Windows.Forms.PaintEventArgs pe)
            {
                pe.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
                using (var pen = new System.Drawing.Pen(UITheme.BorderDefault, 1))
                    pe.Graphics.DrawRectangle(pen, 0, 0, pnlRegCard.Width - 1, pnlRegCard.Height - 1);
            };

            var pnlRegAccent = new System.Windows.Forms.Panel
            {
                Size = new System.Drawing.Size(540, 4),
                Location = new System.Drawing.Point(0, 0),
                BackColor = UITheme.Accent
            };

            var lblRegTitle = MakeCardLabel("Create Account", 540, 32f, FontStyle.Bold, clrText, 0, 22);
            var lblRegSub = MakeCardLabel("Register a new ClinicVets employee", 540, 10f, FontStyle.Regular,
                UITheme.TextMuted, 0, 62);

            // Row 1: First | Last
            int rx = 48, rw2 = 214, ry = 100;  // centered: (540-444)/2=48
            MakeRegRow(out var lFN, out txtRegFirstName, out lblErrRegFN, "First Name *", rx, ry, rw2);
            MakeRegRow(out var lLN, out txtRegLastName, out lblErrRegLN, "Last Name *", rx + rw2 + 16, ry, rw2);
            ry += 72;

            // Row 2: Username | Employee Number
            MakeRegRow(out var lUN, out txtRegUsername, out lblErrRegUsername, "Username (6-8 chars)", rx, ry, rw2);
            MakeRegRow(out var lEN, out txtRegEmpNum, out lblErrRegEmpNum, "Employee No. (4 digits)", rx + rw2 + 16, ry, rw2);
            ry += 72;

            // Row 3: ID Number | Phone
            MakeRegRow(out var lID, out txtRegIdNumber, out lblErrRegIdNumber, "ID Number (9 digits)", rx, ry, rw2);
            MakeRegRow(out var lPH2, out txtRegPhone, out _, "Phone", rx + rw2 + 16, ry, rw2);
            ry += 72;

            // Row: Role
            var lblRoleLbl = MakeFieldLabel("Role *", rx, ry, rw2);
            cmbRegRole = new ComboBox
            {
                Size = new Size(rw2, 34),
                Location = new Point(rx, ry + 18),
                FlatStyle = FlatStyle.Flat,
                BackColor = UITheme.BgInput,
                ForeColor = clrText,
                Font = new Font("Segoe UI", 10f),
                DropDownStyle = ComboBoxStyle.DropDownList
            };
            cmbRegRole.Items.AddRange(new object[] { "Secretary", "Veterinarian" });
            lblErrRegRole = MakeErrLbl(rx, ry + 54, rw2);

            ry += 72;

            // Row 3: Email full width
            var lblEmailR = MakeFieldLabel("Email Address *", rx, ry, rw2 * 2 + 16);
            txtRegEmail = MakeInput(rx, ry + 18, rw2 * 2 + 16, 34, "your.email@clinicvets.com");
            lblErrRegEmail = MakeErrLbl(rx, ry + 54, rw2 * 2 + 16);
            ry += 72;

            // Row 4: Password | Confirm
            var lblPwR = MakeFieldLabel("Password *", rx, ry, rw2);
            txtRegPw = MakeInput(rx, ry + 18, rw2 - 36, 34, "8-10 chars");
            txtRegPw.UseSystemPasswordChar = true;
            btnEyeRegPw = MakeEyeBtn(rx + rw2 - 32, ry + 18);
            lblErrRegPw = MakeErrLbl(rx, ry + 54, rw2);

            var lblConR = MakeFieldLabel("Confirm Password *", rx + rw2 + 16, ry, rw2);
            txtRegConfirm = MakeInput(rx + rw2 + 16, ry + 18, rw2 - 36, 34, "Repeat password");
            txtRegConfirm.UseSystemPasswordChar = true;
            btnEyeRegConfirm = MakeEyeBtn(rx + rw2 * 2 + 16 - 32, ry + 18);
            lblErrRegConfirm = MakeErrLbl(rx + rw2 + 16, ry + 54, rw2);
            ry += 72;

            // Register button - green
            btnDoRegister = new Button
            {
                Text = "✔  Create Account",
                Font = new Font("Segoe UI", 10.5f, FontStyle.Bold),
                Size = new Size(468, 44),
                Location = new Point(rx, ry),
                FlatStyle = FlatStyle.Flat,
                BackColor = UITheme.AccentDim,
                ForeColor = UITheme.Accent,
                Cursor = Cursors.Hand
            };
            btnDoRegister.FlatAppearance.BorderColor = UITheme.AccentSoft;
            btnDoRegister.FlatAppearance.BorderSize = 1;
            btnDoRegister.MouseEnter += (s, e) => btnDoRegister.BackColor = UITheme.AccentSoft;
            btnDoRegister.MouseLeave += (s, e) => btnDoRegister.BackColor = UITheme.AccentDim;
            ry += 54;

            lnkGoLogin = MakeLink("← Already have an account? Sign In", 0, ry, 540);
            lnkBackFromReg = MakeLink("← Back to Home", 0, ry + 24, 540);
            lnkBackFromReg.ForeColor = UITheme.BorderDefault;
            lnkBackFromReg.Font = new Font("Segoe UI", 8f, FontStyle.Regular);

            var lblRVer = MakeCardLabel("ClinicVets v1.0  •  © 2025", 540, 7.5f, FontStyle.Regular,
                UITheme.BorderDefault, 0, 512);

            pnlRegCard.Controls.AddRange(new Control[]
            {
                pnlRegAccent, lblRegTitle, lblRegSub,
                lFN, txtRegFirstName, lblErrRegFN,
                lLN, txtRegLastName,  lblErrRegLN,
                lUN, txtRegUsername,  lblErrRegUsername,
                lEN, txtRegEmpNum,    lblErrRegEmpNum,
                lID, txtRegIdNumber,  lblErrRegIdNumber,
                lPH2, txtRegPhone,
                lblRoleLbl, cmbRegRole, lblErrRegRole,
                lPH2, txtRegPhone,
                lblEmailR, txtRegEmail, lblErrRegEmail,
                lblPwR, txtRegPw, btnEyeRegPw, lblErrRegPw,
                lblConR, txtRegConfirm, btnEyeRegConfirm, lblErrRegConfirm,
                btnDoRegister, lnkGoLogin, lnkBackFromReg, lblRVer
            });

            pnlAuthReg.Controls.Add(pnlRegCard);

            // Centring handled by CentreAuthCard() via SizePanels()
            // ══════════════════════════════════════════
            // Keep all view panels full-size matching the content area
            void SizePanels()
            {
                int w = this.ClientSize.Width;
                int topH = pnlTopBar.Height;
                int h = Math.Max(1, this.ClientSize.Height - topH);
                this.SuspendLayout();
                foreach (var p in new[] { pnlWelcome, pnlAuthLogin, pnlAuthReg })
                {
                    p.Size = new Size(w, h);
                    p.Location = new Point(0, topH);
                }
                this.ResumeLayout(false);
                CentreAuthCard();
            }
            this.Resize += (s, e) => SizePanels();
            this.Load += (s, e) => SizePanels();

            this.Controls.Add(pnlTopBar);     // DockStyle.Top - must be added early
            this.Controls.Add(pnlAuthReg);
            this.Controls.Add(pnlAuthLogin);
            this.Controls.Add(pnlWelcome);
        }

        // ─────────────────────────────────────────────
        //  Helper: centre auth card (called from MainPageForm.cs)
        // ─────────────────────────────────────────────
        internal void CentreAuthCard()
        {
            if (pnlLoginCard != null && pnlAuthLogin.Width > 0)
            {
                // Fixed card width 520px - just centre it
                pnlLoginCard.Width = 520;
                pnlLoginCard.Height = 480;
                pnlLoginCard.Location = new Point(
                    (pnlAuthLogin.Width - 520) / 2,
                    Math.Max(20, (pnlAuthLogin.Height - 480) / 2));
            }
            if (pnlRegCard != null && pnlAuthReg.Width > 0)
            {
                // Fixed card width 540px - just centre it
                pnlRegCard.Width = 540;
                pnlRegCard.Height = 720;
                pnlRegCard.Location = new Point(
                    (pnlAuthReg.Width - 540) / 2,
                    Math.Max(20, (pnlAuthReg.Height - 600) / 2));
            }
        }

        // ─────────────────────────────────────────────
        //  Factory helpers
        // ─────────────────────────────────────────────
        private static Label MakeCardLabel_Root(string text, int w, float sz,
            FontStyle fs, Color fore, int x, int y) =>
            new Label
            {
                Text = text,
                Font = new Font("Segoe UI", sz, fs),
                ForeColor = fore,
                AutoSize = false,
                Size = new Size(w, sz > 20 ? 56 : sz > 12 ? 28 : 20),
                Location = new Point(x, y),
                TextAlign = ContentAlignment.MiddleCenter,
                BackColor = UITheme.BgRoot
            };

        private static Label MakeCardLabel(string text, int w, float size, FontStyle style,
            Color color, int x, int y)
        {
            return new Label
            {
                Text = text,
                Font = new Font("Segoe UI", size, style),
                ForeColor = color,
                AutoSize = false,
                Size = new Size(w, (int)(size * 2.4f)),
                Location = new Point(x, y),
                TextAlign = ContentAlignment.MiddleCenter,
                BackColor = UITheme.BgCard
            };
        }

        private static Label MakeFieldLabel(string text, int x, int y, int w)
        {
            return new Label
            {
                Text = text,
                Font = new Font("Segoe UI", 8.5f, FontStyle.Bold),
                ForeColor = UITheme.TextMuted,
                AutoSize = false,
                Size = new Size(w, 17),
                Location = new Point(x, y),
                BackColor = UITheme.BgCard
            };
        }

        private static TextBox MakeInput(int x, int y, int w, int h, string placeholder)
        {
            return new TextBox
            {
                Size = new Size(w, h),
                Location = new Point(x, y),
                Font = new Font("Segoe UI", 10f),
                BorderStyle = BorderStyle.FixedSingle,
                BackColor = Color.White,
                ForeColor = UITheme.TextPrimary,
            };
        }

        private static Button MakePrimaryBtn(string text, int x, int y, int w, int h)
        {
            var btn = new Button
            {
                Text = text,
                Font = new Font("Segoe UI", 10.5f, FontStyle.Bold),
                Size = new Size(w, h),
                Location = new Point(x, y),
                FlatStyle = FlatStyle.Flat,
                BackColor = UITheme.AccentViolet,
                ForeColor = UITheme.TextPrimary,
                Cursor = Cursors.Hand
            };
            btn.FlatAppearance.BorderSize = 0;
            btn.FlatAppearance.MouseOverBackColor = UITheme.AccentHover;
            btn.MouseEnter += (s, e) => btn.BackColor = UITheme.AccentHover;
            btn.MouseLeave += (s, e) => btn.BackColor = UITheme.AccentViolet;
            return btn;
        }

        private static Button MakeEyeBtn(int x, int y)
        {
            var btn = new Button
            {
                Text = "👁",
                Font = new Font("Segoe UI Emoji", 10f),
                Size = new Size(30, 34),
                Location = new Point(x, y),
                FlatStyle = FlatStyle.Flat,
                BackColor = Color.White,
                ForeColor = UITheme.TextMuted,
                Cursor = Cursors.Hand,
                TabStop = false
            };
            btn.FlatAppearance.BorderSize = 0;
            return btn;
        }

        private static Label MakeLink(string text, int x, int y, int w)
        {
            var lbl = new Label
            {
                Text = text,
                Font = new Font("Segoe UI", 9f, FontStyle.Underline),
                ForeColor = UITheme.Accent,
                AutoSize = false,
                Size = new Size(w, 20),
                Location = new Point(x, y),
                TextAlign = ContentAlignment.MiddleCenter,
                Cursor = Cursors.Hand,
                BackColor = UITheme.BgCard
            };
            lbl.MouseEnter += (s, e) => lbl.ForeColor = UITheme.AccentHover;
            lbl.MouseLeave += (s, e) => lbl.ForeColor = UITheme.Accent;
            return lbl;
        }

        private static Label MakeErrLbl(int x, int y, int w)
        {
            return new Label
            {
                Text = "",
                Font = new Font("Segoe UI", 7.8f),
                ForeColor = UITheme.SemanticDanger,
                AutoSize = false,
                Size = new Size(w, 14),
                Location = new Point(x, y),
                Visible = false,
                BackColor = UITheme.BgCard
            };
        }

        private static void MakeRegRow(out Label lbl, out TextBox txt, out Label err,
            string labelText, int x, int y, int w)
        {
            lbl = new Label
            {
                Text = labelText,
                Font = new Font("Segoe UI", 8.5f, FontStyle.Bold),
                ForeColor = UITheme.TextMuted,
                AutoSize = false,
                Size = new Size(w, 17),
                Location = new Point(x, y),
                BackColor = UITheme.BgCard
            };
            txt = new TextBox
            {
                Size = new Size(w, 34),
                Location = new Point(x, y + 18),
                Font = new Font("Segoe UI", 10f),
                BorderStyle = BorderStyle.FixedSingle,
                BackColor = Color.White,
                ForeColor = UITheme.TextPrimary
            };
            err = new Label
            {
                Text = "",
                Font = new Font("Segoe UI", 7.8f),
                ForeColor = UITheme.SemanticDanger,
                AutoSize = false,
                Size = new Size(w, 14),
                Location = new Point(x, y + 54),
                Visible = false,
                BackColor = UITheme.BgCard
            };
        }
        // ─────────────────────────────────────────────
        //  Double-buffered panel - eliminates card flicker
        // ─────────────────────────────────────────────
        private static Panel MakeBufferedPanel()
        {
            var p = new BufferedPanel();
            return p;
        }

        private sealed class BufferedPanel : Panel
        {
            public BufferedPanel()
            {
                this.SetStyle(
                    ControlStyles.OptimizedDoubleBuffer |
                    ControlStyles.AllPaintingInWmPaint |
                    ControlStyles.ResizeRedraw |
                    ControlStyles.UserPaint, true);
                this.UpdateStyles();
            }
        }

    }
}