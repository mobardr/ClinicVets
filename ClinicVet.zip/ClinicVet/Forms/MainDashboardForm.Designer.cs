using System;
using System.Drawing;
using System.Windows.Forms;
using ClinicVets.UI;

namespace ClinicVets.Forms
{
    partial class MainDashboardForm
    {
        private System.ComponentModel.IContainer components = null;

        private Panel pnlSidebar;
        private Panel pnlSidebarBottom;
        private Panel pnlTopbar;
        private Panel pnlContent;
        private Label lblPageTitle;
        private Label lblDateTime;
        private Label lblAppName;
        private Label lblNavHeader;
        private Button btnNavCustomers, btnNavAnimals, btnNavVisits;
        private Button btnNavMedicines, btnNavAnimalTypes;
        private Panel pnlAvatar;
        private Label lblEmpName, lblEmpRole;
        private Button btnLogout;
        private System.Windows.Forms.Timer clockTimer;

        protected override void Dispose(bool disposing)
        {
            if (disposing && components != null) components.Dispose();
            clockTimer?.Stop();
            clockTimer?.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            var clrBase = UITheme.BgRoot;
            var clrSidebar = UITheme.BgSurface;
            var clrTopbar = UITheme.BgToolbar;
            var clrContent = UITheme.BgRoot;
            var clrText = UITheme.TextPrimary;
            var clrMuted = UITheme.TextMuted;
            var clrAccent = UITheme.Accent;
            var clrBorder = UITheme.BorderDefault;
            var clrNav = UITheme.BgCard;

            this.Text = "ClinicVets";
            this.Size = new Size(1200, 700);
            this.MinimumSize = new Size(1000, 600);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = clrBase;
            this.Font = UITheme.FontBody;
            this.WindowState = FormWindowState.Maximized;
            this.DoubleBuffered = true;

            // ══════════════════════════════════════════
            //  SIDEBAR  (DockStyle.Left, no Paint)
            // ══════════════════════════════════════════
            pnlSidebar = new Panel
            {
                Dock = DockStyle.Left,
                Width = 220,
                BackColor = clrSidebar
            };

            // App brand at top
            lblAppName = new Label
            {
                Text = "🐾  ClinicVets",
                Font = new Font("Segoe UI", 13f, FontStyle.Bold),
                ForeColor = clrText,
                AutoSize = false,
                Size = new Size(220, 60),
                Location = new Point(0, 0),
                TextAlign = System.Drawing.ContentAlignment.MiddleLeft,
                Padding = new Padding(16, 0, 0, 0),
                BackColor = clrSidebar
            };

            // Thin bottom border on app name area using a 1px panel
            var pnlBrandDiv = new Panel
            {
                Size = new Size(180, 1),
                Location = new Point(20, 59),
                BackColor = clrBorder
            };

            lblNavHeader = new Label
            {
                Text = "NAVIGATION",
                Font = new Font("Segoe UI", 7f, FontStyle.Bold),
                ForeColor = clrMuted,
                AutoSize = false,
                Size = new Size(180, 28),
                Location = new Point(16, 70),
                TextAlign = System.Drawing.ContentAlignment.BottomLeft,
                BackColor = clrSidebar
            };

            // Nav buttons
            btnNavCustomers = MakeNavBtn("🧑‍⚕️  Customers", 100, clrSidebar, clrAccent, clrText);
            btnNavAnimals = MakeNavBtn("🐾  Animals", 140, clrSidebar, clrAccent, clrText);
            btnNavVisits = MakeNavBtn("📋  Visits", 180, clrSidebar, clrAccent, clrText);
            btnNavMedicines = MakeNavBtn("💊  Medicines", 220, clrSidebar, clrAccent, clrText);
            btnNavAnimalTypes = MakeNavBtn("🏷️  Animal Types", 260, clrSidebar, clrAccent, clrText);

            // Bottom: avatar + logout
            pnlSidebarBottom = new Panel
            {
                Dock = DockStyle.Bottom,
                Height = 96,
                BackColor = clrSidebar
            };

            var pnlBottomDiv = new Panel
            {
                Size = new Size(180, 1),
                Location = new Point(20, 0),
                BackColor = clrBorder
            };

            pnlAvatar = new Panel
            {
                Size = new Size(36, 36),
                Location = new Point(16, 12),
                BackColor = UITheme.SemanticDangerBg
            };
            pnlAvatar.Paint += (s, e) =>
            {
                e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
                var br = new SolidBrush(UITheme.BgInput);
                e.Graphics.FillEllipse(br, 0, 0, 35, 35);
                var textBr = new SolidBrush(UITheme.Accent);
                var initials = _currentEmployee != null
                    ? $"{_currentEmployee.FirstName[0]}{_currentEmployee.LastName[0]}"
                    : "??";
                var f = new Font("Segoe UI", 10f, FontStyle.Bold);
                var sz = e.Graphics.MeasureString(initials, f);
                e.Graphics.DrawString(initials, f, textBr,
                    (35 - sz.Width) / 2, (35 - sz.Height) / 2);
            };

            lblEmpName = new Label
            {
                Text = "",
                Font = new Font("Segoe UI", 9f, FontStyle.Bold),
                ForeColor = clrText,
                AutoSize = false,
                Size = new Size(148, 18),
                Location = new Point(58, 14),
                BackColor = clrSidebar
            };

            lblEmpRole = new Label
            {
                Text = "",
                Font = new Font("Segoe UI", 8f),
                ForeColor = clrAccent,
                AutoSize = false,
                Size = new Size(148, 16),
                Location = new Point(58, 32),
                BackColor = clrSidebar
            };

            btnLogout = new Button
            {
                Text = "⏻  Sign Out",
                Font = new Font("Segoe UI", 8.5f, FontStyle.Bold),
                Size = new Size(188, 30),
                Location = new Point(16, 54),
                FlatStyle = FlatStyle.Flat,
                BackColor = UITheme.SemanticDangerBg,
                ForeColor = UITheme.SemanticDanger,
                Cursor = Cursors.Hand
            };
            btnLogout.FlatAppearance.BorderColor = UITheme.SemanticDangerBg;
            btnLogout.FlatAppearance.BorderSize = 0;
            btnLogout.MouseEnter += (s, e) => btnLogout.BackColor = UITheme.SemanticDangerBg;
            btnLogout.MouseLeave += (s, e) => btnLogout.BackColor = UITheme.SemanticDangerBg;

            pnlSidebarBottom.Controls.AddRange(new Control[]
                { pnlBottomDiv, pnlAvatar, lblEmpName, lblEmpRole, btnLogout });

            pnlSidebar.Controls.AddRange(new Control[]
            {
                lblAppName, pnlBrandDiv, lblNavHeader,
                btnNavCustomers, btnNavAnimals, btnNavVisits,
                btnNavMedicines, btnNavAnimalTypes,
                pnlSidebarBottom
            });

            // ══════════════════════════════════════════
            //  TOPBAR  (DockStyle.Top, no Paint)
            // ══════════════════════════════════════════
            pnlTopbar = new Panel
            {
                Dock = DockStyle.Top,
                Height = 54,
                BackColor = clrTopbar
            };

            lblPageTitle = new Label
            {
                Text = "Dashboard",
                Font = UITheme.FontTitle,
                ForeColor = clrText,
                AutoSize = false,
                Size = new Size(400, 54),
                Location = new Point(UITheme.SpaceLG, 0),
                TextAlign = System.Drawing.ContentAlignment.MiddleLeft,
                BackColor = clrTopbar
            };

            lblDateTime = new Label
            {
                Text = DateTime.Now.ToString("dddd, dd MMM yyyy   HH:mm"),
                Font = new Font("Segoe UI", 8.5f),
                ForeColor = clrMuted,
                AutoSize = false,
                Size = new Size(320, 54),
                Location = new Point(660, 0),
                TextAlign = System.Drawing.ContentAlignment.MiddleRight,
                BackColor = clrTopbar,
                Anchor = AnchorStyles.Top | AnchorStyles.Right
            };

            clockTimer = new System.Windows.Forms.Timer { Interval = 1000, Enabled = true };
            clockTimer.Tick += (s, e) =>
            {
                lblDateTime.Text = DateTime.Now.ToString("dddd, dd MMM yyyy   HH:mm");
                lblDateTime.Left = pnlTopbar.Width - lblDateTime.Width - UITheme.SpaceLG;
            };

            pnlTopbar.SizeChanged += (s, e) =>
                lblDateTime.Left = pnlTopbar.Width - lblDateTime.Width - UITheme.SpaceLG;

            pnlTopbar.Controls.AddRange(new Control[] { lblPageTitle, lblDateTime });

            // ══════════════════════════════════════════
            //  CONTENT AREA
            // ══════════════════════════════════════════
            pnlContent = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = clrContent
            };

            // Add to form (Fill first, then Top, then Left)
            this.Controls.Add(pnlContent);
            this.Controls.Add(pnlTopbar);
            this.Controls.Add(pnlSidebar);
        }

        private static Button MakeNavBtn(string text, int top,
            Color bg, Color accent, Color fore)
        {
            var btn = new Button
            {
                Text = text,
                Font = new Font("Segoe UI", 9.5f),
                Size = new Size(220, 40),
                Location = new Point(0, top),
                FlatStyle = FlatStyle.Flat,
                BackColor = bg,
                ForeColor = fore,
                Cursor = Cursors.Hand,
                TextAlign = System.Drawing.ContentAlignment.MiddleLeft,
                Padding = new Padding(14, 0, 0, 0)
            };
            btn.FlatAppearance.BorderSize = 0;
            btn.FlatAppearance.MouseOverBackColor = UITheme.BgCard;
            btn.MouseEnter += (s, e) => ((Button)s).BackColor = UITheme.BgCard;
            btn.MouseLeave += (s, e) =>
            {
                var b = (Button)s;
                b.BackColor = b.Tag?.ToString() == "active" ? UITheme.BgCard : UITheme.BgSurface;
            };
            return btn;
        }
    }
}