using ClinicVets.Data;
using ClinicVets.Helpers;
using ClinicVets.Models;
using ClinicVets.UI;
using System;
using System.Data;
using System.Data.SQLite;
using System.Drawing;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace ClinicVets.Forms
{
    /// <summary>
    /// AnimalForm - full CRUD panel for patient animals.
    /// Loads owners and animal types from SQLite into ComboBoxes.
    /// Embedded as a UserControl inside MainDashboardForm.
    /// </summary>
    public partial class AnimalForm : UserControl
    {
        // ─────────────────────────────────────────────
        //  State
        // ─────────────────────────────────────────────
        private int _selectedAnimalId = -1;
        private bool _isEditing = false;

        // ─────────────────────────────────────────────
        //  Constructor
        // ─────────────────────────────────────────────
        private Employee _currentEmployee = null;

        public AnimalForm() : this(null) { }

        public AnimalForm(Employee employee)
        {
            InitializeComponent();
            _currentEmployee = employee;
            ApplyRoleAccess();
            WireEvents();
        }

        // ─────────────────────────────────────────────
        //  Event wiring
        // ─────────────────────────────────────────────
        private void ApplyRoleAccess()
        {
            // All staff can manage animals per project spec
            // Just show the role in the toolbar if needed
            bool canEdit = _currentEmployee != null;
            btnAdd.Enabled = canEdit;
            btnEdit.Enabled = false;   // enabled when row selected
            btnDelete.Enabled = false;   // enabled when row selected
        }

        private void WireEvents()
        {
            this.Load += AnimalForm_Load;
            btnAdd.Click += BtnAdd_Click;
            btnEdit.Click += BtnEdit_Click;
            btnDelete.Click += BtnDelete_Click;
            btnSave.Click += BtnSave_Click;
            btnCancel.Click += BtnCancel_Click;
            btnSearch.Click += BtnSearch_Click;
            btnClearSearch.Click += BtnClearSearch_Click;
            txtSearch.KeyDown += (s, e) => { if (e.KeyCode == Keys.Enter) BtnSearch_Click(s, e); };
            dgvAnimals.SelectionChanged += DgvAnimals_SelectionChanged;
            dgvAnimals.CellDoubleClick += (s, e) => { if (e.RowIndex >= 0) BtnEdit_Click(s, e); };

            // Live validation on Leave
            txtAnimalName.Leave += (s, e) => ValidateAnimalName(false);
            txtWeight.Leave += (s, e) => ValidateWeight(false);
            dtpBirthDate.Leave += (s, e) => ValidateBirthDate(false);
            cmbOwner.Leave += (s, e) => ValidateOwner(false);
        }

        // ─────────────────────────────────────────────
        //  Form Load
        // ─────────────────────────────────────────────
        private void AnimalForm_Load(object sender, EventArgs e)
        {
            try
            {
                LoadOwners();
                LoadAnimalTypes();
                SetFormMode(FormMode.View);
                LoadAllAnimals();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Failed to load Animals:\n\n{ex.Message}",
                    "Load Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // ─────────────────────────────────────────────
        //  ComboBox population
        // ─────────────────────────────────────────────
        private void LoadOwners()
        {
            try
            {
                DataTable dt = DatabaseHelper.Instance.ExecuteQuery(
                    @"SELECT CustomerId, FirstName || ' ' || LastName AS FullName
                      FROM   Customers
                      WHERE  IsActive = 1
                      ORDER  BY LastName, FirstName;");

                cmbOwner.DataSource = dt;
                cmbOwner.DisplayMember = "FullName";
                cmbOwner.ValueMember = "CustomerId";
                cmbOwner.SelectedIndex = -1;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Failed to load owners:\n\n{ex.Message}",
                    "Load Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LoadAnimalTypes()
        {
            try
            {
                DataTable dt = DatabaseHelper.Instance.ExecuteQuery(
                    @"SELECT AnimalTypeId, TypeName
                      FROM   AnimalTypes
                      ORDER  BY TypeName;");

                cmbAnimalType.DataSource = dt;
                cmbAnimalType.DisplayMember = "TypeName";
                cmbAnimalType.ValueMember = "AnimalTypeId";
                cmbAnimalType.SelectedIndex = -1;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Failed to load animal types:\n\n{ex.Message}",
                    "Load Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // ─────────────────────────────────────────────
        //  Grid events
        // ─────────────────────────────────────────────
        private void DgvAnimals_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvAnimals.SelectedRows.Count == 0) return;

            var row = dgvAnimals.SelectedRows[0];
            _selectedAnimalId = Convert.ToInt32(row.Cells["colAnimalId"].Value);

            txtAnimalName.Text = row.Cells["colName"].Value?.ToString() ?? "";
            txtWeight.Text = row.Cells["colWeight"].Value?.ToString() ?? "";
            txtChipNumber.Text = row.Cells["colChip"].Value?.ToString() ?? "";

            // Owner ComboBox
            int ownerId = Convert.ToInt32(row.Cells["colOwnerId"].Value);
            cmbOwner.SelectedValue = ownerId;

            // AnimalType ComboBox
            int typeId = Convert.ToInt32(row.Cells["colTypeId"].Value);
            cmbAnimalType.SelectedValue = typeId;

            // Birth date
            string dob = row.Cells["colBirthDate"].Value?.ToString() ?? "";
            if (DateTime.TryParse(dob, out DateTime birth))
                dtpBirthDate.Value = birth;

            // Vaccine date
            string vax = row.Cells["colVaccineDate"].Value?.ToString() ?? "";
            if (DateTime.TryParse(vax, out DateTime vaccine))
            {
                chkVaccineDate.Checked = true;
                dtpVaccineDate.Value = vaccine;
            }
            else
            {
                chkVaccineDate.Checked = false;
            }

            btnEdit.Enabled = true;
            btnDelete.Enabled = true;

            ClearAllErrors();
        }

        // ─────────────────────────────────────────────
        //  CRUD button handlers
        // ─────────────────────────────────────────────
        private void BtnAdd_Click(object sender, EventArgs e)
        {
            ClearForm();
            _selectedAnimalId = -1;
            _isEditing = false;
            SetFormMode(FormMode.Edit);
            txtAnimalName.Focus();
        }

        private void BtnEdit_Click(object sender, EventArgs e)
        {
            if (_selectedAnimalId < 0)
            {
                MessageBox.Show("Please select an animal to edit.",
                    "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            _isEditing = true;
            SetFormMode(FormMode.Edit);
            txtAnimalName.Focus();
        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
            if (_selectedAnimalId < 0)
            {
                MessageBox.Show("Please select an animal to delete.",
                    "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            string name = txtAnimalName.Text.Trim();
            var confirm = MessageBox.Show(
                $"Delete animal \"{name}\"?\n\nVisit history will be preserved.",
                "Confirm Delete",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning,
                MessageBoxDefaultButton.Button2);

            if (confirm != DialogResult.Yes) return;

            try
            {
                DatabaseHelper.Instance.ExecuteNonQuery(
                    "UPDATE Animals SET IsActive = 0, UpdatedAt = DATETIME('now') WHERE AnimalId = @Id;",
                    new SQLiteParameter("@Id", _selectedAnimalId));

                MessageBox.Show($"Animal \"{name}\" deleted.",
                    "Deleted", MessageBoxButtons.OK, MessageBoxIcon.Information);

                ClearForm();
                SetFormMode(FormMode.View);
                LoadAllAnimals();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Failed to delete animal:\n\n{ex.Message}",
                    "Delete Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnSave_Click(object sender, EventArgs e)
        {
            if (!ValidateAll()) return;

            try
            {
                if (_isEditing) UpdateAnimal();
                else InsertAnimal();

                string action = _isEditing ? "updated" : "added";
                MessageBox.Show($"Animal \"{txtAnimalName.Text.Trim()}\" {action} successfully.",
                    "Saved", MessageBoxButtons.OK, MessageBoxIcon.Information);

                SetFormMode(FormMode.View);
                LoadAllAnimals();
            }
            catch (SQLiteException ex) when (ex.Message.Contains("UNIQUE"))
            {
                MessageBox.Show("A chip number with this value already exists.",
                    "Duplicate Chip", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Failed to save animal:\n\n{ex.Message}",
                    "Save Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnCancel_Click(object sender, EventArgs e)
        {
            ClearForm();
            _isEditing = false;
            SetFormMode(FormMode.View);
        }

        // ─────────────────────────────────────────────
        //  Search
        // ─────────────────────────────────────────────
        private void BtnSearch_Click(object sender, EventArgs e)
        {
            string term = txtSearch.Text.Trim();
            if (string.IsNullOrWhiteSpace(term))
            {
                LoadAllAnimals();
                return;
            }

            LoadAnimals(
                @"SELECT a.AnimalId,
                         a.Name,
                         t.TypeName,
                         a.AnimalTypeId,
                         c.FirstName || ' ' || c.LastName AS OwnerName,
                         a.CustomerId,
                         a.Weight,
                         a.DateOfBirth,
                         a.Microchip,
                         a.VaccineDate,
                         a.Notes
                  FROM   Animals a
                  JOIN   AnimalTypes t ON a.AnimalTypeId = t.AnimalTypeId
                  JOIN   Customers   c ON a.CustomerId   = c.CustomerId
                  WHERE  a.IsActive = 1
                    AND  (a.Name      LIKE @T
                       OR t.TypeName  LIKE @T
                       OR a.Microchip LIKE @T
                       OR c.FirstName || ' ' || c.LastName LIKE @T);",
                new SQLiteParameter("@T", $"%{term}%"));

            lblSearchStatus.Text = $"Results for: \"{term}\"";
        }

        private void BtnClearSearch_Click(object sender, EventArgs e)
        {
            txtSearch.Clear();
            lblSearchStatus.Text = string.Empty;
            LoadAllAnimals();
        }

        // ─────────────────────────────────────────────
        //  Data loading
        // ─────────────────────────────────────────────
        private void LoadAllAnimals()
        {
            LoadAnimals(
                @"SELECT a.AnimalId,
                         a.Name,
                         t.TypeName,
                         a.AnimalTypeId,
                         c.FirstName || ' ' || c.LastName AS OwnerName,
                         a.CustomerId,
                         a.Weight,
                         a.DateOfBirth,
                         a.Microchip,
                         a.VaccineDate,
                         a.Notes
                  FROM   Animals a
                  JOIN   AnimalTypes t ON a.AnimalTypeId = t.AnimalTypeId
                  JOIN   Customers   c ON a.CustomerId   = c.CustomerId
                  WHERE  a.IsActive = 1
                  ORDER  BY a.Name;");

            lblSearchStatus.Text = string.Empty;
        }

        private void LoadAnimals(string sql, params SQLiteParameter[] parameters)
        {
            try
            {
                DataTable dt = DatabaseHelper.Instance.ExecuteQuery(sql, parameters);
                PopulateGrid(dt);
                lblRecordCount.Text = $"{dt.Rows.Count} animal{(dt.Rows.Count != 1 ? "s" : "")}";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Failed to load animals:\n\n{ex.Message}",
                    "Load Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void PopulateGrid(DataTable dt)
        {
            dgvAnimals.Rows.Clear();

            foreach (DataRow row in dt.Rows)
            {
                string dob = row["DateOfBirth"] != DBNull.Value
                    ? DateTime.Parse(row["DateOfBirth"].ToString()).ToString("dd/MM/yyyy")
                    : "-";

                string vax = row["VaccineDate"] != DBNull.Value
                    ? DateTime.Parse(row["VaccineDate"].ToString()).ToString("dd/MM/yyyy")
                    : "-";

                string weight = row["Weight"] != DBNull.Value
                    ? $"{row["Weight"]:F1} kg"
                    : "-";

                dgvAnimals.Rows.Add(
                    row["AnimalId"],      // colAnimalId  (hidden)
                    row["Name"],          // colName
                    row["TypeName"],      // colTypeName
                    row["OwnerName"],     // colOwnerName
                    weight,              // colWeight     (display: "4.5 kg")
                    dob,                 // colBirthDate  (display: "01/01/2020")
                    vax,                 // colVaccineDate (display)
                    row["Microchip"],     // colChip       (hidden)
                    row["AnimalTypeId"],  // colTypeId     (hidden)
                    row["CustomerId"],    // colOwnerId    (hidden)
                    row["Notes"]);        // colNotes      (hidden)
            }

            ClearForm();
            btnEdit.Enabled = false;
            btnDelete.Enabled = false;
            _selectedAnimalId = -1;
        }

        // ─────────────────────────────────────────────
        //  Database CRUD
        // ─────────────────────────────────────────────
        private void InsertAnimal()
        {
            const string sql = @"
                INSERT INTO Animals
                    (CustomerId, AnimalTypeId, Name, Weight, DateOfBirth,
                     Microchip, VaccineDate, IsActive)
                VALUES
                    (@OwnerId, @TypeId, @Name, @Weight, @DOB,
                     @Chip, @VaxDate, 1);";

            DatabaseHelper.Instance.ExecuteNonQuery(sql, BuildParams());
        }

        private void UpdateAnimal()
        {
            const string sql = @"
                UPDATE Animals SET
                    CustomerId   = @OwnerId,
                    AnimalTypeId = @TypeId,
                    Name         = @Name,
                    Weight       = @Weight,
                    DateOfBirth  = @DOB,
                    Microchip    = @Chip,
                    VaccineDate  = @VaxDate,
                    UpdatedAt    = DATETIME('now')
                WHERE AnimalId   = @Id;";

            var p = BuildParams();
            Array.Resize(ref p, p.Length + 1);
            p[p.Length - 1] = new SQLiteParameter("@Id", _selectedAnimalId);

            DatabaseHelper.Instance.ExecuteNonQuery(sql, p);
        }

        private SQLiteParameter[] BuildParams()
        {
            string chip = txtChipNumber.Text.Trim();
            string vaxDate = chkVaccineDate.Checked
                ? dtpVaccineDate.Value.ToString("yyyy-MM-dd")
                : null;

            return new[]
            {
                new SQLiteParameter("@OwnerId", cmbOwner.SelectedValue),
                new SQLiteParameter("@TypeId",  cmbAnimalType.SelectedValue),
                new SQLiteParameter("@Name",    txtAnimalName.Text.Trim()),
                new SQLiteParameter("@Weight",  double.TryParse(txtWeight.Text, out double w) ? (object)w : DBNull.Value),
                new SQLiteParameter("@DOB",     dtpBirthDate.Value.ToString("yyyy-MM-dd")),
                new SQLiteParameter("@Chip",    string.IsNullOrWhiteSpace(chip) ? (object)DBNull.Value : chip),
                new SQLiteParameter("@VaxDate", vaxDate ?? (object)DBNull.Value)
            };
        }

        // ─────────────────────────────────────────────
        //  Validation
        // ─────────────────────────────────────────────
        private bool ValidateAll()
        {
            ClearAllErrors();
            bool ok = true;

            if (!ValidateAnimalName(true)) ok = false;
            if (!ValidateWeight(true)) ok = false;
            if (!ValidateBirthDate(true)) ok = false;
            if (!ValidateOwner(true)) ok = false;

            if (!ok)
                MessageBox.Show("Please fix the highlighted fields.",
                    "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);

            return ok;
        }

        /// <summary>Animal name: letters only (including Hebrew), spaces, hyphens.</summary>
        private bool ValidateAnimalName(bool fromSave)
        {
            string val = txtAnimalName.Text.Trim();
            if (string.IsNullOrWhiteSpace(val))
            { ShowError(txtAnimalName, lblErrName, "Animal name is required."); return false; }

            if (!Regex.IsMatch(val, @"^[\p{L}\s\-']+$"))
            { ShowError(txtAnimalName, lblErrName, "Letters only - no numbers or symbols."); return false; }

            ClearError(txtAnimalName, lblErrName);
            return true;
        }

        /// <summary>Weight: between 0.1 and 100 kg.</summary>
        private bool ValidateWeight(bool fromSave)
        {
            string val = txtWeight.Text.Trim();
            if (string.IsNullOrWhiteSpace(val))
            { ShowError(txtWeight, lblErrWeight, "Weight is required."); return false; }

            if (!double.TryParse(val, out double w) || w < 0.1 || w > 100)
            { ShowError(txtWeight, lblErrWeight, "Enter a value between 0.1 and 100 kg."); return false; }

            ClearError(txtWeight, lblErrWeight);
            return true;
        }

        /// <summary>
        /// Birth date: not in the future, not before year 2000.
        /// </summary>
        private bool ValidateBirthDate(bool fromSave)
        {
            DateTime dob = dtpBirthDate.Value.Date;

            if (dob > DateTime.Today)
            { ShowError(null, lblErrBirthDate, "Birth date cannot be in the future."); return false; }

            if (dob.Year < 2000)
            { ShowError(null, lblErrBirthDate, "Birth year must be 2000 or later."); return false; }

            ClearError(null, lblErrBirthDate);
            return true;
        }

        /// <summary>Owner: must be selected.</summary>
        private bool ValidateOwner(bool fromSave)
        {
            if (cmbOwner.SelectedValue == null || cmbOwner.SelectedIndex < 0)
            { lblErrOwner.Text = "⚠  Owner is required."; lblErrOwner.Visible = true; return false; }

            lblErrOwner.Visible = false;
            return true;
        }

        // ─────────────────────────────────────────────
        //  Error helpers
        // ─────────────────────────────────────────────
        private void ShowError(TextBox txt, Label lbl, string msg)
        {
            if (txt != null) txt.BackColor = UITheme.SemanticDangerBg;
            lbl.Text = "⚠  " + msg;
            lbl.Visible = true;
        }

        private void ClearError(TextBox txt, Label lbl)
        {
            if (txt != null) txt.BackColor = UITheme.BgInput;
            lbl.Text = string.Empty;
            lbl.Visible = false;
        }

        private void ClearAllErrors()
        {
            ClearError(txtAnimalName, lblErrName);
            ClearError(txtWeight, lblErrWeight);
            ClearError(null, lblErrBirthDate);
            lblErrOwner.Visible = false;
        }

        // ─────────────────────────────────────────────
        //  UI mode helpers
        // ─────────────────────────────────────────────
        private enum FormMode { View, Edit }

        private void SetFormMode(FormMode mode)
        {
            bool editing = mode == FormMode.Edit;

            txtAnimalName.ReadOnly = !editing;
            txtWeight.ReadOnly = !editing;
            txtChipNumber.ReadOnly = !editing;

            cmbOwner.Enabled = editing;
            cmbAnimalType.Enabled = editing;
            dtpBirthDate.Enabled = editing;
            chkVaccineDate.Enabled = editing;
            dtpVaccineDate.Enabled = editing && chkVaccineDate.Checked;

            btnAdd.Visible = !editing;
            btnEdit.Visible = !editing;
            btnDelete.Visible = !editing;
            btnSave.Visible = editing;
            btnCancel.Visible = editing;

            lblFormTitle.Text = editing
                ? (_isEditing ? "✏  Edit Animal" : "＋  New Animal")
                : "Animal Details";

            pnlForm.BackColor = editing
                ? UITheme.BgCardHover
                : UITheme.BgCard;

            dgvAnimals.Enabled = !editing;

            // Vaccine date toggle
            chkVaccineDate.CheckedChanged -= ChkVaccineDate_CheckedChanged;
            chkVaccineDate.CheckedChanged += ChkVaccineDate_CheckedChanged;
        }

        private void ChkVaccineDate_CheckedChanged(object sender, EventArgs e)
        {
            dtpVaccineDate.Enabled = chkVaccineDate.Checked;
        }

        private void ClearForm()
        {
            txtAnimalName.Text = string.Empty;
            txtWeight.Text = string.Empty;
            txtChipNumber.Text = string.Empty;
            cmbOwner.SelectedIndex = -1;
            cmbAnimalType.SelectedIndex = -1;
            dtpBirthDate.Value = DateTime.Today;
            chkVaccineDate.Checked = false;
            dtpVaccineDate.Value = DateTime.Today;
            ClearAllErrors();
        }
    }
}