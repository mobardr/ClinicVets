using System;
using System.Data;
using System.Data.SQLite;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using ClinicVets.UI;
using System.Drawing;
using ClinicVets.Data;

namespace ClinicVets.Forms
{
    /// <summary>
    /// AnimalTypesForm — manage the lookup table of animal categories.
    /// Supports Add and Delete; types in use by animals cannot be deleted.
    /// Embedded as a UserControl inside MainDashboardForm.
    /// </summary>
    public partial class AnimalTypesForm : UserControl
    {
        // ─────────────────────────────────────────────
        //  State
        // ─────────────────────────────────────────────
        private int _selectedTypeId = -1;
        private string _selectedTypeName = string.Empty;

        // ─────────────────────────────────────────────
        //  Constructor
        // ─────────────────────────────────────────────
        public AnimalTypesForm()
        {
            InitializeComponent();
            WireEvents();
        }

        // ─────────────────────────────────────────────
        //  Event wiring
        // ─────────────────────────────────────────────
        private void WireEvents()
        {
            this.Load += AnimalTypesForm_Load;
            btnAdd.Click += BtnAdd_Click;
            btnDelete.Click += BtnDelete_Click;
            btnCancelAdd.Click += BtnCancelAdd_Click;
            btnConfirmAdd.Click += BtnConfirmAdd_Click;
            dgvTypes.SelectionChanged += DgvTypes_SelectionChanged;
            dgvTypes.CellDoubleClick += DgvTypes_CellDoubleClick;
            txtTypeName.KeyDown += TxtTypeName_KeyDown;
            txtTypeName.TextChanged += (s, e) => ClearError();
            txtDescription.KeyDown += (s, e) =>
            {
                if (e.KeyCode == Keys.Enter && !e.Shift)
                {
                    e.SuppressKeyPress = true;
                    BtnConfirmAdd_Click(s, e);
                }
            };
        }

        // ─────────────────────────────────────────────
        //  Load
        // ─────────────────────────────────────────────
        private void AnimalTypesForm_Load(object sender, EventArgs e)
        {
            try
            {
                SetAddPanelVisible(false);
                LoadAllTypes();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Failed to load Animal Types:\n\n{ex.Message}",
                    "Load Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // ─────────────────────────────────────────────
        //  Grid events
        // ─────────────────────────────────────────────
        private void DgvTypes_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvTypes.SelectedRows.Count == 0) return;

            var row = dgvTypes.SelectedRows[0];
            _selectedTypeId = Convert.ToInt32(row.Cells["colTypeId"].Value);
            _selectedTypeName = row.Cells["colTypeName"].Value?.ToString() ?? string.Empty;

            lblSelectedName.Text = _selectedTypeName;
            lblSelectedDescription.Text = row.Cells["colDescription"].Value?.ToString() ?? "—";
            lblSelectedCount.Text = row.Cells["colAnimalCount"].Value?.ToString() ?? "0";

            btnDelete.Enabled = true;
            UpdateDeleteButtonState();
        }

        private void DgvTypes_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;
            // Double-click populates edit-ready name into add panel for quick re-entry reference
            BtnAdd_Click(sender, e);
        }

        // ─────────────────────────────────────────────
        //  Add flow
        // ─────────────────────────────────────────────
        private void BtnAdd_Click(object sender, EventArgs e)
        {
            ClearAddForm();
            SetAddPanelVisible(true);
            txtTypeName.Focus();
        }

        private void BtnConfirmAdd_Click(object sender, EventArgs e)
        {
            if (!ValidateTypeName()) return;

            string name = txtTypeName.Text.Trim();
            string desc = txtDescription.Text.Trim();

            try
            {
                // Check for duplicate (case-insensitive)
                DataTable exists = DatabaseHelper.Instance.ExecuteQuery(
                    "SELECT COUNT(*) AS C FROM AnimalTypes WHERE LOWER(TypeName) = LOWER(@Name);",
                    new SQLiteParameter("@Name", name));

                if (Convert.ToInt32(exists.Rows[0]["C"]) > 0)
                {
                    ShowError($"Animal type \"{name}\" already exists.");
                    txtTypeName.Focus();
                    return;
                }

                DatabaseHelper.Instance.ExecuteNonQuery(
                    "INSERT INTO AnimalTypes (TypeName, Description) VALUES (@Name, @Desc);",
                    new SQLiteParameter("@Name", name),
                    new SQLiteParameter("@Desc", string.IsNullOrWhiteSpace(desc) ? (object)DBNull.Value : desc));

                MessageBox.Show(
                    $"Animal type \"{name}\" added successfully.",
                    "Type Added",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);

                SetAddPanelVisible(false);
                LoadAllTypes();
                SelectRowByName(name);
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    $"Failed to add animal type:\n\n{ex.Message}",
                    "Add Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        private void BtnCancelAdd_Click(object sender, EventArgs e)
        {
            SetAddPanelVisible(false);
            ClearAddForm();
        }

        private void TxtTypeName_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true;
                txtDescription.Focus();
            }
            else if (e.KeyCode == Keys.Escape)
            {
                BtnCancelAdd_Click(sender, e);
            }
        }

        // ─────────────────────────────────────────────
        //  Delete
        // ─────────────────────────────────────────────
        private void BtnDelete_Click(object sender, EventArgs e)
        {
            if (_selectedTypeId < 0)
            {
                MessageBox.Show("Please select an animal type to delete.",
                    "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            // Guard: type in use
            int usageCount = GetTypeUsageCount(_selectedTypeId);
            if (usageCount > 0)
            {
                MessageBox.Show(
                    $"Cannot delete \"{_selectedTypeName}\".\n\n" +
                    $"This type is assigned to {usageCount} animal{(usageCount == 1 ? "" : "s")}.\n\n" +
                    "Reassign those animals before deleting this type.",
                    "Type In Use",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
                return;
            }

            var confirm = MessageBox.Show(
                $"Permanently delete animal type \"{_selectedTypeName}\"?\n\nThis action cannot be undone.",
                "Confirm Delete",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning,
                MessageBoxDefaultButton.Button2);

            if (confirm != DialogResult.Yes) return;

            try
            {
                DatabaseHelper.Instance.ExecuteNonQuery(
                    "DELETE FROM AnimalTypes WHERE AnimalTypeId = @Id;",
                    new SQLiteParameter("@Id", _selectedTypeId));

                MessageBox.Show(
                    $"Animal type \"{_selectedTypeName}\" deleted.",
                    "Deleted",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);

                _selectedTypeId = -1;
                _selectedTypeName = string.Empty;
                ClearDetailPanel();
                LoadAllTypes();
            }
            catch (SQLiteException ex) when (ex.Message.Contains("CONSTRAINT") || ex.Message.Contains("constraint"))
            {
                MessageBox.Show(
                    "Cannot delete this type — it is referenced by existing animal records.",
                    "Constraint Violation",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    $"Failed to delete animal type:\n\n{ex.Message}",
                    "Delete Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        // ─────────────────────────────────────────────
        //  Data loading
        // ─────────────────────────────────────────────
        private void LoadAllTypes()
        {
            try
            {
                DataTable dt = DatabaseHelper.Instance.ExecuteQuery(
                    @"SELECT t.AnimalTypeId,
                             t.TypeName,
                             COALESCE(t.Description, '') AS Description,
                             COUNT(a.AnimalId)           AS AnimalCount,
                             t.CreatedAt
                      FROM   AnimalTypes t
                      LEFT   JOIN Animals a
                             ON  a.AnimalTypeId = t.AnimalTypeId
                             AND a.IsActive     = 1
                      GROUP  BY t.AnimalTypeId
                      ORDER  BY t.TypeName;");

                PopulateGrid(dt);
                lblTotalCount.Text = $"{dt.Rows.Count} type{(dt.Rows.Count != 1 ? "s" : "")}";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Failed to load animal types:\n\n{ex.Message}",
                    "Load Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void PopulateGrid(DataTable dt)
        {
            dgvTypes.Rows.Clear();

            foreach (DataRow row in dt.Rows)
            {
                int count = Convert.ToInt32(row["AnimalCount"]);
                string created = DateTime.TryParse(row["CreatedAt"].ToString(), out DateTime ca)
                    ? ca.ToString("dd/MM/yyyy")
                    : "—";

                int idx = dgvTypes.Rows.Add(
                    row["AnimalTypeId"],
                    row["TypeName"],
                    row["Description"],
                    count,
                    created);

                // Colour the count cell
                var cell = dgvTypes.Rows[idx].Cells["colAnimalCount"];
                cell.Style.ForeColor = count > 0
                    ? UITheme.SemanticSuccess
                    : UITheme.TextMuted;

                // Alternate row shading
                dgvTypes.Rows[idx].DefaultCellStyle.BackColor =
                    idx % 2 == 0
                        ? UITheme.BgCard
                        : UITheme.BgInput;
            }

            btnDelete.Enabled = false;
            _selectedTypeId = -1;
            _selectedTypeName = string.Empty;
            ClearDetailPanel();
        }

        // ─────────────────────────────────────────────
        //  Helpers
        // ─────────────────────────────────────────────
        private int GetTypeUsageCount(int typeId)
        {
            DataTable dt = DatabaseHelper.Instance.ExecuteQuery(
                "SELECT COUNT(*) AS C FROM Animals WHERE AnimalTypeId = @Id AND IsActive = 1;",
                new SQLiteParameter("@Id", typeId));
            return Convert.ToInt32(dt.Rows[0]["C"]);
        }

        private void UpdateDeleteButtonState()
        {
            if (_selectedTypeId < 0) { btnDelete.Enabled = false; return; }
            int count = GetTypeUsageCount(_selectedTypeId);
            btnDelete.Enabled = true;
            btnDelete.BackColor = count > 0
                ? UITheme.SemanticWarningBg   // dimmed — in use
                : UITheme.SemanticDangerBg;   // normal danger
            btnDelete.ForeColor = count > 0
                ? UITheme.SemanticDanger
                : UITheme.SemanticDanger;
        }

        private void SelectRowByName(string name)
        {
            foreach (DataGridViewRow row in dgvTypes.Rows)
            {
                if (row.Cells["colTypeName"].Value?.ToString() == name)
                {
                    row.Selected = true;
                    dgvTypes.FirstDisplayedScrollingRowIndex = row.Index;
                    break;
                }
            }
        }

        // ─────────────────────────────────────────────
        //  Validation
        // ─────────────────────────────────────────────
        private bool ValidateTypeName()
        {
            string val = txtTypeName.Text.Trim();

            if (string.IsNullOrWhiteSpace(val))
            { ShowError("Type name is required."); return false; }

            if (val.Length < 2)
            { ShowError("Type name must be at least 2 characters."); return false; }

            if (val.Length > 40)
            { ShowError("Type name must not exceed 40 characters."); return false; }

            if (!Regex.IsMatch(val, @"^[\p{L}\s\-/]+$"))
            { ShowError("Type name may contain letters, spaces, hyphens, or slashes only."); return false; }

            ClearError();
            return true;
        }

        private void ShowError(string msg)
        {
            lblErrTypeName.Text = "⚠  " + msg;
            lblErrTypeName.Visible = true;
            txtTypeName.BackColor = UITheme.SemanticDangerBg;
        }

        private void ClearError()
        {
            lblErrTypeName.Visible = false;
            lblErrTypeName.Text = string.Empty;
            txtTypeName.BackColor = UITheme.BgInput;
        }

        // ─────────────────────────────────────────────
        //  UI helpers
        // ─────────────────────────────────────────────
        private void SetAddPanelVisible(bool visible)
        {
            pnlAddForm.Visible = visible;
            btnAdd.Visible = !visible;
            btnDelete.Visible = !visible;

            if (visible)
                pnlAddForm.BringToFront();
        }

        private void ClearAddForm()
        {
            txtTypeName.Clear();
            txtDescription.Clear();
            ClearError();
        }

        private void ClearDetailPanel()
        {
            lblSelectedName.Text = "—";
            lblSelectedDescription.Text = "—";
            lblSelectedCount.Text = "—";
        }
    }
}