using System;
using System.Data.SQLite;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using ClinicVets.UI;
using System.Drawing;
using ClinicVets.Data;

namespace ClinicVets.Forms
{
    /// <summary>
    /// Registration form for new clinic employees.
    /// Validates all fields, hashes the password with SHA-256,
    /// and inserts the record into the Employees table.
    /// </summary>
    public partial class RegisterEmployeeForm : Form
    {
        // ─────────────────────────────────────────────
        //  Constants
        // ─────────────────────────────────────────────
        private const int UsernameMin = 6;
        private const int UsernameMax = 8;
        private const int UsernameMaxDigits = 2;
        private const int PasswordMin = 8;
        private const int PasswordMax = 10;
        private const int EmployeeNumLen = 4;

        // ─────────────────────────────────────────────
        //  Constructor
        // ─────────────────────────────────────────────
        public RegisterEmployeeForm()
        {
            InitializeComponent();
            WireEvents();
        }

        // ─────────────────────────────────────────────
        //  Event wiring
        // ─────────────────────────────────────────────
        private void WireEvents()
        {
            this.Load += RegisterEmployeeForm_Load;
            btnRegister.Click += BtnRegister_Click;
            btnCancel.Click += BtnCancel_Click;
            lblSignInLink.Click += LblSignInLink_Click;
            btnEyePassword.Click += BtnEyePassword_Click;
            btnEyeConfirm.Click += BtnEyeConfirm_Click;

            // Live inline validation on Leave
            txtUsername.Leave += (s, e) => ValidateUsername(true);
            txtPassword.Leave += (s, e) => ValidatePassword(true);
            txtConfirmPassword.Leave += (s, e) => ValidateConfirmPassword(true);
            txtEmployeeNumber.Leave += (s, e) => ValidateEmployeeNumber(true);
            txtEmail.Leave += (s, e) => ValidateEmail(true);
            txtIsraeliId.Leave += (s, e) => ValidateIsraeliId(true);

            // Clear field error on focus
            foreach (Control c in new Control[]
            { txtUsername, txtPassword, txtConfirmPassword,
              txtEmployeeNumber, txtEmail, txtIsraeliId,
              txtFirstName, txtLastName, txtPhone })
            {
                c.Enter += Input_Enter;
            }

            // Enter key advances focus
            txtFirstName.KeyDown += Input_KeyDown;
            txtLastName.KeyDown += Input_KeyDown;
            txtUsername.KeyDown += Input_KeyDown;
            txtPassword.KeyDown += Input_KeyDown;
            txtConfirmPassword.KeyDown += Input_KeyDown;
            txtEmployeeNumber.KeyDown += Input_KeyDown;
            txtEmail.KeyDown += Input_KeyDown;
            txtPhone.KeyDown += Input_KeyDown;
            txtIsraeliId.KeyDown += Input_KeyDown;
        }

        // ─────────────────────────────────────────────
        //  Form Load
        // ─────────────────────────────────────────────
        private void RegisterEmployeeForm_Load(object sender, EventArgs e)
        {
            cmbRole.SelectedIndex = 0;
            txtFirstName.Focus();
            HideAllErrors();
        }

        // ─────────────────────────────────────────────
        //  Focus helpers
        // ─────────────────────────────────────────────
        private void Input_Enter(object sender, EventArgs e)
        {
            if (sender is TextBox tb)
                tb.BackColor = UITheme.BgInput;
        }

        private void Input_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true;
                SelectNextControl((Control)sender, true, true, true, false);
            }
        }

        // ─────────────────────────────────────────────
        //  Eye toggles
        // ─────────────────────────────────────────────
        private bool _pwVisible, _cfVisible;

        private void BtnEyePassword_Click(object sender, EventArgs e)
        {
            _pwVisible = !_pwVisible;
            txtPassword.UseSystemPasswordChar = !_pwVisible;
            btnEyePassword.Text = _pwVisible ? "🙈" : "👁";
        }

        private void BtnEyeConfirm_Click(object sender, EventArgs e)
        {
            _cfVisible = !_cfVisible;
            txtConfirmPassword.UseSystemPasswordChar = !_cfVisible;
            btnEyeConfirm.Text = _cfVisible ? "🙈" : "👁";
        }

        // ─────────────────────────────────────────────
        //  Register button
        // ─────────────────────────────────────────────
        private void BtnRegister_Click(object sender, EventArgs e)
        {
            if (!ValidateAll()) return;

            try
            {
                SetBusy(true);
                InsertEmployee();

                MessageBox.Show(
                    $"Employee '{txtFirstName.Text.Trim()} {txtLastName.Text.Trim()}' " +
                    $"registered successfully!",
                    "Registration Successful",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);

                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (SQLiteException ex) when (ex.Message.Contains("UNIQUE"))
            {
                MessageBox.Show(
                    "An employee with this email, username, or ID number already exists.\n\n" +
                    "Please check the fields and try again.",
                    "Duplicate Record",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    $"An unexpected error occurred while saving:\n\n{ex.Message}",
                    "Registration Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
            finally
            {
                SetBusy(false);
            }
        }

        private void BtnCancel_Click(object sender, EventArgs e)
        {
            if (AnyFieldFilled())
            {
                var r = MessageBox.Show(
                    "Discard all entered information and close?",
                    "Confirm Cancel",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Question,
                    MessageBoxDefaultButton.Button2);
                if (r != DialogResult.Yes) return;
            }
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }

        // ─────────────────────────────────────────────
        //  Sign In link
        // ─────────────────────────────────────────────
        private void LblSignInLink_Click(object sender, EventArgs e)
        {
            // If fields are filled ask before leaving
            if (AnyFieldFilled())
            {
                var r = MessageBox.Show(
                    "Leave the registration form and go to Sign In?\n\nUnsaved data will be lost.",
                    "Go to Sign In",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Question,
                    MessageBoxDefaultButton.Button2);

                if (r != DialogResult.Yes) return;
            }

            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }

        // ─────────────────────────────────────────────
        //  Master validate
        // ─────────────────────────────────────────────
        private bool ValidateAll()
        {
            bool ok = true;

            if (string.IsNullOrWhiteSpace(txtFirstName.Text))
            { ShowFieldError(txtFirstName, lblErrFirstName, "First name is required."); ok = false; }
            else ClearFieldError(txtFirstName, lblErrFirstName);

            if (string.IsNullOrWhiteSpace(txtLastName.Text))
            { ShowFieldError(txtLastName, lblErrLastName, "Last name is required."); ok = false; }
            else ClearFieldError(txtLastName, lblErrLastName);

            if (!ValidateUsername(false)) ok = false;
            if (!ValidatePassword(false)) ok = false;
            if (!ValidateConfirmPassword(false)) ok = false;
            if (!ValidateEmployeeNumber(false)) ok = false;
            if (!ValidateEmail(false)) ok = false;
            if (!ValidateIsraeliId(false)) ok = false;

            if (!ok)
                MessageBox.Show(
                    "Please fix the highlighted fields before registering.",
                    "Validation Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

            return ok;
        }

        // ─────────────────────────────────────────────
        //  Individual validators
        // ─────────────────────────────────────────────

        /// <summary>
        /// Username: 6-8 chars, max 2 digits.
        /// </summary>
        private bool ValidateUsername(bool showPopup)
        {
            string val = txtUsername.Text.Trim();

            if (string.IsNullOrWhiteSpace(val))
            { ShowFieldError(txtUsername, lblErrUsername, "Username is required."); return false; }

            if (val.Length < UsernameMin || val.Length > UsernameMax)
            {
                ShowFieldError(txtUsername, lblErrUsername,
                    $"Username must be {UsernameMin}-{UsernameMax} characters.");
                return false;
            }

            int digitCount = 0;
            foreach (char c in val)
                if (char.IsDigit(c)) digitCount++;

            if (digitCount > UsernameMaxDigits)
            {
                ShowFieldError(txtUsername, lblErrUsername,
                    $"Username may contain at most {UsernameMaxDigits} digits.");
                return false;
            }

            ClearFieldError(txtUsername, lblErrUsername);
            return true;
        }

        /// <summary>
        /// Password: 8-10 chars, ≥1 letter, ≥1 digit, ≥1 special character.
        /// </summary>
        private bool ValidatePassword(bool showPopup)
        {
            string val = txtPassword.Text;

            if (string.IsNullOrEmpty(val))
            { ShowFieldError(txtPassword, lblErrPassword, "Password is required."); return false; }

            if (val.Length < PasswordMin || val.Length > PasswordMax)
            {
                ShowFieldError(txtPassword, lblErrPassword,
                    $"Password must be {PasswordMin}-{PasswordMax} characters.");
                return false;
            }

            if (!Regex.IsMatch(val, @"[a-zA-Z]"))
            {
                ShowFieldError(txtPassword, lblErrPassword,
                    "Password must contain at least one letter.");
                return false;
            }

            if (!Regex.IsMatch(val, @"[0-9]"))
            {
                ShowFieldError(txtPassword, lblErrPassword,
                    "Password must contain at least one number.");
                return false;
            }

            if (!Regex.IsMatch(val, @"[!@#$%^&*()\-_=+\[\]{};:',.<>?/\\|`~""]"))
            {
                ShowFieldError(txtPassword, lblErrPassword,
                    "Password must contain at least one special character.");
                return false;
            }

            ClearFieldError(txtPassword, lblErrPassword);
            return true;
        }

        /// <summary>Password confirmation must match password.</summary>
        private bool ValidateConfirmPassword(bool showPopup)
        {
            if (txtConfirmPassword.Text != txtPassword.Text)
            {
                ShowFieldError(txtConfirmPassword, lblErrConfirmPassword,
                    "Passwords do not match.");
                return false;
            }
            ClearFieldError(txtConfirmPassword, lblErrConfirmPassword);
            return true;
        }

        /// <summary>Employee number: exactly 4 digits.</summary>
        private bool ValidateEmployeeNumber(bool showPopup)
        {
            string val = txtEmployeeNumber.Text.Trim();

            if (string.IsNullOrWhiteSpace(val))
            { ShowFieldError(txtEmployeeNumber, lblErrEmployeeNumber, "Employee number is required."); return false; }

            if (!Regex.IsMatch(val, @"^\d{4}$"))
            {
                ShowFieldError(txtEmployeeNumber, lblErrEmployeeNumber,
                    "Employee number must be exactly 4 digits.");
                return false;
            }

            ClearFieldError(txtEmployeeNumber, lblErrEmployeeNumber);
            return true;
        }

        /// <summary>Standard email format validation.</summary>
        private bool ValidateEmail(bool showPopup)
        {
            string val = txtEmail.Text.Trim();

            if (string.IsNullOrWhiteSpace(val))
            { ShowFieldError(txtEmail, lblErrEmail, "Email address is required."); return false; }

            if (!Regex.IsMatch(val,
                @"^[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}$"))
            {
                ShowFieldError(txtEmail, lblErrEmail,
                    "Please enter a valid email address.");
                return false;
            }

            ClearFieldError(txtEmail, lblErrEmail);
            return true;
        }

        /// <summary>
        /// Israeli ID (Teudat Zehut): exactly 9 digits, passes Luhn-style checksum.
        /// </summary>
        private bool ValidateIsraeliId(bool showPopup)
        {
            string val = txtIsraeliId.Text.Trim();

            if (string.IsNullOrWhiteSpace(val))
            { ShowFieldError(txtIsraeliId, lblErrIsraeliId, "Israeli ID is required."); return false; }

            // Pad to 9 digits
            string padded = val.PadLeft(9, '0');

            if (!Regex.IsMatch(padded, @"^\d{9}$"))
            {
                ShowFieldError(txtIsraeliId, lblErrIsraeliId,
                    "Israeli ID must be exactly 9 digits.");
                return false;
            }

            if (!IsValidIsraeliId(padded))
            {
                ShowFieldError(txtIsraeliId, lblErrIsraeliId,
                    "Invalid Israeli ID number (checksum failed).");
                return false;
            }

            ClearFieldError(txtIsraeliId, lblErrIsraeliId);
            return true;
        }

        // ─────────────────────────────────────────────
        //  Israeli ID checksum (Luhn variant)
        // ─────────────────────────────────────────────
        private static bool IsValidIsraeliId(string id)
        {
            int sum = 0;
            for (int i = 0; i < 9; i++)
            {
                int digit = id[i] - '0';
                if (i % 2 != 0) digit *= 2;
                if (digit > 9) digit -= 9;
                sum += digit;
            }
            return sum % 10 == 0;
        }

        // ─────────────────────────────────────────────
        //  Database insert
        // ─────────────────────────────────────────────
        private void InsertEmployee()
        {
            string passwordHash = HashPassword(txtPassword.Text);

            const string sql = @"
                INSERT INTO Employees
                    (FirstName, LastName, Role, Phone, Email,
                     HireDate, IsActive, PasswordHash)
                VALUES
                    (@FirstName, @LastName, @Role, @Phone, @Email,
                     @HireDate,  1,         @PasswordHash);";

            DatabaseHelper.Instance.ExecuteNonQuery(sql,
                new SQLiteParameter("@FirstName", txtFirstName.Text.Trim()),
                new SQLiteParameter("@LastName", txtLastName.Text.Trim()),
                new SQLiteParameter("@Role", cmbRole.SelectedItem.ToString()),
                new SQLiteParameter("@Phone", txtPhone.Text.Trim()),
                new SQLiteParameter("@Email", txtEmail.Text.Trim()),
                new SQLiteParameter("@HireDate", DateTime.Today.ToString("yyyy-MM-dd")),
                new SQLiteParameter("@PasswordHash", passwordHash));
        }

        // ─────────────────────────────────────────────
        //  Password hashing (SHA-256)
        // ─────────────────────────────────────────────
        private static string HashPassword(string password)
        {
            var sha = SHA256.Create();
            byte[] bytes = sha.ComputeHash(Encoding.UTF8.GetBytes(password));
            var sb = new StringBuilder();
            foreach (byte b in bytes) sb.Append(b.ToString("x2"));
            return sb.ToString();
        }

        // ─────────────────────────────────────────────
        //  Field error UI helpers
        // ─────────────────────────────────────────────
        private static readonly Color ClrErrorBorder = UITheme.SemanticDanger;
        private static readonly Color ClrNormalBorder = UITheme.TextMuted;

        private void ShowFieldError(TextBox txt, Label errLabel, string message)
        {
            errLabel.Text = "⚠  " + message;
            errLabel.Visible = true;
            txt.BackColor = UITheme.SemanticDangerBg;
        }

        private void ClearFieldError(TextBox txt, Label errLabel = null)
        {
            txt.BackColor = UITheme.BgInput;
            if (errLabel != null)
            {
                errLabel.Visible = false;
                errLabel.Text = string.Empty;
            }
        }

        private void HideAllErrors()
        {
            foreach (var lbl in new[]
            {
                lblErrFirstName, lblErrLastName,
                lblErrUsername, lblErrPassword, lblErrConfirmPassword,
                lblErrEmployeeNumber, lblErrEmail, lblErrIsraeliId
            })
            {
                if (lbl != null)
                {
                    lbl.Visible = false;
                    lbl.Text = string.Empty;
                }
            }
        }

        private bool AnyFieldFilled() =>
            txtFirstName.Text.Length > 0 || txtLastName.Text.Length > 0 ||
            txtUsername.Text.Length > 0 || txtEmail.Text.Length > 0;

        private void SetBusy(bool busy)
        {
            btnRegister.Enabled = !busy;
            btnRegister.Text = busy ? "Saving…" : "Register Employee";
            Cursor = busy ? Cursors.WaitCursor : Cursors.Default;
        }
    }
}