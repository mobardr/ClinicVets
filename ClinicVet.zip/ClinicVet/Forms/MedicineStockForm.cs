using System;
using System.Data;
using System.Data.SQLite;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using ClinicVets.UI;
using System.Drawing;
using ClinicVets.Data;

namespace ClinicVets.Forms
{
    /// <summary>
    /// MedicineStockForm — full inventory management for clinic medicines.
    /// Supports Add, Edit (quantity + price), Delete, and stock-level alerts.
    /// Embedded as a UserControl inside MainDashboardForm.
    /// </summary>
    public partial class MedicineStockForm : UserControl
    {
        // ─────────────────────────────────────────────
        //  State
        // ─────────────────────────────────────────────
        private int _selectedMedicineId = -1;
        private string _selectedMedicineName = string.Empty;
        private bool _isEditing = false;
        private bool _isAdding = false;

        // ─────────────────────────────────────────────
        //  Constructor
        // ─────────────────────────────────────────────
        public MedicineStockForm()
        {
            InitializeComponent();
            WireEvents();
        }

        // ─────────────────────────────────────────────
        //  Event wiring
        // ─────────────────────────────────────────────
        private void WireEvents()
        {
            this.Load += MedicineStockForm_Load;
            btnAdd.Click += BtnAdd_Click;
            btnEdit.Click += BtnEdit_Click;
            btnDelete.Click += BtnDelete_Click;
            btnSave.Click += BtnSave_Click;
            btnCancel.Click += BtnCancel_Click;
            btnRestockAdd.Click += BtnRestockAdd_Click;
            btnRestockSet.Click += BtnRestockSet_Click;
            btnSearch.Click += BtnSearch_Click;
            btnClearSearch.Click += BtnClearSearch_Click;
            txtSearch.KeyDown += (s, e) => { if (e.KeyCode == Keys.Enter) BtnSearch_Click(s, e); };
            dgvMedicines.SelectionChanged += DgvMedicines_SelectionChanged;
            dgvMedicines.CellDoubleClick += (s, e) => { if (e.RowIndex >= 0) BtnEdit_Click(s, e); };

            // Live field validation on leave
            txtName.Leave += (s, e) => ValidateName(false);
            txtUnitPrice.Leave += (s, e) => ValidateUnitPrice(false);
            txtStockQty.Leave += (s, e) => ValidateStockQty(false);
            txtReorderLevel.Leave += (s, e) => ValidateReorderLevel(false);

            // Clear error on enter
            foreach (Control c in new Control[]
                { txtName, txtUnit, txtUnitPrice, txtStockQty, txtReorderLevel })
                c.Enter += (s, e) => ClearFieldError((TextBox)s);
        }

        // ─────────────────────────────────────────────
        //  Form Load
        // ─────────────────────────────────────────────
        private void MedicineStockForm_Load(object sender, EventArgs e)
        {
            try
            {
                SetFormMode(FormMode.View);
                LoadAllMedicines();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Failed to load Medicines:\n\n{ex.Message}",
                    "Load Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // ─────────────────────────────────────────────
        //  Grid selection
        // ─────────────────────────────────────────────
        private void DgvMedicines_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvMedicines.SelectedRows.Count == 0) return;

            var row = dgvMedicines.SelectedRows[0];
            _selectedMedicineId = Convert.ToInt32(row.Cells["colMedId"].Value);
            _selectedMedicineName = row.Cells["colMedName"].Value?.ToString() ?? string.Empty;

            // Populate detail / edit fields
            txtName.Text = row.Cells["colMedName"].Value?.ToString() ?? string.Empty;
            txtDescription.Text = row.Cells["colMedDesc"].Value?.ToString() ?? string.Empty;
            txtUnit.Text = row.Cells["colMedUnit"].Value?.ToString() ?? string.Empty;
            txtUnitPrice.Text = row.Cells["colMedUnitPriceRaw"].Value?.ToString() ?? "0";
            txtStockQty.Text = row.Cells["colMedStockRaw"].Value?.ToString() ?? "0";
            txtReorderLevel.Text = row.Cells["colMedReorderRaw"].Value?.ToString() ?? "10";

            // Stock status indicator
            UpdateStockIndicator(
                Convert.ToDouble(row.Cells["colMedStockRaw"].Value),
                Convert.ToDouble(row.Cells["colMedReorderRaw"].Value));

            btnEdit.Enabled = true;
            btnDelete.Enabled = true;
            pnlRestock.Visible = true;
            txtRestockQty.Text = string.Empty;
        }

        // ─────────────────────────────────────────────
        //  Stock indicator
        // ─────────────────────────────────────────────
        private void UpdateStockIndicator(double stock, double reorder)
        {
            if (stock == 0)
            {
                lblStockStatus.Text = "OUT OF STOCK";
                lblStockStatus.ForeColor = UITheme.SemanticDanger;
                pnlStockBar.BackColor = UITheme.SemanticDanger;
            }
            else if (stock <= reorder)
            {
                lblStockStatus.Text = "LOW STOCK";
                lblStockStatus.ForeColor = UITheme.SemanticWarning;
                pnlStockBar.BackColor = UITheme.SemanticWarning;
            }
            else
            {
                lblStockStatus.Text = "IN STOCK";
                lblStockStatus.ForeColor = UITheme.SemanticSuccess;
                pnlStockBar.BackColor = UITheme.SemanticSuccess;
            }
        }

        // ─────────────────────────────────────────────
        //  CRUD handlers
        // ─────────────────────────────────────────────
        private void BtnAdd_Click(object sender, EventArgs e)
        {
            ClearForm();
            _selectedMedicineId = -1;
            _isAdding = true;
            _isEditing = false;
            SetFormMode(FormMode.Edit);
            txtName.Focus();
        }

        private void BtnEdit_Click(object sender, EventArgs e)
        {
            if (_selectedMedicineId < 0)
            {
                MessageBox.Show("Please select a medicine to edit.",
                    "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            _isEditing = true;
            _isAdding = false;
            SetFormMode(FormMode.Edit);
            txtName.Focus();
        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
            if (_selectedMedicineId < 0)
            {
                MessageBox.Show("Please select a medicine to delete.",
                    "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            // Guard: medicine used in visits
            int usageCount = GetMedicineUsageCount(_selectedMedicineId);
            if (usageCount > 0)
            {
                MessageBox.Show(
                    $"Cannot delete \"{_selectedMedicineName}\".\n\n" +
                    $"It is referenced in {usageCount} visit record{(usageCount > 1 ? "s" : "")}.\n\n" +
                    "You can deactivate it instead by setting stock to 0.",
                    "Medicine In Use",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
                return;
            }

            var confirm = MessageBox.Show(
                $"Permanently delete medicine \"{_selectedMedicineName}\"?\n\nThis cannot be undone.",
                "Confirm Delete",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning,
                MessageBoxDefaultButton.Button2);

            if (confirm != DialogResult.Yes) return;

            try
            {
                DatabaseHelper.Instance.ExecuteNonQuery(
                    "UPDATE Medicines SET IsActive = 0, UpdatedAt = DATETIME('now') WHERE MedicineId = @Id;",
                    new SQLiteParameter("@Id", _selectedMedicineId));

                MessageBox.Show($"Medicine \"{_selectedMedicineName}\" deleted.",
                    "Deleted", MessageBoxButtons.OK, MessageBoxIcon.Information);

                ClearForm();
                SetFormMode(FormMode.View);
                LoadAllMedicines();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Failed to delete:\n\n{ex.Message}",
                    "Delete Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnSave_Click(object sender, EventArgs e)
        {
            if (!ValidateAll()) return;

            try
            {
                if (_isAdding) InsertMedicine();
                else UpdateMedicine();

                string action = _isAdding ? "added" : "updated";
                MessageBox.Show($"Medicine \"{txtName.Text.Trim()}\" {action} successfully.",
                    "Saved", MessageBoxButtons.OK, MessageBoxIcon.Information);

                SetFormMode(FormMode.View);
                LoadAllMedicines();
            }
            catch (SQLiteException ex) when (ex.Message.Contains("UNIQUE"))
            {
                MessageBox.Show("A medicine with this name already exists.",
                    "Duplicate", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Failed to save:\n\n{ex.Message}",
                    "Save Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnCancel_Click(object sender, EventArgs e)
        {
            _isEditing = false;
            _isAdding = false;
            SetFormMode(FormMode.View);
            ClearForm();
        }

        // ─────────────────────────────────────────────
        //  Restock handlers
        // ─────────────────────────────────────────────
        private void BtnRestockAdd_Click(object sender, EventArgs e)
        {
            if (!ValidateRestockQty(out double qty)) return;

            try
            {
                DatabaseHelper.Instance.ExecuteNonQuery(
                    "UPDATE Medicines SET StockQty = StockQty + @Qty, UpdatedAt = DATETIME('now') WHERE MedicineId = @Id;",
                    new SQLiteParameter("@Qty", qty),
                    new SQLiteParameter("@Id", _selectedMedicineId));

                MessageBox.Show($"Added {qty} units to \"{_selectedMedicineName}\" stock.",
                    "Restocked", MessageBoxButtons.OK, MessageBoxIcon.Information);

                txtRestockQty.Clear();
                LoadAllMedicines();
                SelectRowById(_selectedMedicineId);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Restock failed:\n{ex.Message}",
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnRestockSet_Click(object sender, EventArgs e)
        {
            if (!ValidateRestockQty(out double qty)) return;

            var confirm = MessageBox.Show(
                $"Set stock for \"{_selectedMedicineName}\" to exactly {qty} units?",
                "Confirm Stock Set",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (confirm != DialogResult.Yes) return;

            try
            {
                DatabaseHelper.Instance.ExecuteNonQuery(
                    "UPDATE Medicines SET StockQty = @Qty, UpdatedAt = DATETIME('now') WHERE MedicineId = @Id;",
                    new SQLiteParameter("@Qty", qty),
                    new SQLiteParameter("@Id", _selectedMedicineId));

                txtRestockQty.Clear();
                LoadAllMedicines();
                SelectRowById(_selectedMedicineId);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Failed:\n{ex.Message}",
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private bool ValidateRestockQty(out double qty)
        {
            qty = 0;
            if (_selectedMedicineId < 0)
            {
                MessageBox.Show("Select a medicine first.",
                    "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return false;
            }
            string raw = txtRestockQty.Text.Trim();
            if (!double.TryParse(raw, out qty) || qty <= 0)
            {
                MessageBox.Show("Enter a valid positive quantity.",
                    "Invalid Quantity", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            return true;
        }

        // ─────────────────────────────────────────────
        //  Search
        // ─────────────────────────────────────────────
        private void BtnSearch_Click(object sender, EventArgs e)
        {
            string term = txtSearch.Text.Trim();
            if (string.IsNullOrWhiteSpace(term)) { LoadAllMedicines(); return; }

            LoadMedicines(
                @"SELECT MedicineId, Name, Description, Unit,
                         UnitPrice, StockQty, ReorderLevel, UpdatedAt
                  FROM   Medicines
                  WHERE  IsActive = 1
                    AND  (Name LIKE @T OR Description LIKE @T OR Unit LIKE @T);",
                new SQLiteParameter("@T", $"%{term}%"));

            lblSearchStatus.Text = $"Results for: \"{term}\"";
        }

        private void BtnClearSearch_Click(object sender, EventArgs e)
        {
            txtSearch.Clear();
            lblSearchStatus.Text = string.Empty;
            LoadAllMedicines();
        }

        // ─────────────────────────────────────────────
        //  Data loading
        // ─────────────────────────────────────────────
        private void LoadAllMedicines()
        {
            LoadMedicines(
                @"SELECT MedicineId, Name, Description, Unit,
                         UnitPrice, StockQty, ReorderLevel, UpdatedAt
                  FROM   Medicines
                  WHERE  IsActive = 1
                  ORDER  BY Name;");

            lblSearchStatus.Text = string.Empty;
        }

        private void LoadMedicines(string sql, params SQLiteParameter[] parameters)
        {
            try
            {
                DataTable dt = DatabaseHelper.Instance.ExecuteQuery(sql, parameters);
                PopulateGrid(dt);
                UpdateSummaryStats(dt);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Failed to load medicines:\n\n{ex.Message}",
                    "Load Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void PopulateGrid(DataTable dt)
        {
            dgvMedicines.Rows.Clear();

            foreach (DataRow row in dt.Rows)
            {
                double stock = Convert.ToDouble(row["StockQty"]);
                double reorder = Convert.ToDouble(row["ReorderLevel"]);
                double price = Convert.ToDouble(row["UnitPrice"]);

                string stockDisplay = stock == 0 ? "OUT" : stock.ToString("F0");
                string priceDisplay = $"₪{price:F2}";
                string updated = DateTime.TryParse(row["UpdatedAt"].ToString(), out DateTime upd)
                    ? upd.ToString("dd/MM/yy")
                    : "—";

                // Stock status text
                string statusText = stock == 0 ? "Out of Stock"
                                  : stock <= reorder ? "Low Stock"
                                                         : "In Stock";

                int idx = dgvMedicines.Rows.Add(
                    row["MedicineId"],
                    row["Name"],
                    row["Description"],
                    row["Unit"],
                    priceDisplay,
                    price,
                    stockDisplay,
                    stock,
                    reorder,
                    statusText,
                    updated);

                var r = dgvMedicines.Rows[idx];

                // Row background
                r.DefaultCellStyle.BackColor = idx % 2 == 0
                    ? UITheme.BgCard
                    : UITheme.BgInput;

                // Stock cell colouring
                var stockCell = r.Cells["colMedStock"];
                var statusCell = r.Cells["colMedStatus"];

                if (stock == 0)
                {
                    stockCell.Style.ForeColor = UITheme.SemanticDanger;
                    statusCell.Style.ForeColor = UITheme.SemanticDanger;
                    statusCell.Style.BackColor = UITheme.SemanticDangerBg;
                }
                else if (stock <= reorder)
                {
                    stockCell.Style.ForeColor = UITheme.SemanticWarning;
                    statusCell.Style.ForeColor = UITheme.SemanticWarning;
                    statusCell.Style.BackColor = UITheme.SemanticWarningBg;
                }
                else
                {
                    stockCell.Style.ForeColor = UITheme.SemanticSuccess;
                    statusCell.Style.ForeColor = UITheme.SemanticSuccess;
                    statusCell.Style.BackColor = UITheme.AccentDim;
                }
            }

            lblMedCount.Text = $"{dt.Rows.Count} medicine{(dt.Rows.Count != 1 ? "s" : "")}";
            btnEdit.Enabled = false;
            btnDelete.Enabled = false;
            pnlRestock.Visible = false;
            _selectedMedicineId = -1;
            _selectedMedicineName = string.Empty;
            ClearForm();
        }

        // ─────────────────────────────────────────────
        //  Summary stats
        // ─────────────────────────────────────────────
        private void UpdateSummaryStats(DataTable dt)
        {
            int total = dt.Rows.Count, outOfStock = 0, lowStock = 0;
            double totalValue = 0;

            foreach (DataRow row in dt.Rows)
            {
                double stock = Convert.ToDouble(row["StockQty"]);
                double reorder = Convert.ToDouble(row["ReorderLevel"]);
                double price = Convert.ToDouble(row["UnitPrice"]);
                totalValue += stock * price;
                if (stock == 0) outOfStock++;
                else if (stock <= reorder) lowStock++;
            }

            SetStatValue(pnlStatTotal, total.ToString());
            SetStatValue(pnlStatLow, lowStock.ToString());
            SetStatValue(pnlStatOut, outOfStock.ToString());
            SetStatValue(pnlStatValue, $"₪{totalValue:N0}");
        }

        private static void SetStatValue(Panel tile, string val)
        {
            foreach (Control c in tile.Controls)
                if (c.Tag?.ToString() == "value") { c.Text = val; return; }
        }

        // ─────────────────────────────────────────────
        //  Database operations
        // ─────────────────────────────────────────────
        private void InsertMedicine()
        {
            const string sql = @"
                INSERT INTO Medicines
                    (Name, Description, Unit, UnitPrice, StockQty, ReorderLevel, IsActive)
                VALUES
                    (@Name, @Desc, @Unit, @Price, @Stock, @Reorder, 1);";

            DatabaseHelper.Instance.ExecuteNonQuery(sql, BuildParams());
        }

        private void UpdateMedicine()
        {
            const string sql = @"
                UPDATE Medicines SET
                    Name         = @Name,
                    Description  = @Desc,
                    Unit         = @Unit,
                    UnitPrice    = @Price,
                    StockQty     = @Stock,
                    ReorderLevel = @Reorder,
                    UpdatedAt    = DATETIME('now')
                WHERE MedicineId = @Id;";

            var p = BuildParams();
            Array.Resize(ref p, p.Length + 1);
            p[p.Length - 1] = new SQLiteParameter("@Id", _selectedMedicineId);
            DatabaseHelper.Instance.ExecuteNonQuery(sql, p);
        }

        private SQLiteParameter[] BuildParams() => new[]
        {
            new SQLiteParameter("@Name",    txtName.Text.Trim()),
            new SQLiteParameter("@Desc",    txtDescription.Text.Trim()),
            new SQLiteParameter("@Unit",    txtUnit.Text.Trim()),
            new SQLiteParameter("@Price",   double.Parse(txtUnitPrice.Text)),
            new SQLiteParameter("@Stock",   double.Parse(txtStockQty.Text)),
            new SQLiteParameter("@Reorder", double.Parse(txtReorderLevel.Text))
        };

        private int GetMedicineUsageCount(int id)
        {
            var dt = DatabaseHelper.Instance.ExecuteQuery(
                "SELECT COUNT(*) AS C FROM VisitMedicines WHERE MedicineId = @Id;",
                new SQLiteParameter("@Id", id));
            return Convert.ToInt32(dt.Rows[0]["C"]);
        }

        // ─────────────────────────────────────────────
        //  Validation
        // ─────────────────────────────────────────────
        private bool ValidateAll()
        {
            ClearAllErrors();
            bool ok = true;

            if (!ValidateName(true)) ok = false;
            if (!ValidateUnitPrice(true)) ok = false;
            if (!ValidateStockQty(true)) ok = false;
            if (!ValidateReorderLevel(true)) ok = false;

            if (string.IsNullOrWhiteSpace(txtUnit.Text))
            { ShowFieldError(txtUnit, lblErrUnit, "Unit is required."); ok = false; }

            if (!ok)
                MessageBox.Show("Please fix the highlighted fields.",
                    "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);

            return ok;
        }

        private bool ValidateName(bool fromSave)
        {
            string v = txtName.Text.Trim();
            if (string.IsNullOrWhiteSpace(v))
            { ShowFieldError(txtName, lblErrName, "Medicine name is required."); return false; }
            if (v.Length < 2 || v.Length > 80)
            { ShowFieldError(txtName, lblErrName, "Name must be 2–80 characters."); return false; }
            ClearFieldError(txtName); lblErrName.Visible = false;
            return true;
        }

        private bool ValidateUnitPrice(bool fromSave)
        {
            if (!double.TryParse(txtUnitPrice.Text, out double p) || p < 0)
            { ShowFieldError(txtUnitPrice, lblErrUnitPrice, "Enter a valid price (≥ 0)."); return false; }
            ClearFieldError(txtUnitPrice); lblErrUnitPrice.Visible = false;
            return true;
        }

        private bool ValidateStockQty(bool fromSave)
        {
            if (!double.TryParse(txtStockQty.Text, out double q) || q < 0)
            { ShowFieldError(txtStockQty, lblErrStockQty, "Enter a valid quantity (≥ 0)."); return false; }
            ClearFieldError(txtStockQty); lblErrStockQty.Visible = false;
            return true;
        }

        private bool ValidateReorderLevel(bool fromSave)
        {
            if (!double.TryParse(txtReorderLevel.Text, out double r) || r < 0)
            { ShowFieldError(txtReorderLevel, lblErrReorderLevel, "Enter a valid reorder level (≥ 0)."); return false; }
            ClearFieldError(txtReorderLevel); lblErrReorderLevel.Visible = false;
            return true;
        }

        // ─────────────────────────────────────────────
        //  Error helpers
        // ─────────────────────────────────────────────
        private readonly Color _clrErrBg = UITheme.SemanticDangerBg;
        private readonly Color _clrInputBg = UITheme.BgInput;

        private void ShowFieldError(TextBox txt, Label lbl, string msg)
        {
            txt.BackColor = _clrErrBg;
            lbl.Text = "⚠  " + msg;
            lbl.Visible = true;
        }

        private void ClearFieldError(TextBox txt)
        {
            txt.BackColor = _clrInputBg;
        }

        private void ClearAllErrors()
        {
            foreach (var (txt, lbl) in new[]
            {
                (txtName,         lblErrName),
                (txtUnit,         lblErrUnit),
                (txtUnitPrice,    lblErrUnitPrice),
                (txtStockQty,     lblErrStockQty),
                (txtReorderLevel, lblErrReorderLevel)
            })
            {
                txt.BackColor = _clrInputBg;
                lbl.Visible = false;
                lbl.Text = string.Empty;
            }
        }

        // ─────────────────────────────────────────────
        //  UI state helpers
        // ─────────────────────────────────────────────
        private enum FormMode { View, Edit }

        private void SetFormMode(FormMode mode)
        {
            bool editing = mode == FormMode.Edit;

            foreach (TextBox tb in new[] { txtName, txtUnit, txtDescription,
                                           txtUnitPrice, txtStockQty, txtReorderLevel })
                tb.ReadOnly = !editing;

            btnAdd.Visible = !editing;
            btnEdit.Visible = !editing;
            btnDelete.Visible = !editing;
            btnSave.Visible = editing;
            btnCancel.Visible = editing;

            pnlRestock.Visible = !editing && _selectedMedicineId > 0;
            dgvMedicines.Enabled = !editing;

            lblFormTitle.Text = editing
                ? (_isAdding ? "＋  New Medicine" : "✏  Edit Medicine")
                : "Medicine Details";

            pnlDetail.BackColor = editing
                ? UITheme.BgCardHover
                : UITheme.BgCard;
        }

        private void ClearForm()
        {
            txtName.Text = string.Empty;
            txtDescription.Text = string.Empty;
            txtUnit.Text = string.Empty;
            txtUnitPrice.Text = "0.00";
            txtStockQty.Text = "0";
            txtReorderLevel.Text = "10";
            lblStockStatus.Text = string.Empty;
            pnlStockBar.BackColor = UITheme.BorderDefault;
            ClearAllErrors();
        }

        private void SelectRowById(int id)
        {
            foreach (DataGridViewRow row in dgvMedicines.Rows)
            {
                if (Convert.ToInt32(row.Cells["colMedId"].Value) == id)
                {
                    row.Selected = true;
                    dgvMedicines.FirstDisplayedScrollingRowIndex = row.Index;
                    break;
                }
            }
        }
    }
}