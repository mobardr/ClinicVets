using System;
using System.Drawing;
using System.Windows.Forms;
using ClinicVets.UI;

namespace ClinicVets.Forms
{
    partial class LoginForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && components != null) components.Dispose();
            base.Dispose(disposing);
        }

        // ── Shared containers ─────────────────────────────────────────────
        private Panel pnlOuter;
        private Panel pnlCard;

        // ── Login panel controls ──────────────────────────────────────────
        private Panel pnlLoginView;
        private Label lblCardTitle;      // kept for compatibility
        private Label lblCardSubtitle;   // kept for compatibility
        private Label lblVersion;
        private Label lblLoginError;
        private Label lblLoginEmailLabel;
        private Label lblLoginPasswordLabel;
        private TextBox txtLoginEmail;      // used for USERNAME in new spec
        private TextBox txtLoginPassword;
        private Button btnEyeLogin;
        private Button btnLogin;
        private Label lnkGoToRegister;
        private Label lnkBackFromLogin;

        // ── Register panel controls ───────────────────────────────────────
        private Panel pnlRegisterView;
        private Label lblRegFirstName, lblErrRegFirstName;
        private Label lblRegLastName, lblErrRegLastName;
        private Label lblRegUsername, lblErrRegUsername;
        private Label lblRegEmpNum, lblErrRegEmpNum;
        private Label lblRegIdNumber, lblErrRegIdNumber;
        private Label lblRegPhone;
        private Label lblRegEmail, lblErrRegEmail;
        private Label lblRegPassword, lblErrRegPassword;
        private Label lblRegConfirm, lblErrRegConfirm;
        private Label lblErrRegRole;
        private TextBox txtRegFirstName, txtRegLastName;
        private TextBox txtRegUsername;     // NEW: username field
        private TextBox txtRegEmpNum;       // NEW: 4-digit employee number
        private TextBox txtRegIdNumber;     // NEW: Israeli ID number
        private TextBox txtRegPhone, txtRegEmail;
        private TextBox txtRegPassword, txtRegConfirm;
        private ComboBox cmbRegRole;
        private Button btnEyeRegPassword, btnEyeRegConfirm;
        private Button btnRegister;
        private Label lnkGoToLogin;

        private void InitializeComponent()
        {
            // ── Form properties ───────────────────────────────────────────
            this.Text = "ClinicVets - Veterinary Clinic Management";
            this.MinimumSize = new System.Drawing.Size(860, 600);
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.BackColor = UITheme.BgRoot;
            this.Font = UITheme.FontBody;
            this.DoubleBuffered = true;

            // Decorative background
            this.Paint += delegate (object s, System.Windows.Forms.PaintEventArgs pe)
            {
                pe.Graphics.SmoothingMode =
                    System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
                int W = this.ClientSize.Width, H = this.ClientSize.Height;
                using (var br = new System.Drawing.SolidBrush(
                    System.Drawing.Color.FromArgb(18, 217, 119, 86)))
                {
                    pe.Graphics.FillEllipse(br, W - 280, -100, 380, 380);
                    pe.Graphics.FillEllipse(br, -80, H - 250, 320, 320);
                }
                using (var br = new System.Drawing.SolidBrush(
                    System.Drawing.Color.FromArgb(20, 61, 53, 40)))
                {
                    pe.Graphics.FillEllipse(br, 50, 60, 80, 80);
                    pe.Graphics.FillEllipse(br, W - 55, H / 2, 18, 18);
                }
            };

            // ── Outer fill panel ─────────────────────────────────────────
            pnlOuter = new Panel { Dock = DockStyle.Fill, BackColor = UITheme.BgRoot };

            // ── Card (size set by FixLayout at runtime) ───────────────────
            pnlCard = new Panel { Size = new Size(520, 560), BackColor = UITheme.BgCard };

            // ── Login panel (rebuilt by FixLayout) ────────────────────────
            pnlLoginView = new Panel
            {
                Size = new Size(520, 556),
                Location = new Point(0, 4),
                BackColor = UITheme.BgCard,
                Visible = true
            };

            // Stub controls — positions overridden by FixLayout()
            lblCardTitle = new Label { Visible = false };
            lblCardSubtitle = new Label { Visible = false };
            lblVersion = new Label { BackColor = UITheme.BgCard };
            lblLoginError = new Label
            {
                ForeColor = UITheme.SemanticDanger,
                Font = new Font("Segoe UI", 8.5f),
                BackColor = UITheme.BgCard,
                Visible = false
            };
            lblLoginEmailLabel = new Label { BackColor = UITheme.BgCard };
            lblLoginPasswordLabel = new Label { BackColor = UITheme.BgCard };
            txtLoginEmail = new TextBox { BorderStyle = BorderStyle.FixedSingle, BackColor = System.Drawing.Color.White };
            txtLoginPassword = new TextBox { BorderStyle = BorderStyle.FixedSingle, BackColor = System.Drawing.Color.White };
            btnEyeLogin = new Button { FlatStyle = FlatStyle.Flat, BackColor = System.Drawing.Color.White, Text = "o", TabStop = false };
            btnEyeLogin.FlatAppearance.BorderSize = 0;
            btnLogin = new Button { FlatStyle = FlatStyle.Flat };
            lnkGoToRegister = new Label
            {
                Cursor = Cursors.Hand,
                ForeColor = UITheme.Accent,
                Font = new Font("Segoe UI", 9f, FontStyle.Underline),
                BackColor = UITheme.BgCard
            };
            lnkBackFromLogin = new Label
            {
                Cursor = Cursors.Hand,
                ForeColor = UITheme.TextMuted,
                Font = new Font("Segoe UI", 9f, FontStyle.Underline),
                BackColor = UITheme.BgCard
            };

            // ── Register panel (rebuilt by FixLayout) ─────────────────────
            pnlRegisterView = new Panel
            {
                Size = new Size(600, 636),
                Location = new Point(0, 4),
                BackColor = UITheme.BgCard,
                Visible = false,
                AutoScroll = true
            };

            // Stub register controls
            lblRegFirstName = new Label { BackColor = UITheme.BgCard };
            lblErrRegFirstName = new Label { BackColor = UITheme.BgCard, Visible = false };
            txtRegFirstName = new TextBox { BorderStyle = BorderStyle.FixedSingle, BackColor = System.Drawing.Color.White };
            lblRegLastName = new Label { BackColor = UITheme.BgCard };
            lblErrRegLastName = new Label { BackColor = UITheme.BgCard, Visible = false };
            txtRegLastName = new TextBox { BorderStyle = BorderStyle.FixedSingle, BackColor = System.Drawing.Color.White };
            lblRegUsername = new Label { BackColor = UITheme.BgCard };
            lblErrRegUsername = new Label { BackColor = UITheme.BgCard, Visible = false };
            txtRegUsername = new TextBox { BorderStyle = BorderStyle.FixedSingle, BackColor = System.Drawing.Color.White };
            lblRegEmpNum = new Label { BackColor = UITheme.BgCard };
            lblErrRegEmpNum = new Label { BackColor = UITheme.BgCard, Visible = false };
            txtRegEmpNum = new TextBox { BorderStyle = BorderStyle.FixedSingle, BackColor = System.Drawing.Color.White };
            lblRegIdNumber = new Label { BackColor = UITheme.BgCard };
            lblErrRegIdNumber = new Label { BackColor = UITheme.BgCard, Visible = false };
            txtRegIdNumber = new TextBox { BorderStyle = BorderStyle.FixedSingle, BackColor = System.Drawing.Color.White };
            lblRegPhone = new Label { BackColor = UITheme.BgCard };
            txtRegPhone = new TextBox { BorderStyle = BorderStyle.FixedSingle, BackColor = System.Drawing.Color.White };
            lblRegEmail = new Label { BackColor = UITheme.BgCard };
            lblErrRegEmail = new Label { BackColor = UITheme.BgCard, Visible = false };
            txtRegEmail = new TextBox { BorderStyle = BorderStyle.FixedSingle, BackColor = System.Drawing.Color.White };
            lblRegPassword = new Label { BackColor = UITheme.BgCard };
            lblErrRegPassword = new Label { BackColor = UITheme.BgCard, Visible = false };
            txtRegPassword = new TextBox { BorderStyle = BorderStyle.FixedSingle, BackColor = System.Drawing.Color.White, UseSystemPasswordChar = true };
            lblRegConfirm = new Label { BackColor = UITheme.BgCard };
            lblErrRegConfirm = new Label { BackColor = UITheme.BgCard, Visible = false };
            txtRegConfirm = new TextBox { BorderStyle = BorderStyle.FixedSingle, BackColor = System.Drawing.Color.White, UseSystemPasswordChar = true };
            lblErrRegRole = new Label { BackColor = UITheme.BgCard, Visible = false };
            cmbRegRole = new ComboBox { FlatStyle = FlatStyle.Flat, DropDownStyle = ComboBoxStyle.DropDownList, BackColor = System.Drawing.Color.White };
            cmbRegRole.Items.AddRange(new object[] { "Veterinarian", "Secretary" });
            btnEyeRegPassword = new Button { FlatStyle = FlatStyle.Flat, Text = "o", TabStop = false, BackColor = System.Drawing.Color.White };
            btnEyeRegPassword.FlatAppearance.BorderSize = 0;
            btnEyeRegConfirm = new Button { FlatStyle = FlatStyle.Flat, Text = "o", TabStop = false, BackColor = System.Drawing.Color.White };
            btnEyeRegConfirm.FlatAppearance.BorderSize = 0;
            btnRegister = new Button { FlatStyle = FlatStyle.Flat };
            lnkGoToLogin = new Label
            {
                Cursor = Cursors.Hand,
                ForeColor = UITheme.Accent,
                Font = new Font("Segoe UI", 9f, FontStyle.Underline),
                BackColor = UITheme.BgCard
            };

            // ── Assemble ──────────────────────────────────────────────────
            pnlCard.Controls.Add(pnlLoginView);
            pnlCard.Controls.Add(pnlRegisterView);
            pnlOuter.Controls.Add(pnlCard);
            this.Controls.Add(pnlOuter);
        }
    }
}