using System.Drawing;
using System.Windows.Forms;
using ClinicVets.UI;

namespace ClinicVets.Forms
{
    partial class RegisterEmployeeForm
    {
        private System.ComponentModel.IContainer components = null;

        private Panel pnlOuter;
        private Panel pnlCard;
        private Panel pnlCardHeader;
        private Label lblBrandIcon, lblBrandName;

        // ── All field names match RegisterEmployeeForm.cs exactly ─────
        private Label lblFormTitle, lblFormSubtitle;

        // Name row
        private Label lblFirstName, lblLastName;
        private TextBox txtFirstName, txtLastName;
        private Label lblErrFirstName, lblErrLastName;

        // Role / Phone row
        private Label lblRole, lblPhone;
        private ComboBox cmbRole;
        private TextBox txtPhone;

        // Credentials section header
        private Panel lblSectionCreds;

        // Username / Employee Number
        private Label lblUsername, lblEmpNumber;
        private TextBox txtUsername, txtEmployeeNumber;
        private Label lblErrUsername, lblErrEmployeeNumber;

        // Email
        private Label lblEmail;
        private TextBox txtEmail;
        private Label lblErrEmail;

        // ID section header
        private Panel lblSectionId;

        // Israeli ID
        private Label lblIsraeliId;
        private TextBox txtIsraeliId;
        private Label lblErrIsraeliId;

        // Password / Confirm
        private Label lblPassword, lblConfirmPassword;
        private TextBox txtPassword, txtConfirmPassword;
        private Button btnEyePassword, btnEyeConfirm;
        private Label lblErrPassword, lblErrConfirmPassword;

        // Actions + link
        private Button btnRegister, btnCancel;
        private Label lblSignInLink;

        protected override void Dispose(bool disposing)
        {
            if (disposing && components != null) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            var clrBg = UITheme.BgRoot;
            var clrCard = UITheme.BgCard;
            var clrSurface = UITheme.BgSurface;
            var clrInput = UITheme.BgInput;
            var clrText = UITheme.TextPrimary;
            var clrSec = UITheme.TextSecondary;
            var clrMuted = UITheme.TextMuted;
            var clrAccent = UITheme.Accent;
            var clrBorder = UITheme.BorderDefault;

            this.Text = "ClinicVets - Register Employee";
            this.MinimumSize = new Size(880, 640);
            this.FormBorderStyle = FormBorderStyle.Sizable;
            this.MaximizeBox = true;
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = clrBg;
            this.Font = UITheme.FontBody;
            this.DoubleBuffered = true;

            // ── Outer wrapper ─────────────────────────
            pnlOuter = new Panel { Dock = DockStyle.Fill, BackColor = clrBg };

            // ── Card ──────────────────────────────────
            pnlCard = new Panel { Size = new Size(600, 660), BackColor = clrCard };
            // Draw subtle border via Paint
            pnlCard.Paint += delegate (object s2, System.Windows.Forms.PaintEventArgs pe)
            {
                using (var pen = new System.Drawing.Pen(UITheme.BorderDefault, 1))
                    pe.Graphics.DrawRectangle(pen, 0, 0, pnlCard.Width - 1, pnlCard.Height - 1);
            };

            // Accent bar at top (solid panel, no Paint handler)
            var pnlAccent = new Panel
            {
                Size = new Size(600, 4),
                Location = new Point(0, 0),
                BackColor = clrAccent
            };

            // ── Card header ───────────────────────────
            pnlCardHeader = new Panel
            {
                Size = new Size(600, 62),
                Location = new Point(0, 4),
                BackColor = clrSurface
            };
            lblBrandIcon = new Label
            {
                Text = "🐾",
                Font = new Font("Segoe UI Emoji", 18f),
                AutoSize = false,
                Size = new Size(42, 60),
                Location = new Point(20, 1),
                TextAlign = System.Drawing.ContentAlignment.MiddleCenter,
                BackColor = clrSurface
            };
            lblBrandName = new Label
            {
                Text = "ClinicVets - Register Employee",
                Font = new Font("Segoe UI", 12f, FontStyle.Bold),
                ForeColor = clrText,
                AutoSize = false,
                Size = new Size(520, 60),
                Location = new Point(68, 1),
                TextAlign = System.Drawing.ContentAlignment.MiddleLeft,
                BackColor = clrSurface
            };
            pnlCardHeader.Controls.AddRange(new Control[] { lblBrandIcon, lblBrandName });

            // ── Body layout ───────────────────────────
            int bx = 30;          // left margin
            int bw2 = 256;         // half-width field
            int gap = 14;          // gap between columns
            int bwF = bw2 * 2 + gap; // full width
            int bx2 = bx + bw2 + gap; // right column x
            int by = 76;          // start y (below header)

            lblFormTitle = new System.Windows.Forms.Label
            {
                Text = "Create Account",
                Font = new System.Drawing.Font("Segoe UI", 24f, System.Drawing.FontStyle.Bold),
                ForeColor = clrText,
                AutoSize = false,
                Size = new System.Drawing.Size(600, 52),
                Location = new System.Drawing.Point(0, by),
                TextAlign = System.Drawing.ContentAlignment.MiddleCenter,
                BackColor = clrCard
            }; by += 58;
            lblFormSubtitle = new System.Windows.Forms.Label
            {
                Text = "Fill in your details to get started",
                Font = UITheme.FontBody,
                ForeColor = clrMuted,
                AutoSize = false,
                Size = new System.Drawing.Size(600, 22),
                Location = new System.Drawing.Point(0, by),
                TextAlign = System.Drawing.ContentAlignment.MiddleCenter,
                BackColor = clrCard
            }; by += 30;

            // Row 1: First Name | Last Name
            (lblFirstName, txtFirstName, lblErrFirstName) = Field("First Name *", bx, by, bw2);
            (lblLastName, txtLastName, lblErrLastName) = Field("Last Name *", bx2, by, bw2); by += 62;

            // Row 2: Role | Phone
            lblRole = LblSm("Role *", bx, by, bw2);
            cmbRole = new ComboBox
            {
                Size = new Size(bw2, UITheme.InputH),
                Location = new Point(bx, by + 20),
                FlatStyle = FlatStyle.Flat,
                BackColor = clrInput,
                ForeColor = clrText,
                Font = UITheme.FontInput,
                DropDownStyle = ComboBoxStyle.DropDownList
            };
            cmbRole.Items.AddRange(new object[] { "Secretary", "Veterinarian" });
            (lblPhone, txtPhone, _) = Field("Phone", bx2, by, bw2); by += 62;

            // Section separator: Credentials
            lblSectionCreds = Sep("Login Credentials", bx, by, bwF, clrCard); by += 34;

            // Row 3: Username | Employee Number
            (lblUsername, txtUsername, lblErrUsername) = Field("Username *", bx, by, bw2);
            (lblEmpNumber, txtEmployeeNumber, lblErrEmployeeNumber) = Field("Employee Number *", bx2, by, bw2); by += 62;

            // Row 4: Email (full width)
            (lblEmail, txtEmail, lblErrEmail) = Field("Email Address *", bx, by, bwF); by += 62;

            // Section separator: Identity
            lblSectionId = Sep("Identity Verification", bx, by, bwF, clrCard); by += 34;

            // Row 5: Israeli ID (full width)
            (lblIsraeliId, txtIsraeliId, lblErrIsraeliId) = Field("Israeli ID Number *", bx, by, bwF); by += 62;

            // Row 6: Password | Confirm
            lblPassword = LblSm("Password *", bx, by, bw2);
            txtPassword = Inp(bx, by + 20, bw2 - 36);
            txtPassword.UseSystemPasswordChar = true;
            btnEyePassword = Eye(bx + bw2 - 32, by + 20);
            lblErrPassword = ErrLbl(bx, by + 20 + UITheme.InputH + 2, bw2);

            lblConfirmPassword = LblSm("Confirm Password *", bx2, by, bw2);
            txtConfirmPassword = Inp(bx2, by + 20, bw2 - 36);
            txtConfirmPassword.UseSystemPasswordChar = true;
            btnEyeConfirm = Eye(bx2 + bw2 - 32, by + 20);
            lblErrConfirmPassword = ErrLbl(bx2, by + 20 + UITheme.InputH + 2, bw2); by += 62;

            // Action buttons
            btnRegister = new Button();
            UITheme.StylePrimaryBtn(btnRegister, "✔  Create Account");
            btnRegister.Size = new Size(bwF / 2 - 6, 40);
            btnRegister.Location = new Point(bx, by);

            btnCancel = new Button();
            UITheme.StyleGhostBtn(btnCancel, "✕  Cancel");
            btnCancel.Size = new Size(bwF / 2 - 6, 40);
            btnCancel.Location = new Point(bx + bwF / 2 + 6, by); by += 50;

            // Sign-in link
            lblSignInLink = new Label
            {
                Text = "Already have an account? Sign In →",
                Font = new Font("Segoe UI", 9f, FontStyle.Underline),
                ForeColor = clrAccent,
                AutoSize = false,
                Size = new Size(bwF, 22),
                Location = new Point(bx, by),
                TextAlign = System.Drawing.ContentAlignment.MiddleCenter,
                Cursor = Cursors.Hand,
                BackColor = clrCard
            };
            lblSignInLink.MouseEnter += (s, e) => lblSignInLink.ForeColor = UITheme.AccentHover;
            lblSignInLink.MouseLeave += (s, e) => lblSignInLink.ForeColor = clrAccent;

            pnlCard.Controls.AddRange(new Control[]
            {
                pnlAccent, pnlCardHeader,
                lblFormTitle, lblFormSubtitle,
                lblFirstName, txtFirstName, lblErrFirstName,
                lblLastName,  txtLastName,  lblErrLastName,
                lblRole, cmbRole, lblPhone, txtPhone,
                lblSectionCreds,
                lblUsername, txtUsername, lblErrUsername,
                lblEmpNumber, txtEmployeeNumber, lblErrEmployeeNumber,
                lblEmail, txtEmail, lblErrEmail,
                lblSectionId,
                lblIsraeliId, txtIsraeliId, lblErrIsraeliId,
                lblPassword,        txtPassword,        btnEyePassword,     lblErrPassword,
                lblConfirmPassword, txtConfirmPassword, btnEyeConfirm,      lblErrConfirmPassword,
                btnRegister, btnCancel, lblSignInLink
            });

            // Responsive centring
            UITheme.CentreInParent(pnlOuter, pnlCard, UITheme.CardMaxW + 120, UITheme.CardMaxH + 60);

            pnlOuter.Controls.Add(pnlCard);
            this.Controls.Add(pnlOuter);
        }

        // ── Factory helpers ───────────────────────────

        private static (Label, TextBox, Label) Field(string label, int x, int y, int w)
        {
            var l = LblSm(label, x, y, w);
            var t = Inp(x, y + 20, w);
            var e = ErrLbl(x, y + 20 + UITheme.InputH + 2, w);
            return (l, t, e);
        }

        private static Label Lbl(int x, int y, int w, string text, Font font, Color fore, Color bg) =>
            new Label
            {
                Text = text,
                Font = font,
                ForeColor = fore,
                AutoSize = false,
                Size = new Size(w, 30),
                Location = new Point(x, y),
                BackColor = bg
            };

        private static Label LblSm(string text, int x, int y, int w) =>
            new Label
            {
                Text = text,
                Font = UITheme.FontLabel,
                ForeColor = UITheme.TextSecondary,
                AutoSize = false,
                Size = new Size(w, 18),
                Location = new Point(x, y),
                BackColor = UITheme.BgCard
            };

        private static TextBox Inp(int x, int y, int w) =>
            new TextBox
            {
                Size = new Size(w, UITheme.InputH),
                Location = new Point(x, y),
                Font = UITheme.FontInput,
                BorderStyle = BorderStyle.FixedSingle,
                BackColor = UITheme.BgInput,
                ForeColor = UITheme.TextPrimary
            };

        private static Button Eye(int x, int y)
        {
            var b = new Button
            {
                Text = "👁",
                Font = new Font("Segoe UI Emoji", 10f),
                Size = new Size(32, UITheme.InputH),
                Location = new Point(x, y),
                FlatStyle = FlatStyle.Flat,
                BackColor = UITheme.BgInput,
                ForeColor = UITheme.TextMuted,
                Cursor = Cursors.Hand,
                TabStop = false
            };
            b.FlatAppearance.BorderSize = 0;
            return b;
        }

        private static Label ErrLbl(int x, int y, int w) =>
            new Label
            {
                Text = "",
                Font = new Font("Segoe UI", 7.8f),
                ForeColor = UITheme.SemanticDanger,
                AutoSize = false,
                Size = new Size(w, 14),
                Location = new Point(x, y),
                BackColor = UITheme.BgCard,
                Visible = false
            };

        private static Panel Sep(string title, int x, int y, int w, Color bg)
        {
            var p = new Panel { Size = new Size(w, 28), Location = new Point(x, y), BackColor = bg };
            var line = new Panel { Size = new Size(w, 1), Location = new Point(0, 14), BackColor = UITheme.BorderDefault };
            var lbl = new Label
            {
                Text = "  " + title.ToUpper() + "  ",
                Font = new Font("Segoe UI", 7.5f, FontStyle.Bold),
                ForeColor = UITheme.TextMuted,
                AutoSize = true,
                Location = new Point(0, 6),
                BackColor = bg
            };
            p.Controls.AddRange(new Control[] { line, lbl });
            return p;
        }
    }
}