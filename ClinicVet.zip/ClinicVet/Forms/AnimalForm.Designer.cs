using System.Drawing;
using System.Windows.Forms;
using ClinicVets.UI;

namespace ClinicVets.Forms
{
    partial class AnimalForm
    {
        private System.ComponentModel.IContainer components = null;

        // ── Toolbar ───────────────────────────────────
        private Panel pnlToolbar;
        private Label lblPageTitle;
        private Button btnAdd, btnEdit, btnDelete, btnSave, btnCancel;

        // ── Search ────────────────────────────────────
        private Panel pnlSearch;
        private TextBox txtSearch;
        private Button btnSearch, btnClearSearch;
        private Label lblSearchStatus;
        private Label lblRecordCount;

        // ── Split layout ──────────────────────────────
        private Panel pnlMain;
        private Panel pnlLeft;
        private Panel pnlSplitter;
        private Panel pnlRight;
        private Panel pnlForm;

        // ── Grid ──────────────────────────────────────
        private DataGridView dgvAnimals;
        private DataGridViewTextBoxColumn colAnimalId;
        private DataGridViewTextBoxColumn colName;
        private DataGridViewTextBoxColumn colTypeName;
        private DataGridViewTextBoxColumn colTypeId;
        private DataGridViewTextBoxColumn colOwnerName;
        private DataGridViewTextBoxColumn colOwnerId;
        private DataGridViewTextBoxColumn colWeight;
        private DataGridViewTextBoxColumn colBirthDate;
        private DataGridViewTextBoxColumn colVaccineDate;
        private DataGridViewTextBoxColumn colChip;
        private DataGridViewTextBoxColumn colNotes;

        // ── Detail form — exact names used in AnimalForm.cs ───
        private Label lblFormTitle;
        private Label lblName, lblWeight, lblChip;
        private Label lblType, lblOwner;
        private Label lblBirth, lblVaccine, lblNotesLbl;
        private Label lblErrName, lblErrWeight;
        private Label lblErrBirthDate, lblErrOwner, lblErrType;
        private TextBox txtAnimalName, txtWeight, txtChipNumber;
        private ComboBox cmbAnimalType, cmbOwner;
        private DateTimePicker dtpBirthDate;
        private CheckBox chkVaccineDate;
        private DateTimePicker dtpVaccineDate;
        private RichTextBox txtNotesAnimal;

        protected override void Dispose(bool disposing)
        {
            if (disposing && components != null) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.BackColor = UITheme.BgRoot;
            this.Dock = DockStyle.Fill;
            this.Font = UITheme.FontBody;
            this.DoubleBuffered = true;
            this.SetStyle(ControlStyles.OptimizedDoubleBuffer |
                          ControlStyles.AllPaintingInWmPaint, true);

            // ── Toolbar ───────────────────────────────
            pnlToolbar = new Panel
            {
                Dock = DockStyle.Top,
                Height = UITheme.ToolbarH,
                BackColor = UITheme.BgToolbar
            };
            lblPageTitle = new Label
            {
                Text = "Animals",
                Font = UITheme.FontTitle,
                ForeColor = UITheme.TextPrimary,
                AutoSize = false,
                Size = new Size(260, UITheme.ToolbarH),
                Location = new Point(UITheme.SpaceLG, 0),
                TextAlign = System.Drawing.ContentAlignment.MiddleLeft,
                BackColor = UITheme.BgToolbar
            };
            btnAdd = new Button(); UITheme.StylePrimaryBtn(btnAdd, "＋  Add New");
            btnEdit = new Button(); UITheme.StyleSecondaryBtn(btnEdit, "✏  Edit");
            btnDelete = new Button(); UITheme.StyleDangerBtn(btnDelete, "🗑  Delete");
            btnSave = new Button(); UITheme.StylePrimaryBtn(btnSave, "✔  Save");
            btnCancel = new Button(); UITheme.StyleGhostBtn(btnCancel, "✕  Cancel");
            foreach (var b in new[] { btnAdd, btnEdit, btnDelete, btnSave, btnCancel })
                b.Size = new Size(112, 34);
            btnSave.Visible = false;
            btnCancel.Visible = false;
            pnlToolbar.SizeChanged += (s, e) =>
            {
                int y = (UITheme.ToolbarH - 34) / 2;
                btnAdd.Location = new Point(pnlToolbar.Width - 128, y);
                btnEdit.Location = new Point(pnlToolbar.Width - 248, y);
                btnDelete.Location = new Point(pnlToolbar.Width - 368, y);
                btnSave.Location = new Point(pnlToolbar.Width - 128, y);
                btnCancel.Location = new Point(pnlToolbar.Width - 248, y);
                foreach (var b in new[] { btnAdd, btnEdit, btnDelete, btnSave, btnCancel })
                    b.Anchor = AnchorStyles.Right | AnchorStyles.Top;
            };
            pnlToolbar.Controls.AddRange(new Control[]
                { lblPageTitle, btnAdd, btnEdit, btnDelete, btnSave, btnCancel });

            // ── Search bar ────────────────────────────
            pnlSearch = new Panel
            {
                Dock = DockStyle.Top,
                Height = UITheme.SearchBarH,
                BackColor = UITheme.BgSurface
            };
            var lblS = new Label
            {
                Text = "Search:",
                Font = UITheme.FontLabel,
                ForeColor = UITheme.TextSecondary,
                AutoSize = false,
                Size = new Size(60, UITheme.SearchBarH),
                Location = new Point(UITheme.SpaceLG, 0),
                TextAlign = System.Drawing.ContentAlignment.MiddleRight,
                BackColor = UITheme.BgSurface
            };
            txtSearch = new TextBox
            {
                Size = new Size(220, UITheme.InputH),
                Location = new Point(86, (UITheme.SearchBarH - UITheme.InputH) / 2),
                Font = UITheme.FontInput,
                BorderStyle = BorderStyle.FixedSingle,
                BackColor = UITheme.BgInput,
                ForeColor = UITheme.TextPrimary,
            };
            btnSearch = new Button(); UITheme.StyleSecondaryBtn(btnSearch, "Search");
            btnClearSearch = new Button(); UITheme.StyleGhostBtn(btnClearSearch, "✕ Clear");
            btnSearch.Size = btnClearSearch.Size = new Size(80, UITheme.InputH);
            btnSearch.Location = new Point(314, (UITheme.SearchBarH - UITheme.InputH) / 2);
            btnClearSearch.Location = new Point(402, (UITheme.SearchBarH - UITheme.InputH) / 2);
            lblSearchStatus = new Label
            {
                Text = "",
                Font = UITheme.FontLabel,
                ForeColor = UITheme.TextMuted,
                AutoSize = false,
                Size = new Size(200, UITheme.SearchBarH),
                Location = new Point(498, 0),
                TextAlign = System.Drawing.ContentAlignment.MiddleLeft,
                BackColor = UITheme.BgSurface
            };
            lblRecordCount = new Label
            {
                Text = "",
                Font = UITheme.FontLabel,
                ForeColor = UITheme.Accent,
                AutoSize = false,
                Size = new Size(120, UITheme.SearchBarH),
                Location = new Point(702, 0),
                TextAlign = System.Drawing.ContentAlignment.MiddleLeft,
                BackColor = UITheme.BgSurface
            };
            pnlSearch.Controls.AddRange(new Control[]
                { lblS, txtSearch, btnSearch, btnClearSearch, lblSearchStatus, lblRecordCount });

            // ── Main split ────────────────────────────
            pnlMain = new Panel { Dock = DockStyle.Fill, BackColor = UITheme.BgRoot };
            pnlLeft = new Panel { Dock = DockStyle.Left, Width = 600, BackColor = UITheme.BgSurface };
            // Responsive: left panel = 55% of parent, clamped
            pnlMain.Resize += (s, e) =>
            {
                if (pnlMain.Width < 1) return;
                int lw = System.Math.Max(600, System.Math.Min(
                    (int)(pnlMain.Width * 0.58f), pnlMain.Width - 280));
                pnlLeft.Width = lw;
            };
            pnlSplitter = new Panel { Dock = DockStyle.Left, Width = 1, BackColor = UITheme.BorderDefault };
            pnlRight = new Panel { Dock = DockStyle.Fill, BackColor = UITheme.BgSurface };

            // ── Grid ──────────────────────────────────
            dgvAnimals = new DataGridView { Dock = DockStyle.Fill };
            UITheme.StyleGrid(dgvAnimals);

            colAnimalId = Col("colAnimalId", "ID", 50, false);
            colName = Col("colName", "Name", 140, true);
            colTypeName = Col("colTypeName", "Type", 100, true);
            colOwnerName = Col("colOwnerName", "Owner", 150, true);
            colWeight = Col("colWeight", "Weight (kg)", 90, true);
            colBirthDate = Col("colBirthDate", "Born", 90, true);
            colVaccineDate = Col("colVaccineDate", "Vaccine", 90, true);
            colChip = Col("colChip", "Chip No.", 0, false);
            colTypeId = Col("colTypeId", "", 0, false);
            colOwnerId = Col("colOwnerId", "", 0, false);
            colNotes = Col("colNotes", "Notes", 0, false);

            dgvAnimals.Columns.AddRange(new DataGridViewColumn[]
            {
                colAnimalId, colName, colTypeName, colOwnerName,
                colWeight, colBirthDate, colVaccineDate,
                colChip, colTypeId, colOwnerId, colNotes
            });
            pnlLeft.Controls.Add(dgvAnimals);

            // ── Detail form ───────────────────────────
            pnlForm = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = UITheme.BgSurface,
                AutoScroll = true,
                Padding = new Padding(UITheme.SpaceLG)
            };

            lblFormTitle = new Label
            {
                Text = "Animal Details",
                Font = UITheme.FontSubtitle,
                ForeColor = UITheme.TextPrimary,
                AutoSize = false,
                Size = new Size(360, 32),
                Location = new Point(0, 0),
                BackColor = UITheme.BgSurface
            };

            int fy = 40, fw = 340;

            // Animal Name
            (lblName, txtAnimalName, lblErrName) = MakeField("Animal Name *", 0, fy, fw); fy += 62;
            // Weight
            (lblWeight, txtWeight, lblErrWeight) = MakeField("Weight (kg)", 0, fy, fw); fy += 62;
            // Chip Number
            lblChip = MakeLbl("Chip Number", 0, fy, fw);
            txtChipNumber = MakeTxt(0, fy + 20, fw); fy += 62;
            // Type
            lblType = MakeLbl("Animal Type *", 0, fy, fw);
            cmbAnimalType = new ComboBox
            {
                Size = new Size(fw, UITheme.InputH),
                Location = new Point(0, fy + 20),
                Font = UITheme.FontInput,
                FlatStyle = FlatStyle.Flat,
                BackColor = UITheme.BgInput,
                ForeColor = UITheme.TextPrimary,
                DropDownStyle = ComboBoxStyle.DropDownList
            };
            lblErrType = MakeErr(0, fy + 20 + UITheme.InputH + 1, fw); fy += 62;
            // Owner
            lblOwner = MakeLbl("Owner *", 0, fy, fw);
            cmbOwner = new ComboBox
            {
                Size = new Size(fw, UITheme.InputH),
                Location = new Point(0, fy + 20),
                Font = UITheme.FontInput,
                FlatStyle = FlatStyle.Flat,
                BackColor = UITheme.BgInput,
                ForeColor = UITheme.TextPrimary,
                DropDownStyle = ComboBoxStyle.DropDownList
            };
            lblErrOwner = MakeErr(0, fy + 20 + UITheme.InputH + 1, fw); fy += 62;
            // Birth date
            lblBirth = MakeLbl("Date of Birth *", 0, fy, fw);
            dtpBirthDate = new DateTimePicker
            {
                Size = new Size(fw, UITheme.InputH),
                Location = new Point(0, fy + 20),
                Font = UITheme.FontInput,
                Format = DateTimePickerFormat.Short
            };
            lblErrBirthDate = MakeErr(0, fy + 20 + UITheme.InputH + 1, fw); fy += 62;
            // Vaccine
            chkVaccineDate = new CheckBox
            {
                Text = "Has Vaccination Date",
                Location = new Point(0, fy),
                Font = UITheme.FontLabel,
                ForeColor = UITheme.TextSecondary,
                BackColor = UITheme.BgSurface,
                AutoSize = true
            };
            fy += 28;
            lblVaccine = MakeLbl("Vaccine Date", 0, fy, fw);
            dtpVaccineDate = new DateTimePicker
            {
                Size = new Size(fw, UITheme.InputH),
                Location = new Point(0, fy + 20),
                Font = UITheme.FontInput,
                Format = DateTimePickerFormat.Short,
                Visible = false
            };
            fy += 62;
            // Notes
            lblNotesLbl = MakeLbl("Notes", 0, fy, fw);
            txtNotesAnimal = new RichTextBox
            {
                Size = new Size(fw, 80),
                Location = new Point(0, fy + 20),
                Font = UITheme.FontInput,
                BorderStyle = BorderStyle.FixedSingle,
                BackColor = UITheme.BgInput,
                ForeColor = UITheme.TextPrimary
            };

            pnlForm.Controls.AddRange(new Control[]
            {
                lblFormTitle,
                lblName,   txtAnimalName, lblErrName,
                lblWeight, txtWeight,     lblErrWeight,
                lblChip,   txtChipNumber,
                lblType,   cmbAnimalType, lblErrType,
                lblOwner,  cmbOwner,      lblErrOwner,
                lblBirth,  dtpBirthDate,  lblErrBirthDate,
                chkVaccineDate, lblVaccine, dtpVaccineDate,
                lblNotesLbl, txtNotesAnimal
            });

            pnlRight.Controls.Add(pnlForm);
            pnlMain.Controls.Add(pnlRight);
            pnlMain.Controls.Add(pnlSplitter);
            pnlMain.Controls.Add(pnlLeft);
            this.Controls.AddRange(new Control[] { pnlMain, pnlSearch, pnlToolbar });
        }

        // ── Factory helpers ───────────────────────────
        private static DataGridViewTextBoxColumn Col(string n, string h, int w, bool v) =>
            new DataGridViewTextBoxColumn
            {
                Name = n,
                HeaderText = h,
                MinimumWidth = w > 0 ? w : 40,
                Visible = v,
                SortMode = DataGridViewColumnSortMode.Automatic
            };

        private static (Label lbl, TextBox txt, Label err) MakeField(
            string label, int x, int y, int w)
        {
            var lbl = MakeLbl(label, x, y, w);
            var txt = MakeTxt(x, y + 20, w);
            var err = MakeErr(x, y + 20 + UITheme.InputH + 1, w);
            return (lbl, txt, err);
        }

        private static Label MakeLbl(string text, int x, int y, int w) =>
            new Label
            {
                Text = text,
                Font = UITheme.FontLabel,
                ForeColor = UITheme.TextSecondary,
                AutoSize = false,
                Size = new Size(w, 18),
                Location = new Point(x, y),
                BackColor = UITheme.BgSurface
            };

        private static TextBox MakeTxt(int x, int y, int w) =>
            new TextBox
            {
                Size = new Size(w, UITheme.InputH),
                Location = new Point(x, y),
                Font = UITheme.FontInput,
                BorderStyle = BorderStyle.FixedSingle,
                BackColor = UITheme.BgInput,
                ForeColor = UITheme.TextPrimary
            };

        private static Label MakeErr(int x, int y, int w) =>
            new Label
            {
                Text = "",
                Font = new Font("Segoe UI", 7.8f),
                ForeColor = UITheme.SemanticDanger,
                AutoSize = false,
                Size = new Size(w, 14),
                Location = new Point(x, y),
                BackColor = UITheme.BgSurface,
                Visible = false
            };
    }
}