using System;
using System.Data;
using System.Data.SQLite;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Drawing;
using ClinicVets.Data;
using ClinicVets.Models;
using ClinicVets.UI;
using ClinicVets.Helpers;

namespace ClinicVets.Forms
{
    /// <summary>
    /// CustomerForm - full CRUD panel for clinic customers.
    /// Embedded as a UserControl inside MainDashboardForm's content area.
    /// </summary>
    public partial class CustomerForm : UserControl
    {
        // ─────────────────────────────────────────────
        //  State
        // ─────────────────────────────────────────────
        private int _selectedCustomerId = -1;
        private bool _isEditing = false;
        private Employee _currentEmployee = null;

        // ─────────────────────────────────────────────
        //  Constructor
        // ─────────────────────────────────────────────
        public CustomerForm() : this(null) { }

        public CustomerForm(Employee employee)
        {
            InitializeComponent();
            _currentEmployee = employee;
            ApplyRoleRestrictions();
            WireEvents();
        }

        // ─────────────────────────────────────────────
        //  Event wiring
        // ─────────────────────────────────────────────
        // ─────────────────────────────────────────────
        //  Role restrictions (Secretary only can edit)
        // ─────────────────────────────────────────────
        private void ApplyRoleRestrictions()
        {
            bool isSecretary = _currentEmployee == null ||
                               _currentEmployee.Role == "Secretary";

            // Only Secretary can add/edit/delete customers
            btnNew.Visible = isSecretary;
            btnEdit.Visible = isSecretary;
            btnDelete.Visible = isSecretary;

            if (!isSecretary)
            {
                // Show read-only message for non-secretaries
                lblSearchStatus.Text = "View only - customer management requires Secretary role";
                lblSearchStatus.ForeColor = UITheme.SemanticWarning;
            }
        }

        private void WireEvents()
        {
            this.Load += CustomerForm_Load;
            btnAdd.Click += BtnAdd_Click;
            btnEdit.Click += BtnEdit_Click;
            btnViewAnimals.Click += BtnViewAnimals_Click;
            btnDelete.Click += BtnDelete_Click;
            btnSave.Click += BtnSave_Click;
            btnCancel.Click += BtnCancel_Click;
            btnSearchById.Click += BtnSearchById_Click;
            btnSearchByPhone.Click += BtnSearchByPhone_Click;
            btnClearSearch.Click += BtnClearSearch_Click;
            txtSearchById.KeyDown += (s, e) => { if (e.KeyCode == Keys.Enter) BtnSearchById_Click(s, e); };
            txtSearchByPhone.KeyDown += (s, e) => { if (e.KeyCode == Keys.Enter) BtnSearchByPhone_Click(s, e); };
            dgvCustomers.SelectionChanged += DgvCustomers_SelectionChanged;
            dgvCustomers.CellDoubleClick += DgvCustomers_CellDoubleClick;
        }

        // ─────────────────────────────────────────────
        //  Load
        // ─────────────────────────────────────────────
        private void CustomerForm_Load(object sender, EventArgs e)
        {
            try
            {
                SetFormMode(FormMode.View);
                LoadAllCustomers();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Failed to load Customers:\n\n{ex.Message}",
                    "Load Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // ─────────────────────────────────────────────
        //  Grid events
        // ─────────────────────────────────────────────
        private void DgvCustomers_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvCustomers.SelectedRows.Count == 0) return;

            var row = dgvCustomers.SelectedRows[0];
            _selectedCustomerId = Convert.ToInt32(row.Cells["colId"].Value);

            txtFirstName.Text = row.Cells["colFirstName"].Value?.ToString() ?? "";
            txtLastName.Text = row.Cells["colLastName"].Value?.ToString() ?? "";
            txtPhone.Text = row.Cells["colPhone"].Value?.ToString() ?? "";
            txtEmail.Text = row.Cells["colEmail"].Value?.ToString() ?? "";
            txtAddress.Text = row.Cells["colAddress"].Value?.ToString() ?? "";
            txtCity.Text = row.Cells["colCity"].Value?.ToString() ?? "";
            txtNotes.Text = row.Cells["colNotes"].Value?.ToString() ?? "";
            txtNationalId.Text = row.Cells["colNationalId"].Value?.ToString() ?? "";

            bool isSecretary = _currentEmployee == null ||
                               _currentEmployee.Role == "Secretary";
            btnEdit.Enabled = isSecretary;
            btnDelete.Enabled = isSecretary;
            btnViewAnimals.Enabled = true;
        }

        private void DgvCustomers_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;
            BtnEdit_Click(sender, e);
        }

        // ─────────────────────────────────────────────
        //  CRUD button handlers
        // ─────────────────────────────────────────────
        private void BtnAdd_Click(object sender, EventArgs e)
        {
            ClearForm();
            _selectedCustomerId = -1;
            _isEditing = false;
            SetFormMode(FormMode.Edit);
            txtFirstName.Focus();
        }

        private void BtnEdit_Click(object sender, EventArgs e)
        {
            if (_selectedCustomerId < 0)
            {
                MessageBox.Show("Please select a customer to edit.",
                    "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            _isEditing = true;
            SetFormMode(FormMode.Edit);
            txtFirstName.Focus();
        }

        private void BtnViewAnimals_Click(object sender, EventArgs e)
        {
            if (_selectedCustomerId < 0) return;

            // Get customer name
            string custName = "";
            if (dgvCustomers.SelectedRows.Count > 0)
                custName = dgvCustomers.SelectedRows[0].Cells["colFullName"].Value?.ToString() ?? "";

            // Query animals for this customer
            try
            {
                string sql = @"
                    SELECT a.AnimalId, a.Name, t.TypeName, a.Breed,
                           a.DateOfBirth, a.Weight, a.Microchip, a.VaccineDate
                    FROM   Animals a
                    LEFT JOIN AnimalTypes t ON a.AnimalTypeId = t.AnimalTypeId
                    WHERE  a.OwnerId = @OwnerId AND a.IsActive = 1
                    ORDER  BY a.Name;";

                DataTable dt = DatabaseHelper.Instance.ExecuteQuery(sql,
                    new SQLiteParameter("@OwnerId", _selectedCustomerId));

                if (dt.Rows.Count == 0)
                {
                    MessageBox.Show($"No animals registered for {custName}.",
                        "Animals", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                // Build display string
                var sb = new System.Text.StringBuilder();
                sb.AppendLine($"Animals registered to: {custName}");
                sb.AppendLine(new string('-', 50));
                foreach (DataRow r in dt.Rows)
                {
                    sb.AppendLine($"  Name: {r["Name"]}");
                    sb.AppendLine($"  Type: {r["TypeName"]}");
                    if (!string.IsNullOrEmpty(r["Weight"]?.ToString()))
                        sb.AppendLine($"  Weight: {r["Weight"]} kg");
                    if (!string.IsNullOrEmpty(r["Microchip"]?.ToString()))
                        sb.AppendLine($"  Chip: {r["Microchip"]}");
                    if (!string.IsNullOrEmpty(r["VaccineDate"]?.ToString()))
                        sb.AppendLine($"  Last Vaccine: {r["VaccineDate"]}");
                    sb.AppendLine();
                }

                MessageBox.Show(sb.ToString(), $"Animals of {custName} ({dt.Rows.Count} found)",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading animals:\n\n" + ex.Message,
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
            if (_selectedCustomerId < 0)
            {
                MessageBox.Show("Please select a customer to delete.",
                    "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            string name = $"{txtFirstName.Text.Trim()} {txtLastName.Text.Trim()}";
            var confirm = MessageBox.Show(
                $"Are you sure you want to delete customer:\n\n\"{name}\"?\n\nThis action cannot be undone.",
                "Confirm Delete",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning,
                MessageBoxDefaultButton.Button2);

            if (confirm != DialogResult.Yes) return;

            try
            {
                // Soft delete - preserves visit history
                DatabaseHelper.Instance.ExecuteNonQuery(
                    "UPDATE Customers SET IsActive = 0, UpdatedAt = DATETIME('now') WHERE CustomerId = @Id;",
                    new SQLiteParameter("@Id", _selectedCustomerId));

                MessageBox.Show($"Customer \"{name}\" has been deleted.",
                    "Deleted", MessageBoxButtons.OK, MessageBoxIcon.Information);

                ClearForm();
                SetFormMode(FormMode.View);
                LoadAllCustomers();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Failed to delete customer:\n\n{ex.Message}",
                    "Delete Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnSave_Click(object sender, EventArgs e)
        {
            if (!ValidateAll()) return;

            try
            {
                if (_isEditing)
                    UpdateCustomer();
                else
                    InsertCustomer();

                string action = _isEditing ? "updated" : "added";
                MessageBox.Show(
                    $"Customer \"{txtFirstName.Text.Trim()} {txtLastName.Text.Trim()}\" {action} successfully.",
                    "Saved", MessageBoxButtons.OK, MessageBoxIcon.Information);

                SetFormMode(FormMode.View);
                LoadAllCustomers();
            }
            catch (SQLiteException ex) when (ex.Message.Contains("UNIQUE"))
            {
                MessageBox.Show(
                    "A customer with this email already exists.\nPlease use a different email address.",
                    "Duplicate Email", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Failed to save customer:\n\n{ex.Message}",
                    "Save Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnCancel_Click(object sender, EventArgs e)
        {
            ClearForm();
            SetFormMode(FormMode.View);
            _isEditing = false;
        }

        // ─────────────────────────────────────────────
        //  Search handlers
        // ─────────────────────────────────────────────
        private void BtnSearchById_Click(object sender, EventArgs e)
        {
            string term = txtSearchById.Text.Trim();
            if (string.IsNullOrWhiteSpace(term))
            {
                MessageBox.Show("Please enter an ID to search.",
                    "Search", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            if (!Regex.IsMatch(term, @"^\d{1,9}$"))
            {
                MessageBox.Show("ID must be numeric (up to 9 digits).",
                    "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            LoadCustomers(
                @"SELECT CustomerId, FirstName, LastName, Phone, Email,
                         Address, City, Notes, NationalId
                  FROM   Customers
                  WHERE  IsActive   = 1
                    AND  NationalId = @Term;",
                new SQLiteParameter("@Term", term));

            lblSearchStatus.Text = $"Results for ID: {term}";
        }

        private void BtnSearchByPhone_Click(object sender, EventArgs e)
        {
            string term = txtSearchByPhone.Text.Trim();
            if (string.IsNullOrWhiteSpace(term))
            {
                MessageBox.Show("Please enter a phone number to search.",
                    "Search", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            LoadCustomers(
                @"SELECT CustomerId, FirstName, LastName, Phone, Email,
                         Address, City, Notes, NationalId
                  FROM   Customers
                  WHERE  IsActive = 1
                    AND  Phone LIKE @Term;",
                new SQLiteParameter("@Term", $"%{term}%"));

            lblSearchStatus.Text = $"Results for phone: {term}";
        }

        private void BtnClearSearch_Click(object sender, EventArgs e)
        {
            txtSearchById.Clear();
            txtSearchByPhone.Clear();
            lblSearchStatus.Text = string.Empty;
            LoadAllCustomers();
        }

        // ─────────────────────────────────────────────
        //  Data loading
        // ─────────────────────────────────────────────
        private void LoadAllCustomers()
        {
            LoadCustomers(
                @"SELECT CustomerId, FirstName, LastName, Phone, Email,
                         Address, City, Notes, NationalId
                  FROM   Customers
                  WHERE  IsActive = 1
                  ORDER  BY LastName, FirstName;");

            lblSearchStatus.Text = string.Empty;
        }

        private void LoadCustomers(string sql, params SQLiteParameter[] parameters)
        {
            try
            {
                DataTable dt = DatabaseHelper.Instance.ExecuteQuery(sql, parameters);
                PopulateGrid(dt);
                lblRecordCount.Text = $"{dt.Rows.Count} record{(dt.Rows.Count != 1 ? "s" : "")}";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Failed to load customers:\n\n{ex.Message}",
                    "Load Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void PopulateGrid(DataTable dt)
        {
            dgvCustomers.Rows.Clear();

            foreach (DataRow row in dt.Rows)
            {
                int idx = dgvCustomers.Rows.Add(
                    row["CustomerId"],                           // colId
                    $"{row["FirstName"]} {row["LastName"]}",     // colFullName
                    row["Phone"],                                // colPhone
                    row["Email"],                                // colEmail
                    row["City"],                                 // colCity
                    row["NationalId"],                           // colNationalId
                    row["FirstName"],                            // colFirstName (hidden)
                    row["LastName"],                             // colLastName  (hidden)
                    row["Address"],                              // colAddress   (hidden)
                    row["Notes"]);                               // colNotes     (hidden)

                // Alternate row shading
                dgvCustomers.Rows[idx].DefaultCellStyle.BackColor =
                    idx % 2 == 0
                        ? UITheme.BgCard
                        : UITheme.BgInput;
            }

            ClearForm();
            btnEdit.Enabled = false;
            btnDelete.Enabled = false;
            _selectedCustomerId = -1;
        }

        // ─────────────────────────────────────────────
        //  Database CRUD
        // ─────────────────────────────────────────────
        private void InsertCustomer()
        {
            const string sql = @"
                INSERT INTO Customers
                    (FirstName, LastName, Phone, Email, Address, City, Notes, NationalId, IsActive)
                VALUES
                    (@FirstName, @LastName, @Phone, @Email, @Address, @City, @Notes, @NationalId, 1);";

            DatabaseHelper.Instance.ExecuteNonQuery(sql, BuildParams());
        }

        private void UpdateCustomer()
        {
            const string sql = @"
                UPDATE Customers SET
                    FirstName  = @FirstName,
                    LastName   = @LastName,
                    Phone      = @Phone,
                    Email      = @Email,
                    Address    = @Address,
                    City       = @City,
                    Notes      = @Notes,
                    NationalId = @NationalId,
                    UpdatedAt  = DATETIME('now')
                WHERE CustomerId = @Id;";

            var p = BuildParams();
            Array.Resize(ref p, p.Length + 1);
            p[p.Length - 1] = new SQLiteParameter("@Id", _selectedCustomerId);

            DatabaseHelper.Instance.ExecuteNonQuery(sql, p);
        }

        private SQLiteParameter[] BuildParams() => new[]
        {
            new SQLiteParameter("@FirstName",  txtFirstName.Text.Trim()),
            new SQLiteParameter("@LastName",   txtLastName.Text.Trim()),
            new SQLiteParameter("@Phone",      txtPhone.Text.Trim()),
            new SQLiteParameter("@Email",      txtEmail.Text.Trim()),
            new SQLiteParameter("@Address",    txtAddress.Text.Trim()),
            new SQLiteParameter("@City",       txtCity.Text.Trim()),
            new SQLiteParameter("@Notes",      txtNotes.Text.Trim()),
            new SQLiteParameter("@NationalId", txtNationalId.Text.Trim())
        };

        // ─────────────────────────────────────────────
        //  Validation
        // ─────────────────────────────────────────────
        private bool ValidateAll()
        {
            ClearAllErrors();
            bool ok = true;

            // First name - letters only (including Hebrew)
            string fn = txtFirstName.Text.Trim();
            if (string.IsNullOrWhiteSpace(fn))
            { ShowError(txtFirstName, lblErrFirstName, "First name is required."); ok = false; }
            else if (!Regex.IsMatch(fn.Trim(), @"^[\p{L}\s\-']+$"))
            { ShowError(txtFirstName, lblErrFirstName, "Letters only."); ok = false; }

            // Last name - letters only
            string ln = txtLastName.Text.Trim();
            if (string.IsNullOrWhiteSpace(ln))
            { ShowError(txtLastName, lblErrLastName, "Last name is required."); ok = false; }
            else if (!Regex.IsMatch(ln.Trim(), @"^[\p{L}\s\-']+$"))
            { ShowError(txtLastName, lblErrLastName, "Letters only."); ok = false; }

            // Phone - Israeli mobile / landline formats
            string phone = txtPhone.Text.Trim();
            if (string.IsNullOrWhiteSpace(phone))
            { ShowError(txtPhone, lblErrPhone, "Phone number is required."); ok = false; }
            else if (!Regex.IsMatch(phone, @"^(\+972|0)[0-9\-\s]{7,13}$"))
            { ShowError(txtPhone, lblErrPhone, "Enter a valid phone number."); ok = false; }

            // Email
            string email = txtEmail.Text.Trim();
            if (!string.IsNullOrWhiteSpace(email) &&
                !Regex.IsMatch(email, @"^[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}$"))
            { ShowError(txtEmail, lblErrEmail, "Invalid email format."); ok = false; }

            // National ID - exactly 9 digits
            string nid = txtNationalId.Text.Trim();
            if (string.IsNullOrWhiteSpace(nid))
            { ShowError(txtNationalId, lblErrNationalId, "National ID is required."); ok = false; }
            else if (!Regex.IsMatch(nid, @"^\d{9}$"))
            { ShowError(txtNationalId, lblErrNationalId, "Must be exactly 9 digits."); ok = false; }

            if (!ok)
                MessageBox.Show("Please fix the highlighted fields.",
                    "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);

            return ok;
        }

        private static bool IsValidIsraeliId(string id)
        {
            int sum = 0;
            for (int i = 0; i < 9; i++)
            {
                int d = id[i] - '0';
                if (i % 2 != 0) d *= 2;
                if (d > 9) d -= 9;
                sum += d;
            }
            return sum % 10 == 0;
        }

        // ─────────────────────────────────────────────
        //  Error helpers
        // ─────────────────────────────────────────────
        private void ShowError(TextBox txt, Label lbl, string msg)
        {
            lbl.Text = "⚠  " + msg;
            lbl.Visible = true;
            txt.BackColor = UITheme.SemanticDangerBg;
        }

        private void ClearAllErrors()
        {
            foreach (var (txt, lbl) in new[]
            {
                (txtFirstName,  lblErrFirstName),
                (txtLastName,   lblErrLastName),
                (txtPhone,      lblErrPhone),
                (txtEmail,      lblErrEmail),
                (txtNationalId, lblErrNationalId)
            })
            {
                lbl.Text = string.Empty;
                lbl.Visible = false;
                txt.BackColor = UITheme.BgInput;
            }
        }

        // ─────────────────────────────────────────────
        //  UI state helpers
        // ─────────────────────────────────────────────
        private enum FormMode { View, Edit }

        private void SetFormMode(FormMode mode)
        {
            bool editing = mode == FormMode.Edit;

            // Input fields
            foreach (Control c in pnlForm.Controls)
                if (c is TextBox tb) tb.ReadOnly = !editing;

            // Button visibility
            btnAdd.Visible = !editing;
            btnEdit.Visible = !editing;
            btnDelete.Visible = !editing;
            btnSave.Visible = editing;
            btnCancel.Visible = editing;

            // Panel header label
            lblFormTitle.Text = editing
                ? (_isEditing ? "✏  Edit Customer" : "＋  New Customer")
                : "Customer Details";

            pnlForm.BackColor = editing
                ? UITheme.BgCardHover
                : UITheme.BgCard;

            // Grid interactivity
            dgvCustomers.Enabled = !editing;
        }

        private void ClearForm()
        {
            txtFirstName.Text = string.Empty;
            txtLastName.Text = string.Empty;
            txtPhone.Text = string.Empty;
            txtEmail.Text = string.Empty;
            txtAddress.Text = string.Empty;
            txtCity.Text = string.Empty;
            txtNotes.Text = string.Empty;
            txtNationalId.Text = string.Empty;
            ClearAllErrors();
        }
    }
}