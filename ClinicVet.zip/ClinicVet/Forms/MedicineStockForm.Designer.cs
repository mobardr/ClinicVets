using System.Drawing;
using System.Windows.Forms;
using ClinicVets.UI;

namespace ClinicVets.Forms
{
    partial class MedicineStockForm
    {
        private System.ComponentModel.IContainer components = null;

        private Panel pnlToolbar;
        private Label lblPageTitle;
        private Button btnAdd, btnEdit, btnDelete, btnSave, btnCancel;

        private Panel pnlStatsRow;
        private Panel pnlStatTotal, pnlStatLow, pnlStatOut, pnlStatValue;

        private Panel pnlSearch;
        private TextBox txtSearch;
        private Button btnSearch, btnClearSearch;
        private Label lblSearchStatus, lblMedCount;

        private Panel pnlMain, pnlLeft, pnlSplitter, pnlRight;

        private DataGridView dgvMedicines;
        private DataGridViewTextBoxColumn colMedId, colMedName, colMedDesc;
        private DataGridViewTextBoxColumn colMedUnit, colMedStock, colMedStockRaw;
        private DataGridViewTextBoxColumn colMedUnitPriceRaw, colMedReorderRaw;
        private DataGridViewTextBoxColumn colMedStatus;

        private Panel pnlDetail;
        private Label lblFormTitle;
        private Label lName, lDesc, lUnit, lQty, lLow, lPrice;
        private Label lblErrName, lblErrUnit, lblErrStockQty, lblErrReorderLevel, lblErrUnitPrice;
        private TextBox txtName, txtDescription, txtUnit, txtStockQty, txtReorderLevel, txtUnitPrice;
        private Panel pnlStockBar;
        private Label lblStockStatus;

        private Panel pnlRestock;
        private Label lblRestockTitle;
        private Button btnRestockAdd, btnRestockSet;
        private TextBox txtRestockQty;
        private Button btnRestock;

        protected override void Dispose(bool disposing)
        {
            if (disposing && components != null) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.BackColor = UITheme.BgRoot;
            this.Dock = DockStyle.Fill;
            this.Font = UITheme.FontBody;
            this.DoubleBuffered = true;
            this.SetStyle(ControlStyles.OptimizedDoubleBuffer |
                          ControlStyles.AllPaintingInWmPaint, true);

            // ── Toolbar ───────────────────────────────
            pnlToolbar = new Panel { Dock = DockStyle.Top, Height = UITheme.ToolbarH, BackColor = UITheme.BgToolbar };
            lblPageTitle = new Label
            {
                Text = "Medicine Stock",
                Font = UITheme.FontTitle,
                ForeColor = UITheme.TextPrimary,
                AutoSize = false,
                Size = new Size(280, UITheme.ToolbarH),
                Location = new Point(UITheme.SpaceLG, 0),
                TextAlign = System.Drawing.ContentAlignment.MiddleLeft,
                BackColor = UITheme.BgToolbar
            };
            btnAdd = new Button(); UITheme.StylePrimaryBtn(btnAdd, "＋  Add");
            btnEdit = new Button(); UITheme.StyleSecondaryBtn(btnEdit, "✏  Edit");
            btnDelete = new Button(); UITheme.StyleDangerBtn(btnDelete, "🗑  Delete");
            btnSave = new Button(); UITheme.StylePrimaryBtn(btnSave, "✔  Save");
            btnCancel = new Button(); UITheme.StyleGhostBtn(btnCancel, "✕  Cancel");
            foreach (var b in new[] { btnAdd, btnEdit, btnDelete, btnSave, btnCancel })
                b.Size = new Size(106, 34);
            btnSave.Visible = false; btnCancel.Visible = false;
            pnlToolbar.SizeChanged += (s, e) =>
            {
                int y = (UITheme.ToolbarH - 34) / 2;
                btnAdd.Location = new Point(pnlToolbar.Width - 116, y);
                btnEdit.Location = new Point(pnlToolbar.Width - 230, y);
                btnDelete.Location = new Point(pnlToolbar.Width - 344, y);
                btnSave.Location = new Point(pnlToolbar.Width - 116, y);
                btnCancel.Location = new Point(pnlToolbar.Width - 230, y);
                foreach (var b in new[] { btnAdd, btnEdit, btnDelete, btnSave, btnCancel })
                    b.Anchor = AnchorStyles.Right | AnchorStyles.Top;
            };
            pnlToolbar.Controls.AddRange(new Control[]
                { lblPageTitle, btnAdd, btnEdit, btnDelete, btnSave, btnCancel });

            // ── Stat row ──────────────────────────────
            pnlStatsRow = new Panel { Dock = DockStyle.Top, Height = UITheme.StatRowH, BackColor = UITheme.BgRoot };
            pnlStatTotal = UITheme.MakeStatCard("Total Items", "0", UITheme.AccentViolet, 170, 62);
            pnlStatLow = UITheme.MakeStatCard("Low Stock", "0", UITheme.SemanticWarning, 170, 62);
            pnlStatOut = UITheme.MakeStatCard("Out of Stock", "0", UITheme.SemanticDanger, 170, 62);
            pnlStatValue = UITheme.MakeStatCard("Stock Value", "₪0", UITheme.Accent, 170, 62);
            int sx = UITheme.SpaceLG;
            foreach (var card in new[] { pnlStatTotal, pnlStatLow, pnlStatOut, pnlStatValue })
            {
                card.Location = new Point(sx, 6);
                foreach (Control c in card.Controls) c.BackColor = UITheme.BgCard;
                sx += 176;
            }
            pnlStatsRow.Controls.AddRange(new Control[] { pnlStatTotal, pnlStatLow, pnlStatOut, pnlStatValue });

            // ── Search bar ────────────────────────────
            pnlSearch = new Panel { Dock = DockStyle.Top, Height = UITheme.SearchBarH, BackColor = UITheme.BgSurface };
            var lS = new Label
            {
                Text = "Search:",
                Font = UITheme.FontLabel,
                ForeColor = UITheme.TextSecondary,
                AutoSize = false,
                Size = new Size(60, UITheme.SearchBarH),
                Location = new Point(UITheme.SpaceLG, 0),
                TextAlign = System.Drawing.ContentAlignment.MiddleRight,
                BackColor = UITheme.BgSurface
            };
            txtSearch = new TextBox
            {
                Size = new Size(220, UITheme.InputH),
                Location = new Point(86, (UITheme.SearchBarH - UITheme.InputH) / 2),
                Font = UITheme.FontInput,
                BorderStyle = BorderStyle.FixedSingle,
                BackColor = UITheme.BgInput,
                ForeColor = UITheme.TextPrimary
            };
            btnSearch = new Button(); UITheme.StyleSecondaryBtn(btnSearch, "Search");
            btnClearSearch = new Button(); UITheme.StyleGhostBtn(btnClearSearch, "✕ Clear");
            btnSearch.Size = btnClearSearch.Size = new Size(80, UITheme.InputH);
            btnSearch.Location = new Point(314, (UITheme.SearchBarH - UITheme.InputH) / 2);
            btnClearSearch.Location = new Point(402, (UITheme.SearchBarH - UITheme.InputH) / 2);
            lblSearchStatus = new Label
            {
                Text = "",
                Font = UITheme.FontLabel,
                ForeColor = UITheme.TextMuted,
                AutoSize = false,
                Size = new Size(180, UITheme.SearchBarH),
                Location = new Point(498, 0),
                TextAlign = System.Drawing.ContentAlignment.MiddleLeft,
                BackColor = UITheme.BgSurface
            };
            lblMedCount = new Label
            {
                Text = "",
                Font = UITheme.FontLabel,
                ForeColor = UITheme.Accent,
                AutoSize = false,
                Size = new Size(130, UITheme.SearchBarH),
                Location = new Point(682, 0),
                TextAlign = System.Drawing.ContentAlignment.MiddleLeft,
                BackColor = UITheme.BgSurface
            };
            pnlSearch.Controls.AddRange(new Control[]
                { lS, txtSearch, btnSearch, btnClearSearch, lblSearchStatus, lblMedCount });

            // ── Main split ────────────────────────────
            pnlMain = new Panel { Dock = DockStyle.Fill, BackColor = UITheme.BgRoot };
            pnlLeft = new Panel { Dock = DockStyle.Left, Width = 600, BackColor = UITheme.BgSurface };
            // Responsive: left panel = 55% of parent, clamped
            pnlMain.Resize += (s, e) =>
            {
                if (pnlMain.Width < 1) return;
                int lw = System.Math.Max(600, System.Math.Min(
                    (int)(pnlMain.Width * 0.58f), pnlMain.Width - 280));
                pnlLeft.Width = lw;
            };
            pnlSplitter = new Panel { Dock = DockStyle.Left, Width = 1, BackColor = UITheme.BorderDefault };
            pnlRight = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = UITheme.BgSurface,
                AutoScroll = true,
                Padding = new Padding(UITheme.SpaceLG)
            };

            // ── Grid ──────────────────────────────────
            dgvMedicines = new DataGridView { Dock = DockStyle.Fill };
            UITheme.StyleGrid(dgvMedicines);
            colMedId = C("colMedId", "ID", 50, false);
            colMedName = C("colMedName", "Name", 180, true);
            colMedUnit = C("colMedUnit", "Unit", 80, true);
            colMedStock = C("colMedStock", "Stock", 80, true);
            colMedUnitPriceRaw = C("colMedUnitPriceRaw", "Price ₪", 90, true);
            colMedStatus = C("colMedStatus", "Status", 90, true);
            colMedStockRaw = C("colMedStockRaw", "", 0, false);
            colMedReorderRaw = C("colMedReorderRaw", "", 0, false);
            colMedDesc = C("colMedDesc", "Description", 0, false);
            dgvMedicines.Columns.AddRange(new DataGridViewColumn[]
            {
                colMedId, colMedName, colMedUnit, colMedStock,
                colMedUnitPriceRaw, colMedStatus,
                colMedStockRaw, colMedReorderRaw, colMedDesc
            });
            pnlLeft.Controls.Add(dgvMedicines);

            // ── Detail form ───────────────────────────
            int fy = 0, fw = 320;
            pnlDetail = new Panel { Dock = DockStyle.Top, Height = 420, BackColor = UITheme.BgSurface };
            lblFormTitle = new Label
            {
                Text = "Medicine Details",
                Font = UITheme.FontSubtitle,
                ForeColor = UITheme.TextPrimary,
                AutoSize = false,
                Size = new Size(fw, 30),
                Location = new Point(0, fy),
                BackColor = UITheme.BgSurface
            }; fy += 36;
            (lName, txtName, lblErrName) = F("Medicine Name *", 0, fy, fw); fy += 58;
            (lUnit, txtUnit, lblErrUnit) = F("Unit (tablet, ml…)", 0, fy, fw); fy += 58;
            (lQty, txtStockQty, lblErrStockQty) = F("Stock Quantity", 0, fy, fw); fy += 58;
            (lLow, txtReorderLevel, lblErrReorderLevel) = F("Reorder Level", 0, fy, fw); fy += 58;
            (lPrice, txtUnitPrice, lblErrUnitPrice) = F("Unit Price (₪)", 0, fy, fw); fy += 58;
            lDesc = new Label
            {
                Text = "Description",
                Font = UITheme.FontLabel,
                ForeColor = UITheme.TextSecondary,
                AutoSize = false,
                Size = new Size(fw, 18),
                Location = new Point(0, fy),
                BackColor = UITheme.BgSurface
            };
            txtDescription = new TextBox
            {
                Size = new Size(fw, 60),
                Location = new Point(0, fy + 20),
                Font = UITheme.FontInput,
                BorderStyle = BorderStyle.FixedSingle,
                BackColor = UITheme.BgInput,
                ForeColor = UITheme.TextPrimary,
                Multiline = true
            };
            fy += 86;
            pnlStockBar = new Panel
            {
                Size = new Size(fw, 6),
                Location = new Point(0, fy),
                BackColor = UITheme.Accent
            };
            lblStockStatus = new Label
            {
                Text = "",
                Font = UITheme.FontLabel,
                ForeColor = UITheme.TextSecondary,
                AutoSize = false,
                Size = new Size(fw, 18),
                Location = new Point(0, fy + 10),
                BackColor = UITheme.BgSurface
            };
            pnlDetail.Controls.AddRange(new Control[]
            {
                lblFormTitle,
                lName, txtName, lblErrName,
                lUnit, txtUnit, lblErrUnit,
                lQty, txtStockQty, lblErrStockQty,
                lLow, txtReorderLevel, lblErrReorderLevel,
                lPrice, txtUnitPrice, lblErrUnitPrice,
                lDesc, txtDescription, pnlStockBar, lblStockStatus
            });

            // ── Restock ───────────────────────────────
            pnlRestock = new Panel { Dock = DockStyle.Fill, BackColor = UITheme.BgSurface };
            lblRestockTitle = new Label
            {
                Text = "Quick Restock",
                Font = UITheme.FontSubtitle,
                ForeColor = UITheme.TextPrimary,
                AutoSize = false,
                Size = new Size(fw, 28),
                Location = new Point(0, 0),
                BackColor = UITheme.BgSurface
            };
            btnRestockAdd = new Button(); UITheme.StyleSecondaryBtn(btnRestockAdd, "Add to stock");
            btnRestockSet = new Button(); UITheme.StyleGhostBtn(btnRestockSet, "Set exact qty");
            btnRestockAdd.Size = btnRestockSet.Size = new Size((fw - 8) / 2, 34);
            btnRestockAdd.Location = new Point(0, 36);
            btnRestockSet.Location = new Point((fw - 8) / 2 + 8, 36);
            var lRQ = new Label
            {
                Text = "Quantity",
                Font = UITheme.FontLabel,
                ForeColor = UITheme.TextSecondary,
                AutoSize = false,
                Size = new Size(fw, 18),
                Location = new Point(0, 80),
                BackColor = UITheme.BgSurface
            };
            txtRestockQty = new TextBox
            {
                Size = new Size(fw, UITheme.InputH),
                Location = new Point(0, 100),
                Font = UITheme.FontInput,
                BorderStyle = BorderStyle.FixedSingle,
                BackColor = UITheme.BgInput,
                ForeColor = UITheme.TextPrimary,
                Text = "0"
            };
            btnRestock = new Button(); UITheme.StylePrimaryBtn(btnRestock, "✔  Apply");
            btnRestock.Size = new Size(fw, 38); btnRestock.Location = new Point(0, 144);
            pnlRestock.Controls.AddRange(new Control[]
                { lblRestockTitle, btnRestockAdd, btnRestockSet, lRQ, txtRestockQty, btnRestock });

            pnlRight.Controls.Add(pnlRestock);
            pnlRight.Controls.Add(pnlDetail);
            pnlMain.Controls.Add(pnlRight);
            pnlMain.Controls.Add(pnlSplitter);
            pnlMain.Controls.Add(pnlLeft);
            this.Controls.AddRange(new Control[]
                { pnlMain, pnlSearch, pnlStatsRow, pnlToolbar });
        }

        private static DataGridViewTextBoxColumn C(string n, string h, int w, bool v) =>
            new DataGridViewTextBoxColumn
            {
                Name = n,
                HeaderText = h,
                MinimumWidth = w > 0 ? w : 40,
                Visible = v,
                SortMode = DataGridViewColumnSortMode.Automatic
            };

        private static (Label, TextBox, Label) F(string label, int x, int y, int w)
        {
            var l = new Label
            {
                Text = label,
                Font = UITheme.FontLabel,
                ForeColor = UITheme.TextSecondary,
                AutoSize = false,
                Size = new Size(w, 18),
                Location = new Point(x, y),
                BackColor = UITheme.BgSurface
            };
            var t = new TextBox
            {
                Size = new Size(w, UITheme.InputH),
                Location = new Point(x, y + 20),
                Font = UITheme.FontInput,
                BorderStyle = BorderStyle.FixedSingle,
                BackColor = UITheme.BgInput,
                ForeColor = UITheme.TextPrimary
            };
            var e = new Label
            {
                Text = "",
                Font = new Font("Segoe UI", 7.8f),
                ForeColor = UITheme.SemanticDanger,
                AutoSize = false,
                Size = new Size(w, 14),
                Location = new Point(x, y + 20 + UITheme.InputH + 1),
                BackColor = UITheme.BgSurface,
                Visible = false
            };
            return (l, t, e);
        }
    }
}