using System.Drawing;
using System.Windows.Forms;
using ClinicVets.UI;

namespace ClinicVets.Forms
{
    partial class VisitForm
    {
        private System.ComponentModel.IContainer components = null;

        private Panel pnlToolbar;
        private Panel pnlBody;
        private Panel pnlListCol;
        private Panel pnlSplitter1;
        private Panel pnlDetailCol;
        private Panel pnlSplitter2;
        private Panel pnlSummaryCol;
        private Panel pnlMedicineAdd;
        private Panel pnlVaccineWarning;
        private Panel pnlPriceSummary;

        private Label lblPageTitle;
        private Label lblCurrentDateTime;
        private Label lblVisitCount;
        private Button btnNewVisit;
        private Button btnDeleteVisit;
        private Button btnMarkPaid;
        private Button btnSaveVisit;
        private Button btnCancelVisit;

        private DataGridView dgvVisits;
        private DataGridViewTextBoxColumn colVisitId, colDate, colAnimalName;
        private DataGridViewTextBoxColumn colTypeName, colVetName, colReason;
        private DataGridViewTextBoxColumn colStatus, colTotal, colOwnerName;

        private Label lblFormTitle;
        private Label lblAnimalLabel, lblVetLabel, lblStatusLabel;
        private Label lblReasonLabel, lblDiagnosisLabel, lblTreatmentLabel, lblNotesLabel;
        private ComboBox cmbAnimal, cmbVeterinarian, cmbStatus;
        private TextBox txtReason, txtDiagnosis, txtTreatment, txtNotes;
        private DateTimePicker dtpVisitDate;
        private TextBox txtVisitTime;
        private Label lblVisitDateLabel, lblVisitTimeLabel;
        private Label lblVaccineWarning;

        private Label lblMedicineLabel, lblQtyLabel, lblPriceLabel;
        private Label lblDosageLabel, lblInstrLabel, lblMedicineLineTotal;
        private ComboBox cmbMedicine;
        private TextBox txtMedicineQty, txtMedicinePrice, txtMedicineDosage, txtMedicineInstructions;
        private Button btnAddMedicine, btnRemoveMedicine;

        private DataGridView dgvMedicines;
        private DataGridViewTextBoxColumn dgvMedId, dgvMedName, dgvMedUnitPrice;
        private DataGridViewTextBoxColumn dgvMedQty, dgvMedUnit, dgvMedLineTotal;
        private DataGridViewTextBoxColumn dgvMedDosage, dgvMedInstructions;

        private Label lblConsultationKey, lblConsultationFee;
        private Label lblMedicinesTotalKey, lblMedicinesTotal;
        private Label lblGrandTotalKey, lblGrandTotal;
        private Button btnMarkPaidSummary;

        private System.Windows.Forms.Timer clockTimer;

        protected override void Dispose(bool disposing)
        {
            if (disposing && components != null) components.Dispose();
            clockTimer?.Stop(); clockTimer?.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.BackColor = UITheme.BgRoot;
            this.Dock = DockStyle.Fill;
            this.Font = UITheme.FontBody;
            this.DoubleBuffered = true;
            this.SetStyle(ControlStyles.OptimizedDoubleBuffer |
                          ControlStyles.AllPaintingInWmPaint, true);

            var clrSurface = UITheme.BgSurface;
            var clrInput = UITheme.BgInput;
            var clrText = UITheme.TextPrimary;
            var clrSec = UITheme.TextSecondary;

            // Toolbar
            pnlToolbar = new Panel { Dock = DockStyle.Top, Height = UITheme.ToolbarH, BackColor = UITheme.BgToolbar };
            lblPageTitle = new Label
            {
                Text = "Visits",
                Font = UITheme.FontTitle,
                ForeColor = clrText,
                AutoSize = false,
                Size = new Size(200, UITheme.ToolbarH),
                Location = new Point(UITheme.SpaceLG, 0),
                TextAlign = System.Drawing.ContentAlignment.MiddleLeft,
                BackColor = UITheme.BgToolbar
            };
            lblCurrentDateTime = new Label
            {
                Text = "",
                Font = new Font("Segoe UI", 8.5f),
                ForeColor = UITheme.TextMuted,
                AutoSize = false,
                Size = new Size(220, UITheme.ToolbarH),
                Location = new Point(220, 0),
                TextAlign = System.Drawing.ContentAlignment.MiddleLeft,
                BackColor = UITheme.BgToolbar
            };
            lblVisitCount = new Label
            {
                Text = "",
                Font = UITheme.FontLabel,
                ForeColor = UITheme.TextMuted,
                AutoSize = false,
                Size = new Size(160, UITheme.ToolbarH),
                Location = new Point(450, 0),
                TextAlign = System.Drawing.ContentAlignment.MiddleLeft,
                BackColor = UITheme.BgToolbar
            };

            btnNewVisit = new Button(); UITheme.StylePrimaryBtn(btnNewVisit, "＋  New Visit");
            btnDeleteVisit = new Button(); UITheme.StyleDangerBtn(btnDeleteVisit, "🗑  Delete");
            btnMarkPaid = new Button(); UITheme.StyleAmberBtn(btnMarkPaid, "✓  Mark Paid");
            btnSaveVisit = new Button(); UITheme.StylePrimaryBtn(btnSaveVisit, "✔  Save");
            btnCancelVisit = new Button(); UITheme.StyleGhostBtn(btnCancelVisit, "✕  Cancel");
            foreach (var b in new[] { btnNewVisit, btnDeleteVisit, btnMarkPaid, btnSaveVisit, btnCancelVisit })
                b.Size = new Size(112, 34);
            btnSaveVisit.Visible = false; btnCancelVisit.Visible = false;
            pnlToolbar.SizeChanged += (s, e) =>
            {
                int y = (UITheme.ToolbarH - 34) / 2;
                btnNewVisit.Location = new Point(pnlToolbar.Width - 122, y);
                btnDeleteVisit.Location = new Point(pnlToolbar.Width - 242, y);
                btnMarkPaid.Location = new Point(pnlToolbar.Width - 362, y);
                btnSaveVisit.Location = new Point(pnlToolbar.Width - 122, y);
                btnCancelVisit.Location = new Point(pnlToolbar.Width - 242, y);
                foreach (var b in new[] { btnNewVisit, btnDeleteVisit, btnMarkPaid, btnSaveVisit, btnCancelVisit })
                    b.Anchor = AnchorStyles.Right | AnchorStyles.Top;
            };
            pnlToolbar.Controls.AddRange(new Control[]
                { lblPageTitle, lblCurrentDateTime, lblVisitCount,
                  btnNewVisit, btnDeleteVisit, btnMarkPaid, btnSaveVisit, btnCancelVisit });

            // Body (three columns)
            pnlBody = new Panel { Dock = DockStyle.Fill, BackColor = UITheme.BgRoot };
            pnlListCol = new Panel { Dock = DockStyle.Left, Width = 460, BackColor = clrSurface };
            pnlBody.Resize += (s, e) =>
            {
                if (pnlBody.Width < 1) return;
                int lw = System.Math.Max(400, System.Math.Min(
                    (int)(pnlBody.Width * 0.40f), pnlBody.Width - 480));
                pnlListCol.Width = lw;
            };
            pnlSplitter1 = new Panel { Dock = DockStyle.Left, Width = 1, BackColor = UITheme.BorderDefault };
            pnlSummaryCol = new Panel { Dock = DockStyle.Right, Width = 240, BackColor = clrSurface };
            pnlSplitter2 = new Panel { Dock = DockStyle.Right, Width = 1, BackColor = UITheme.BorderDefault };
            pnlDetailCol = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = clrSurface,
                AutoScroll = true,
                Padding = new Padding(UITheme.SpaceLG)
            };

            // Visit list grid
            dgvVisits = new DataGridView { Dock = DockStyle.Fill };
            UITheme.StyleGrid(dgvVisits);
            colVisitId = C("colVisitId", "ID", 50, false);
            colDate = C("colDate", "Date", 90, true);
            colAnimalName = C("colAnimalName", "Animal", 110, true);
            colOwnerName = C("colOwnerName", "Owner", 110, true);
            colVetName = C("colVetName", "Vet", 110, true);
            colStatus = C("colStatus", "Status", 80, true);
            colTotal = C("colTotal", "Total ₪", 80, true);
            colReason = C("colReason", "Reason", 0, false);
            colTypeName = C("colTypeName", "Type", 0, false);
            dgvVisits.Columns.AddRange(new DataGridViewColumn[]
                { colVisitId, colDate, colAnimalName, colOwnerName, colVetName, colStatus, colTotal, colReason, colTypeName });
            pnlListCol.Controls.Add(dgvVisits);

            // Detail form
            int fy = 0, fw = 340;
            lblFormTitle = new Label
            {
                Text = "Visit Details",
                Font = UITheme.FontSubtitle,
                ForeColor = clrText,
                AutoSize = false,
                Size = new Size(fw, 30),
                Location = new Point(0, fy),
                BackColor = clrSurface
            }; fy += 36;

            // Visit Date (defaults to today)
            lblVisitDateLabel = new Label
            {
                Text = "Visit Date *",
                Font = new Font("Segoe UI", 8.5f, System.Drawing.FontStyle.Bold),
                ForeColor = UITheme.TextSecondary,
                AutoSize = false,
                Size = new System.Drawing.Size((fw - 10) / 2, 18),
                Location = new System.Drawing.Point(0, fy),
                BackColor = clrSurface
            };
            dtpVisitDate = new DateTimePicker
            {
                Size = new System.Drawing.Size((fw - 10) / 2, UITheme.InputH),
                Location = new System.Drawing.Point(0, fy + 20),
                Format = DateTimePickerFormat.Short,
                Font = UITheme.FontInput,
                Value = System.DateTime.Today,
                MaxDate = System.DateTime.Today.AddYears(1),
                MinDate = new System.DateTime(2000, 1, 1)
            };

            // Visit Time (defaults to now)
            lblVisitTimeLabel = new Label
            {
                Text = "Visit Time *",
                Font = new Font("Segoe UI", 8.5f, System.Drawing.FontStyle.Bold),
                ForeColor = UITheme.TextSecondary,
                AutoSize = false,
                Size = new System.Drawing.Size((fw - 10) / 2, 18),
                Location = new System.Drawing.Point((fw - 10) / 2 + 10, fy),
                BackColor = clrSurface
            };
            txtVisitTime = new TextBox
            {
                Size = new System.Drawing.Size((fw - 10) / 2, UITheme.InputH),
                Location = new System.Drawing.Point((fw - 10) / 2 + 10, fy + 20),
                Font = UITheme.FontInput,
                BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle,
                BackColor = UITheme.BgInput,
                ForeColor = UITheme.TextPrimary,
                Text = System.DateTime.Now.ToString("HH:mm")
            };
            fy += 58;

            (lblAnimalLabel, cmbAnimal, _) = Combo("Patient (Animal) *", 0, fy, fw); fy += 58;
            (lblVetLabel, cmbVeterinarian, _) = Combo("Veterinarian *", 0, fy, fw); fy += 58;
            (lblStatusLabel, cmbStatus, _) = Combo("Visit Status", 0, fy, fw);
            cmbStatus.Items.AddRange(new object[] { "Scheduled", "In Progress", "Completed", "Cancelled" });
            cmbStatus.SelectedIndex = 0; fy += 58;
            (lblReasonLabel, txtReason, _) = Field("Reason for Visit", 0, fy, fw, clrSurface); fy += 58;
            (lblDiagnosisLabel, txtDiagnosis, _) = Field("Diagnosis", 0, fy, fw, clrSurface); fy += 58;
            (lblTreatmentLabel, txtTreatment, _) = Field("Treatment", 0, fy, fw, clrSurface); fy += 58;
            (lblNotesLabel, txtNotes, _) = Field("Notes", 0, fy, fw, clrSurface); fy += 58;

            // Vaccine warning panel
            pnlVaccineWarning = new Panel
            {
                Size = new Size(fw, 36),
                Location = new Point(0, fy),
                BackColor = UITheme.SemanticWarningBg,
                Visible = false
            };
            lblVaccineWarning = new Label
            {
                Text = "⚠ Vaccination overdue",
                Font = UITheme.FontLabel,
                ForeColor = UITheme.SemanticWarning,
                AutoSize = false,
                Size = new Size(fw, 36),
                Location = new Point(UITheme.SpaceSM, 0),
                TextAlign = System.Drawing.ContentAlignment.MiddleLeft,
                BackColor = UITheme.SemanticWarningBg
            };
            pnlVaccineWarning.Controls.Add(lblVaccineWarning);
            fy += 44;

            // Medicine add section
            pnlMedicineAdd = new Panel
            {
                Size = new Size(fw, 280),
                Location = new Point(0, fy),
                BackColor = clrSurface
            };
            var lMedTitle = new Label
            {
                Text = "Add Medicine",
                Font = UITheme.FontSubtitle,
                ForeColor = clrText,
                AutoSize = false,
                Size = new Size(fw, 26),
                Location = new Point(0, 0),
                BackColor = clrSurface
            };
            int mx = 0, my = 30, mw = fw;
            (lblMedicineLabel, cmbMedicine, _) = Combo2("Medicine", mx, my, mw); my += 50;
            int hw = (mw - 8) / 2;
            (lblQtyLabel, txtMedicineQty, _) = Field("Quantity", mx, my, hw, clrSurface);
            (lblPriceLabel, txtMedicinePrice, _) = Field("Unit Price ₪  (auto-filled)", mx + hw + 8, my, hw, clrSurface); my += 50;
            (lblDosageLabel, txtMedicineDosage, _) = Field("Dosage", mx, my, mw, clrSurface); my += 50;
            (lblInstrLabel, txtMedicineInstructions, _) = Field("Instructions", mx, my, mw, clrSurface); my += 50;
            lblMedicineLineTotal = new Label
            {
                Text = "Line total: ₪0.00",
                Font = UITheme.FontLabel,
                ForeColor = UITheme.Accent,
                AutoSize = false,
                Size = new Size(mw, 20),
                Location = new Point(mx, my),
                BackColor = clrSurface
            };
            my += 26;
            btnAddMedicine = new Button(); UITheme.StylePrimaryBtn(btnAddMedicine, "＋  Add");
            btnRemoveMedicine = new Button(); UITheme.StyleDangerBtn(btnRemoveMedicine, "🗑  Remove");
            btnAddMedicine.Size = btnRemoveMedicine.Size = new Size(hw, 34);
            btnAddMedicine.Location = new Point(mx, my);
            btnRemoveMedicine.Location = new Point(mx + hw + 8, my);

            pnlMedicineAdd.Controls.AddRange(new Control[]
            {
                lMedTitle, lblMedicineLabel, cmbMedicine,
                lblQtyLabel, txtMedicineQty, lblPriceLabel, txtMedicinePrice,
                lblDosageLabel, txtMedicineDosage, lblInstrLabel, txtMedicineInstructions,
                lblMedicineLineTotal, btnAddMedicine, btnRemoveMedicine
            });

            // Medicines grid
            var lMedGridTitle = new Label
            {
                Text = "Prescribed Medicines",
                Font = UITheme.FontSubtitle,
                ForeColor = clrText,
                AutoSize = false,
                Size = new Size(fw, 26),
                Location = new Point(0, fy + 290),
                BackColor = clrSurface
            };
            var dgvMedContainer = new Panel
            {
                Size = new Size(fw, 150),
                Location = new Point(0, fy + 322),
                BackColor = clrSurface
            };
            dgvMedicines = new DataGridView { Dock = DockStyle.Fill };
            UITheme.StyleGrid(dgvMedicines);
            dgvMedId = C("dgvMedId", "ID", 0, false);
            dgvMedName = C("dgvMedName", "Medicine", 160, true);
            dgvMedQty = C("dgvMedQty", "Quantity", 70, true);
            dgvMedUnit = C("dgvMedUnit", "Unit", 60, true);
            dgvMedUnitPrice = C("dgvMedUnitPrice", "Unit Price ₪  (auto-filled)", 90, true);
            dgvMedLineTotal = C("dgvMedLineTotal", "Total ₪", 70, true);
            dgvMedDosage = C("dgvMedDosage", "Dosage", 0, false);
            dgvMedInstructions = C("dgvMedInstructions", "Instr.", 0, false);
            dgvMedicines.Columns.AddRange(new DataGridViewColumn[]
                { dgvMedId, dgvMedName, dgvMedQty, dgvMedUnit, dgvMedUnitPrice, dgvMedLineTotal,
                  dgvMedDosage, dgvMedInstructions });
            dgvMedContainer.Controls.Add(dgvMedicines);

            pnlDetailCol.Controls.AddRange(new Control[]
            {
                lblFormTitle, lblAnimalLabel, cmbAnimal, lblVetLabel, cmbVeterinarian,
                lblVisitDateLabel, dtpVisitDate, lblVisitTimeLabel, txtVisitTime,
                lblStatusLabel, cmbStatus, lblReasonLabel, txtReason,
                lblDiagnosisLabel, txtDiagnosis, lblTreatmentLabel, txtTreatment,
                lblNotesLabel, txtNotes, pnlVaccineWarning,
                pnlMedicineAdd, lMedGridTitle, dgvMedContainer
            });

            // Price summary column
            pnlPriceSummary = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = clrSurface,
                Padding = new Padding(UITheme.SpaceLG)
            };
            var lPriceTitle = new Label
            {
                Text = "Visit Summary",
                Font = UITheme.FontSubtitle,
                ForeColor = clrText,
                AutoSize = false,
                Size = new Size(200, 26),
                Location = new Point(0, 0),
                BackColor = clrSurface
            };

            lblConsultationKey = SumLabel("Consultation fee:", 0, 40, clrSurface);
            lblConsultationFee = SumLabel("₪80.00", 120, 40, clrSurface);
            lblConsultationFee.ForeColor = UITheme.Accent;
            lblMedicinesTotalKey = SumLabel("Medicines:", 0, 66, clrSurface);
            lblMedicinesTotal = SumLabel("₪0.00", 120, 66, clrSurface);
            var pDiv = new Panel { Size = new Size(200, 1), Location = new Point(0, 92), BackColor = UITheme.BorderDefault };
            lblGrandTotalKey = SumLabel("Total:", 0, 102, clrSurface);
            lblGrandTotalKey.Font = new Font("Segoe UI", 10f, FontStyle.Bold);
            lblGrandTotal = SumLabel("₪80.00", 120, 102, clrSurface);
            lblGrandTotal.ForeColor = UITheme.Accent;
            lblGrandTotal.Font = new Font("Segoe UI", 10f, FontStyle.Bold);

            btnMarkPaidSummary = new Button();
            UITheme.StyleAmberBtn(btnMarkPaidSummary, "✓  Mark as Paid");
            btnMarkPaidSummary.Size = new Size(190, 38);
            btnMarkPaidSummary.Location = new Point(0, 128);

            pnlPriceSummary.Controls.AddRange(new Control[]
            {
                lPriceTitle, lblConsultationKey, lblConsultationFee,
                lblMedicinesTotalKey, lblMedicinesTotal,
                pDiv, lblGrandTotalKey, lblGrandTotal, btnMarkPaidSummary
            });
            pnlSummaryCol.Controls.Add(pnlPriceSummary);

            // Live clock
            clockTimer = new System.Windows.Forms.Timer { Interval = 1000, Enabled = true };
            clockTimer.Tick += (s, e) =>
                lblCurrentDateTime.Text = System.DateTime.Now.ToString("ddd dd/MM/yyyy  HH:mm:ss");

            pnlBody.Controls.Add(pnlDetailCol);
            pnlBody.Controls.Add(pnlSplitter2);
            pnlBody.Controls.Add(pnlSummaryCol);
            pnlBody.Controls.Add(pnlSplitter1);
            pnlBody.Controls.Add(pnlListCol);
            this.Controls.AddRange(new Control[] { pnlBody, pnlToolbar });
        }

        private static DataGridViewTextBoxColumn C(string n, string h, int w, bool v) =>
            new DataGridViewTextBoxColumn
            {
                Name = n,
                HeaderText = h,
                MinimumWidth = w > 0 ? w : 40,
                Visible = v,
                SortMode = DataGridViewColumnSortMode.Automatic
            };

        private static (Label, ComboBox, Label) Combo(string lbl, int x, int y, int w)
        {
            var l = new Label
            {
                Text = lbl,
                Font = UITheme.FontLabel,
                ForeColor = UITheme.TextSecondary,
                AutoSize = false,
                Size = new Size(w, 18),
                Location = new Point(x, y),
                BackColor = UITheme.BgSurface
            };
            var c = new ComboBox
            {
                Size = new Size(w, UITheme.InputH),
                Location = new Point(x, y + 20),
                Font = UITheme.FontInput,
                FlatStyle = FlatStyle.Flat,
                BackColor = UITheme.BgInput,
                ForeColor = UITheme.TextPrimary,
                DropDownStyle = ComboBoxStyle.DropDownList
            };
            var e = new Label { BackColor = UITheme.BgSurface, Size = new Size(w, 0) };
            return (l, c, e);
        }

        private static (Label, ComboBox, Label) Combo2(string lbl, int x, int y, int w)
        {
            var (l, c, e) = Combo(lbl, x, y, w);
            return (l, c, e);
        }

        private static (Label, TextBox, Label) Field(string lbl, int x, int y, int w, Color bg)
        {
            var l = new Label
            {
                Text = lbl,
                Font = UITheme.FontLabel,
                ForeColor = UITheme.TextSecondary,
                AutoSize = false,
                Size = new Size(w, 18),
                Location = new Point(x, y),
                BackColor = bg
            };
            var t = new TextBox
            {
                Size = new Size(w, UITheme.InputH),
                Location = new Point(x, y + 20),
                Font = UITheme.FontInput,
                BorderStyle = BorderStyle.FixedSingle,
                BackColor = UITheme.BgInput,
                ForeColor = UITheme.TextPrimary
            };
            var e = new Label { BackColor = bg, Size = new Size(0, 0) };
            return (l, t, e);
        }

        private static Label SumLabel(string text, int x, int y, Color bg) =>
            new Label
            {
                Text = text,
                Font = UITheme.FontBody,
                ForeColor = UITheme.TextPrimary,
                AutoSize = false,
                Size = new Size(110, 22),
                Location = new Point(x, y),
                BackColor = bg
            };
    }
}