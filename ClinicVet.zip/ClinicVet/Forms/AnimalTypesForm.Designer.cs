using System.Drawing;
using System.Windows.Forms;
using ClinicVets.UI;

namespace ClinicVets.Forms
{
    partial class AnimalTypesForm
    {
        private System.ComponentModel.IContainer components = null;

        private Panel  pnlToolbar;
        private Label  lblPageTitle;
        private Button btnAdd, btnDelete;
        private Panel  pnlMain, pnlLeft, pnlSplitter, pnlRight;
        private DataGridView dgvTypes;
        private DataGridViewTextBoxColumn colTypeId, colTypeName, colDescription, colAnimalCount;
        private Panel  pnlAddForm;
        private Label  lblSelectedName, lblSelectedDescription;
        private Label  lblSelectedCount, lblTotalCount;
        private Label  lblErrTypeName;
        private Label  lblAddTitle;
        private Label  lblName, lblDesc;
        private Label  lblErrName;
        private TextBox txtTypeName, txtDescription;
        private Button  btnConfirmAdd, btnCancelAdd;

        protected override void Dispose(bool disposing)
        {
            if (disposing && components != null) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.BackColor     = UITheme.BgRoot;
            this.Dock          = DockStyle.Fill;
            this.Font          = UITheme.FontBody;
            this.DoubleBuffered = true;
            this.SetStyle(ControlStyles.OptimizedDoubleBuffer |
                          ControlStyles.AllPaintingInWmPaint, true);

            // Toolbar
            pnlToolbar = new Panel { Dock = DockStyle.Top, Height = UITheme.ToolbarH, BackColor = UITheme.BgToolbar };
            lblPageTitle = new Label { Text = "Animal Types", Font = UITheme.FontTitle,
                ForeColor = UITheme.TextPrimary, AutoSize = false,
                Size = new Size(300, UITheme.ToolbarH), Location = new Point(UITheme.SpaceLG, 0),
                TextAlign = System.Drawing.ContentAlignment.MiddleLeft, BackColor = UITheme.BgToolbar };
            btnAdd = new Button(); UITheme.StylePrimaryBtn(btnAdd, "＋  Add Type");
            btnDelete  = new Button(); UITheme.StyleDangerBtn(btnDelete,   "🗑  Delete");
            btnAdd.Size = btnDelete.Size = new Size(120, 34);
            pnlToolbar.SizeChanged += (s, e) =>
            {
                int y = (UITheme.ToolbarH - 34) / 2;
                btnAdd.Location = new Point(pnlToolbar.Width - 132, y);
                btnAdd.Anchor   = AnchorStyles.Right | AnchorStyles.Top;
                btnDelete.Location  = new Point(pnlToolbar.Width - 264, y);
                btnDelete.Anchor    = AnchorStyles.Right | AnchorStyles.Top;
            };
            pnlToolbar.Controls.AddRange(new Control[] { lblPageTitle, btnAdd, btnDelete });

            // Main split
            pnlMain     = new Panel { Dock = DockStyle.Fill, BackColor = UITheme.BgRoot };
            pnlLeft     = new Panel { Dock = DockStyle.Left, Width = 560, BackColor = UITheme.BgSurface };
            // Responsive: left panel = 55% of parent, clamped
            pnlMain.Resize += (s, e) =>
            {
                if (pnlMain.Width < 1) return;
                int lw = System.Math.Max(560, System.Math.Min(
                    (int)(pnlMain.Width * 0.58f), pnlMain.Width - 280));
                pnlLeft.Width = lw;
            };
            pnlSplitter = new Panel { Dock = DockStyle.Left, Width = 1, BackColor = UITheme.BorderDefault };
            pnlRight    = new Panel { Dock = DockStyle.Fill, BackColor = UITheme.BgSurface,
                Padding = new Padding(UITheme.SpaceLG) };

            // Grid
            dgvTypes = new DataGridView { Dock = DockStyle.Fill };
            UITheme.StyleGrid(dgvTypes);
            colTypeId      = C("colTypeId",      "ID",          50,  false);
            colTypeName    = C("colTypeName",    "Type Name",   180, true);
            colDescription = C("colDescription", "Description", 240, true);
            colAnimalCount = C("colAnimalCount", "Animals",     90,  true);
            dgvTypes.Columns.AddRange(new DataGridViewColumn[]
                { colTypeId, colTypeName, colDescription, colAnimalCount });
            pnlLeft.Controls.Add(dgvTypes);

            // Add form (right panel)
            pnlAddForm = new Panel { Dock = DockStyle.Fill, BackColor = UITheme.BgSurface, Visible = false };

            lblAddTitle = new Label { Text = "Add Animal Type", Font = UITheme.FontSubtitle,
                ForeColor = UITheme.TextPrimary, AutoSize = false, Size = new Size(360, 32),
                Location = new Point(0, 0), BackColor = UITheme.BgSurface };

            int fy = 44, fw = 340;
            lblName = L("Type Name *", 0, fy, fw);
            txtTypeName = new TextBox { Size = new Size(fw, UITheme.InputH), Location = new Point(0, fy+20),
                Font = UITheme.FontInput, BorderStyle = BorderStyle.FixedSingle,
                BackColor = UITheme.BgInput, ForeColor = UITheme.TextPrimary };
            lblErrTypeName = E(0, fy+20+UITheme.InputH+1, fw);
            fy += 62;

            lblDesc = L("Description", 0, fy, fw);
            txtDescription = new TextBox { Size = new Size(fw, 80), Location = new Point(0, fy+20),
                Font = UITheme.FontInput, BorderStyle = BorderStyle.FixedSingle,
                BackColor = UITheme.BgInput, ForeColor = UITheme.TextPrimary,
                Multiline = true, ScrollBars = ScrollBars.Vertical };
            fy += 102;

            btnConfirmAdd = new Button(); UITheme.StylePrimaryBtn(btnConfirmAdd, "✔  Save Type");
            btnCancelAdd  = new Button(); UITheme.StyleGhostBtn(btnCancelAdd,    "✕  Cancel");
            btnConfirmAdd.Size = btnCancelAdd.Size = new Size(140, 38);
            btnConfirmAdd.Location = new Point(0, fy);
            btnCancelAdd.Location  = new Point(148, fy);

            pnlAddForm.Controls.AddRange(new Control[]
            {
                lblAddTitle, lblName, txtTypeName, lblErrName,
                lblDesc, txtDescription, btnConfirmAdd, btnCancelAdd
            });

            // Selected type info labels
            lblSelectedName = new Label { Text = "Select a type",
                Font = UITheme.FontSubtitle, ForeColor = UITheme.TextPrimary,
                AutoSize = false, Size = new Size(340, 28), Location = new Point(0, 0),
                BackColor = UITheme.BgSurface };
            lblSelectedDescription = new Label { Text = "",
                Font = UITheme.FontBody, ForeColor = UITheme.TextSecondary,
                AutoSize = false, Size = new Size(340, 60), Location = new Point(0, 32),
                BackColor = UITheme.BgSurface };
            lblSelectedCount = new Label { Text = "",
                Font = UITheme.FontLabel, ForeColor = UITheme.Accent,
                AutoSize = false, Size = new Size(340, 20), Location = new Point(0, 98),
                BackColor = UITheme.BgSurface };
            lblTotalCount = new Label { Text = "",
                Font = UITheme.FontLabel, ForeColor = UITheme.TextMuted,
                AutoSize = false, Size = new Size(340, 20), Location = new Point(0, 124),
                BackColor = UITheme.BgSurface };
            pnlRight.Controls.AddRange(new Control[]
                { lblSelectedName, lblSelectedDescription, lblSelectedCount, lblTotalCount });

            pnlRight.Controls.Add(pnlAddForm);
            pnlMain.Controls.Add(pnlRight);
            pnlMain.Controls.Add(pnlSplitter);
            pnlMain.Controls.Add(pnlLeft);
            this.Controls.AddRange(new Control[] { pnlMain, pnlToolbar });
        }

        private static DataGridViewTextBoxColumn C(string n, string h, int w, bool v) =>
            new DataGridViewTextBoxColumn { Name = n, HeaderText = h,
                MinimumWidth = w > 0 ? w : 40, Visible = v,
                SortMode = DataGridViewColumnSortMode.Automatic };
        private static Label L(string t, int x, int y, int w) =>
            new Label { Text = t, Font = UITheme.FontLabel, ForeColor = UITheme.TextSecondary,
                AutoSize = false, Size = new Size(w, 18), Location = new Point(x, y),
                BackColor = UITheme.BgSurface };
        private static Label E(int x, int y, int w) =>
            new Label { Text = "", Font = new Font("Segoe UI", 7.8f), ForeColor = UITheme.SemanticDanger,
                AutoSize = false, Size = new Size(w, 14), Location = new Point(x, y),
                BackColor = UITheme.BgSurface, Visible = false };
    }
}
