using System;
using System.IO;
using System.Data;
using System.Data.SQLite;

namespace ClinicVets.Data
{
    /// <summary>
    /// Singleton DatabaseHelper - manages all SQLite operations.
    /// Handles connection management, table creation, migrations and seed data.
    /// </summary>
    public sealed class DatabaseHelper
    {
        // ─────────────────────────────────────────────
        //  Singleton
        // ─────────────────────────────────────────────
        private static readonly Lazy<DatabaseHelper> _instance =
            new Lazy<DatabaseHelper>(() => new DatabaseHelper());

        public static DatabaseHelper Instance => _instance.Value;

        // ─────────────────────────────────────────────
        //  Configuration
        // ─────────────────────────────────────────────
        private static readonly string DbFolder =
            Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                "ClinicVets");

        private static readonly string DbPath =
            Path.Combine(DbFolder, "clinicvets.db");

        public static readonly string ConnectionString =
            $"Data Source={DbPath};Version=3;Foreign Keys=True;";

        // ─────────────────────────────────────────────
        //  Constructor
        // ─────────────────────────────────────────────
        private DatabaseHelper()
        {
            try
            {
                if (!Directory.Exists(DbFolder))
                    Directory.CreateDirectory(DbFolder);

                InitializeDatabase();
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException(
                    $"[DatabaseHelper] Failed to initialise database: {ex.Message}", ex);
            }
        }

        private void InitializeDatabase()
        {
            bool isNew = !File.Exists(DbPath);
            CreateTables();
            if (isNew) SeedData();
            else
            {
                EnsureAnimalTypes();
                EnsureMedicines();
            }
        }

        /// <summary>Ensures medicines exist even in existing databases.</summary>
        private void EnsureMedicines()
        {
            using (var conn = GetConnection())
            {
                var medicines = new[]
                {
                    ("Amoxicillin",        "Broad-spectrum antibiotic",           "mg",      0.05, 5000.0, 500.0),
                    ("Metronidazole",      "Antibiotic / antiprotozoal",          "mg",      0.08, 3000.0, 300.0),
                    ("Prednisone",         "Corticosteroid anti-inflammatory",    "mg",      0.10, 2000.0, 200.0),
                    ("Frontline",          "Flea and tick preventative",          "ml",     12.50,  200.0,  20.0),
                    ("Rimadyl",            "NSAID pain relief (carprofen)",       "mg",      0.30, 1500.0, 150.0),
                    ("Heartgard",          "Heartworm preventative",              "tablet",  8.00,  300.0,  30.0),
                    ("Baytril",            "Fluoroquinolone antibiotic",          "mg",      0.12, 2500.0, 250.0),
                    ("Vitamin B12",        "Nutritional supplement injection",    "ml",      3.50,  500.0,  50.0),
                    ("Dexamethasone",      "Steroid anti-inflammatory",           "mg",      0.15, 1000.0, 100.0),
                    ("Ivermectin",         "Antiparasitic - dewormer",            "ml",      4.50,  400.0,  40.0),
                    ("Meloxicam",          "Anti-inflammatory pain relief",       "mg",      0.20, 1200.0, 120.0),
                    ("Ringer's Lactate",   "IV fluid for hydration",              "ml",      0.02, 8000.0, 800.0)
                };

                const string sql = @"
                    INSERT OR IGNORE INTO Medicines
                        (Name, Description, Unit, UnitPrice, StockQty, ReorderLevel)
                    VALUES (@N, @D, @U, @P, @S, @R);";

                foreach (var (n, d, u, p, s, r) in medicines)
                    ExecuteNonQueryConn(conn, sql,
                        new System.Data.SQLite.SQLiteParameter("@N", n),
                        new System.Data.SQLite.SQLiteParameter("@D", d),
                        new System.Data.SQLite.SQLiteParameter("@U", u),
                        new System.Data.SQLite.SQLiteParameter("@P", p),
                        new System.Data.SQLite.SQLiteParameter("@S", s),
                        new System.Data.SQLite.SQLiteParameter("@R", r));
            }
        }

        /// <summary>Ensures the 4 required animal types exist even in old databases.</summary>
        private void EnsureAnimalTypes()
        {
            using (var conn = GetConnection())
            {
                var types = new[]
                {
                    ("Dog",     "Domestic canine"),
                    ("Cat",     "Domestic feline"),
                    ("Bird",    "Avian species"),
                    ("Reptile", "Lizards, snakes, turtles")
                };
                foreach (var (name, desc) in types)
                    ExecuteNonQueryConn(conn,
                        "INSERT OR IGNORE INTO AnimalTypes (TypeName, Description) VALUES (@N, @D);",
                        new System.Data.SQLite.SQLiteParameter("@N", name),
                        new System.Data.SQLite.SQLiteParameter("@D", desc));
            }
        }

        // ─────────────────────────────────────────────
        //  Connection factory
        // ─────────────────────────────────────────────
        public SQLiteConnection GetConnection()
        {
            try
            {
                var conn = new SQLiteConnection(ConnectionString);
                conn.Open();
                using (var cmd = new SQLiteCommand("PRAGMA foreign_keys = ON;", conn))
                    cmd.ExecuteNonQuery();
                return conn;
            }
            catch (Exception ex)
            {
                throw new DataException(
                    $"[DatabaseHelper] Unable to open connection: {ex.Message}", ex);
            }
        }

        // ═════════════════════════════════════════════
        //  CREATE TABLES
        // ═════════════════════════════════════════════
        public void CreateTables()
        {
            using (var conn = GetConnection())
            using (var tx = conn.BeginTransaction())
            {
                try
                {
                    CreateTableEmployees(conn);
                    CreateTableAnimalTypes(conn);
                    CreateTableCustomers(conn);
                    CreateTableAnimals(conn);
                    CreateTableVisits(conn);
                    CreateTableMedicines(conn);
                    CreateTableVisitMedicines(conn);
                    tx.Commit();
                }
                catch (Exception ex)
                {
                    tx.Rollback();
                    throw new DataException(
                        $"[CreateTables] Table creation failed: {ex.Message}", ex);
                }
            }
        }

        private void CreateTableEmployees(SQLiteConnection conn)
        {
            const string sql = @"
                CREATE TABLE IF NOT EXISTS Employees (
                    EmployeeId     INTEGER PRIMARY KEY AUTOINCREMENT,
                    Username       TEXT    NOT NULL UNIQUE,
                    FirstName      TEXT    NOT NULL,
                    LastName       TEXT    NOT NULL,
                    Role           TEXT    NOT NULL
                                   CHECK(Role IN ('Veterinarian','Secretary')),
                    Phone          TEXT,
                    Email          TEXT    UNIQUE,
                    EmployeeNumber TEXT    NOT NULL UNIQUE,
                    IdNumber       TEXT    NOT NULL UNIQUE,
                    HireDate       TEXT    NOT NULL DEFAULT (DATE('now')),
                    IsActive       INTEGER NOT NULL DEFAULT 1 CHECK(IsActive IN (0,1)),
                    PasswordHash   TEXT,
                    CreatedAt      TEXT    NOT NULL DEFAULT (DATETIME('now')),
                    UpdatedAt      TEXT    NOT NULL DEFAULT (DATETIME('now'))
                );";
            ExecuteNonQueryConn(conn, sql);
        }

        private void CreateTableAnimalTypes(SQLiteConnection conn)
        {
            const string sql = @"
                CREATE TABLE IF NOT EXISTS AnimalTypes (
                    AnimalTypeId INTEGER PRIMARY KEY AUTOINCREMENT,
                    TypeName     TEXT    NOT NULL UNIQUE,
                    Description  TEXT,
                    CreatedAt    TEXT    NOT NULL DEFAULT (DATETIME('now'))
                );";
            ExecuteNonQueryConn(conn, sql);
        }

        private void CreateTableCustomers(SQLiteConnection conn)
        {
            const string sql = @"
                CREATE TABLE IF NOT EXISTS Customers (
                    CustomerId  INTEGER PRIMARY KEY AUTOINCREMENT,
                    FirstName   TEXT    NOT NULL,
                    LastName    TEXT    NOT NULL,
                    Phone       TEXT    NOT NULL,
                    Email       TEXT    UNIQUE,
                    Address     TEXT,
                    City        TEXT,
                    Notes       TEXT,
                    NationalId  TEXT,
                    IsActive    INTEGER NOT NULL DEFAULT 1 CHECK(IsActive IN (0,1)),
                    CreatedAt   TEXT    NOT NULL DEFAULT (DATETIME('now')),
                    UpdatedAt   TEXT    NOT NULL DEFAULT (DATETIME('now'))
                );";
            ExecuteNonQueryConn(conn, sql);

            // Safe migration for existing databases
            AddColumnIfMissing(conn, "Customers", "NationalId", "TEXT");
        }

        private void CreateTableAnimals(SQLiteConnection conn)
        {
            const string sql = @"
                CREATE TABLE IF NOT EXISTS Animals (
                    AnimalId     INTEGER PRIMARY KEY AUTOINCREMENT,
                    CustomerId   INTEGER NOT NULL,
                    AnimalTypeId INTEGER NOT NULL,
                    Name         TEXT    NOT NULL,
                    Breed        TEXT,
                    DateOfBirth  TEXT,
                    Gender       TEXT    CHECK(Gender IN ('Male','Female','Unknown')),
                    Weight       REAL,
                    Color        TEXT,
                    Microchip    TEXT    UNIQUE,
                    VaccineDate  TEXT,
                    Notes        TEXT,
                    IsActive     INTEGER NOT NULL DEFAULT 1 CHECK(IsActive IN (0,1)),
                    CreatedAt    TEXT    NOT NULL DEFAULT (DATETIME('now')),
                    UpdatedAt    TEXT    NOT NULL DEFAULT (DATETIME('now')),
                    FOREIGN KEY (CustomerId)
                        REFERENCES Customers(CustomerId) ON DELETE RESTRICT ON UPDATE CASCADE,
                    FOREIGN KEY (AnimalTypeId)
                        REFERENCES AnimalTypes(AnimalTypeId) ON DELETE RESTRICT ON UPDATE CASCADE
                );";
            ExecuteNonQueryConn(conn, sql);

            // Create indexes separately (safe if they already exist)
            try
            {
                ExecuteNonQueryConn(conn,
                "CREATE INDEX IF NOT EXISTS idx_animals_customer   ON Animals(CustomerId);");
            }
            catch { }
            try
            {
                ExecuteNonQueryConn(conn,
                "CREATE INDEX IF NOT EXISTS idx_animals_animaltype ON Animals(AnimalTypeId);");
            }
            catch { }

            // Safe migration
            AddColumnIfMissing(conn, "Animals", "VaccineDate", "TEXT");
        }

        private void CreateTableVisits(SQLiteConnection conn)
        {
            const string sql = @"
                CREATE TABLE IF NOT EXISTS Visits (
                    VisitId      INTEGER PRIMARY KEY AUTOINCREMENT,
                    AnimalId     INTEGER NOT NULL,
                    EmployeeId   INTEGER NOT NULL,
                    VisitDate    TEXT    NOT NULL DEFAULT (DATE('now')),
                    Reason       TEXT    NOT NULL,
                    Diagnosis    TEXT,
                    Treatment    TEXT,
                    Notes        TEXT,
                    TotalCost    REAL    NOT NULL DEFAULT 0.0 CHECK(TotalCost >= 0),
                    IsPaid       INTEGER NOT NULL DEFAULT 0 CHECK(IsPaid IN (0,1)),
                    Status       TEXT    NOT NULL DEFAULT 'Scheduled'
                                 CHECK(Status IN ('Scheduled','InProgress','Completed','Cancelled')),
                    CreatedAt    TEXT    NOT NULL DEFAULT (DATETIME('now')),
                    UpdatedAt    TEXT    NOT NULL DEFAULT (DATETIME('now')),
                    FOREIGN KEY (AnimalId)
                        REFERENCES Animals(AnimalId) ON DELETE RESTRICT ON UPDATE CASCADE,
                    FOREIGN KEY (EmployeeId)
                        REFERENCES Employees(EmployeeId) ON DELETE RESTRICT ON UPDATE CASCADE
                );";
            ExecuteNonQueryConn(conn, sql);

            try
            {
                ExecuteNonQueryConn(conn,
                "CREATE INDEX IF NOT EXISTS idx_visits_animal   ON Visits(AnimalId);");
            }
            catch { }
            try
            {
                ExecuteNonQueryConn(conn,
                "CREATE INDEX IF NOT EXISTS idx_visits_employee ON Visits(EmployeeId);");
            }
            catch { }
            try
            {
                ExecuteNonQueryConn(conn,
                "CREATE INDEX IF NOT EXISTS idx_visits_date     ON Visits(VisitDate);");
            }
            catch { }

            // Safe migration - add VisitTime to existing databases
            AddColumnIfMissing(conn, "Visits", "VisitTime", "TEXT NOT NULL DEFAULT '00:00'");
            // Safe migration - add new employee fields
            AddColumnIfMissing(conn, "Employees", "Username", "TEXT NOT NULL DEFAULT 'user'");
            AddColumnIfMissing(conn, "Employees", "EmployeeNumber", "TEXT NOT NULL DEFAULT '0000'");
            AddColumnIfMissing(conn, "Employees", "IdNumber", "TEXT NOT NULL DEFAULT '000000000'");
        }

        private void CreateTableMedicines(SQLiteConnection conn)
        {
            const string sql = @"
                CREATE TABLE IF NOT EXISTS Medicines (
                    MedicineId   INTEGER PRIMARY KEY AUTOINCREMENT,
                    Name         TEXT    NOT NULL UNIQUE,
                    Description  TEXT,
                    Unit         TEXT    NOT NULL DEFAULT 'mg',
                    UnitPrice    REAL    NOT NULL DEFAULT 0.0 CHECK(UnitPrice >= 0),
                    StockQty     REAL    NOT NULL DEFAULT 0.0 CHECK(StockQty >= 0),
                    ReorderLevel REAL    NOT NULL DEFAULT 10.0,
                    IsActive     INTEGER NOT NULL DEFAULT 1 CHECK(IsActive IN (0,1)),
                    CreatedAt    TEXT    NOT NULL DEFAULT (DATETIME('now')),
                    UpdatedAt    TEXT    NOT NULL DEFAULT (DATETIME('now'))
                );";
            ExecuteNonQueryConn(conn, sql);
        }

        private void CreateTableVisitMedicines(SQLiteConnection conn)
        {
            const string sql = @"
                CREATE TABLE IF NOT EXISTS VisitMedicines (
                    VisitMedicineId INTEGER PRIMARY KEY AUTOINCREMENT,
                    VisitId         INTEGER NOT NULL,
                    MedicineId      INTEGER NOT NULL,
                    Quantity        REAL    NOT NULL CHECK(Quantity > 0),
                    UnitPrice       REAL    NOT NULL CHECK(UnitPrice >= 0),
                    Dosage          TEXT,
                    Instructions    TEXT,
                    CreatedAt       TEXT    NOT NULL DEFAULT (DATETIME('now')),
                    FOREIGN KEY (VisitId)
                        REFERENCES Visits(VisitId) ON DELETE CASCADE ON UPDATE CASCADE,
                    FOREIGN KEY (MedicineId)
                        REFERENCES Medicines(MedicineId) ON DELETE RESTRICT ON UPDATE CASCADE,
                    UNIQUE (VisitId, MedicineId)
                );";
            ExecuteNonQueryConn(conn, sql);

            try
            {
                ExecuteNonQueryConn(conn,
                "CREATE INDEX IF NOT EXISTS idx_visitmeds_visit    ON VisitMedicines(VisitId);");
            }
            catch { }
            try
            {
                ExecuteNonQueryConn(conn,
                "CREATE INDEX IF NOT EXISTS idx_visitmeds_medicine ON VisitMedicines(MedicineId);");
            }
            catch { }
        }

        /// <summary>Adds a column only if it doesn't already exist (safe migration).</summary>
        private void AddColumnIfMissing(SQLiteConnection conn,
            string table, string column, string type)
        {
            const string checkSql =
                "SELECT COUNT(*) FROM pragma_table_info('{0}') WHERE name='{1}';";
            using (var cmd = new SQLiteCommand(
                string.Format(checkSql, table, column), conn))
            {
                long count = (long)cmd.ExecuteScalar();
                if (count == 0)
                {
                    using (var alter = new SQLiteCommand(
                        $"ALTER TABLE {table} ADD COLUMN {column} {type};", conn))
                        alter.ExecuteNonQuery();
                }
            }
        }

        // ═════════════════════════════════════════════
        //  SEED DATA
        // ═════════════════════════════════════════════
        private void SeedData()
        {
            using (var conn = GetConnection())
            using (var tx = conn.BeginTransaction())
            {
                try
                {
                    // Only seed lookup/reference data and staff accounts.
                    // Customers, Animals, Medicines, Visits start EMPTY
                    // so users see only what they add themselves.
                    SeedAnimalTypes(conn);
                    SeedEmployees(conn);
                    tx.Commit();
                }
                catch (Exception ex)
                {
                    tx.Rollback();
                    throw new DataException($"[SeedData] Failed: {ex.Message}", ex);
                }
            }
        }

        private void SeedAnimalTypes(SQLiteConnection conn)
        {
            var rows = new[]
            {
                ("Dog",     "Domestic canine"),
                ("Cat",     "Domestic feline"),
                ("Bird",    "Avian species including parrots and canaries"),
                ("Rabbit",  "Domestic rabbit"),
                ("Hamster", "Small rodent"),
                ("Reptile", "Lizards, snakes, turtles"),
                ("Fish",    "Freshwater and saltwater fish"),
                ("Other",   "Other animal types")
            };
            const string sql =
                "INSERT OR IGNORE INTO AnimalTypes (TypeName, Description) VALUES (@N, @D);";
            foreach (var (n, d) in rows)
                ExecuteNonQueryConn(conn, sql,
                    new SQLiteParameter("@N", n),
                    new SQLiteParameter("@D", d));
        }

        private void SeedEmployees(SQLiteConnection conn)
        {
            // Default password "Clinic@1" - SHA-256 hash
            const string hash =
                "5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8";

            // (Username, FirstName, LastName, Role, Phone, Email, EmployeeNumber, IdNumber, HireDate)
            var rows = new[]
            {
                ("sarah01",  "Sarah",  "Mitchell", "Veterinarian", "+972-50-1001001",
                 "sarah.mitchell@clinicvets.com",  "1001", "123456782", "2020-03-15"),
                ("james02",  "James",  "Thornton", "Veterinarian", "+972-50-1002002",
                 "james.thornton@clinicvets.com",  "1002", "234567891", "2019-07-01"),
                ("emily03",  "Emily",  "Carter",   "Secretary",    "+972-52-1003003",
                 "emily.carter@clinicvets.com",    "1003", "345678901", "2021-01-10"),
                ("omar01",   "Omar",   "Mareed",   "Secretary",    "+972-54-1004004",
                 "omar@clinicvets.com",            "1004", "025484056", "2022-05-20")
            };

            const string sql = @"
                INSERT OR IGNORE INTO Employees
                    (Username,FirstName,LastName,Role,Phone,Email,
                     EmployeeNumber,IdNumber,HireDate,IsActive,PasswordHash)
                VALUES (@User,@FN,@LN,@Role,@Phone,@Email,
                        @EmpNum,@IdNum,@Hire,1,@Hash);";

            foreach (var (user, fn, ln, role, phone, email, empnum, idnum, hire) in rows)
                ExecuteNonQueryConn(conn, sql,
                    new SQLiteParameter("@User", user),
                    new SQLiteParameter("@FN", fn),
                    new SQLiteParameter("@LN", ln),
                    new SQLiteParameter("@Role", role),
                    new SQLiteParameter("@Phone", phone),
                    new SQLiteParameter("@Email", email),
                    new SQLiteParameter("@EmpNum", empnum),
                    new SQLiteParameter("@IdNum", idnum),
                    new SQLiteParameter("@Hire", hire),
                    new SQLiteParameter("@Hash", hash));
        }

        private void SeedCustomers(SQLiteConnection conn)
        {
            var rows = new[]
            {
                ("Alice",  "Johnson",  "+972-50-1001001", "alice.johnson@email.com",
                 "12 Oak Lane",        "Tel Aviv",   "123456782"),
                ("Bob",    "Williams", "+972-52-2002002", "bob.williams@email.com",
                 "34 Maple Street",    "Jerusalem",  "234567891"),
                ("Carol",  "Davis",    "+972-54-3003003", "carol.davis@email.com",
                 "56 Pine Avenue",     "Haifa",      "345678901"),
                ("David",  "Brown",    "+972-58-4004004", "david.brown@email.com",
                 "78 Cedar Road",      "Beer Sheva", "456789012"),
                ("Emma",   "Wilson",   "+972-50-5005005", "emma.wilson@email.com",
                 "90 Birch Boulevard", "Tel Aviv",   "567890123"),
                ("Frank",  "Martinez", "+972-52-6006006", "frank.martinez@email.com",
                 "102 Elm Court",      "Netanya",    "678901234")
            };

            const string sql = @"
                INSERT OR IGNORE INTO Customers
                    (FirstName,LastName,Phone,Email,Address,City,NationalId)
                VALUES (@FN,@LN,@Phone,@Email,@Addr,@City,@NID);";

            foreach (var (fn, ln, phone, email, addr, city, nid) in rows)
                ExecuteNonQueryConn(conn, sql,
                    new SQLiteParameter("@FN", fn),
                    new SQLiteParameter("@LN", ln),
                    new SQLiteParameter("@Phone", phone),
                    new SQLiteParameter("@Email", email),
                    new SQLiteParameter("@Addr", addr),
                    new SQLiteParameter("@City", city),
                    new SQLiteParameter("@NID", nid));
        }

        private void SeedAnimals(SQLiteConnection conn)
        {
            var rows = new[]
            {
                (1, 1, "Buddy",    "Labrador Retriever", "2019-06-15", "Male",   28.5,  "2024-03-10"),
                (1, 2, "Whiskers", "Domestic Shorthair", "2020-03-10", "Female",  4.2,  "2024-01-22"),
                (2, 1, "Max",      "German Shepherd",    "2018-11-20", "Male",   34.0,  "2022-11-05"),
                (3, 2, "Luna",     "Siamese",            "2021-01-05", "Female",  3.8,  "2024-05-01"),
                (3, 3, "Tweety",   "Canary",             "2022-04-18", "Male",    0.02, (string)null),
                (4, 4, "Thumper",  "Holland Lop",        "2021-09-30", "Male",    2.1,  "2024-02-14"),
                (5, 1, "Bella",    "Golden Retriever",   "2020-07-22", "Female", 27.3,  "2024-04-20"),
                (6, 5, "Peanut",   "Syrian Hamster",     "2023-02-14", "Male",    0.12, (string)null)
            };

            const string sql = @"
                INSERT OR IGNORE INTO Animals
                    (CustomerId,AnimalTypeId,Name,Breed,DateOfBirth,Gender,Weight,VaccineDate)
                VALUES (@CID,@TID,@Name,@Breed,@DOB,@Gender,@Weight,@Vax);";

            foreach (var (cid, tid, name, breed, dob, gender, weight, vax) in rows)
                ExecuteNonQueryConn(conn, sql,
                    new SQLiteParameter("@CID", cid),
                    new SQLiteParameter("@TID", tid),
                    new SQLiteParameter("@Name", name),
                    new SQLiteParameter("@Breed", breed),
                    new SQLiteParameter("@DOB", dob),
                    new SQLiteParameter("@Gender", gender),
                    new SQLiteParameter("@Weight", weight),
                    new SQLiteParameter("@Vax",
                        vax != null ? (object)vax : DBNull.Value));
        }

        private void SeedMedicines(SQLiteConnection conn)
        {
            var rows = new[]
            {
                ("Amoxicillin",   "Broad-spectrum antibiotic",         "mg",     0.05, 5000.0, 500.0),
                ("Metronidazole", "Antibiotic/antiprotozoal",          "mg",     0.08, 3000.0, 300.0),
                ("Prednisone",    "Corticosteroid anti-inflammatory",  "mg",     0.10, 2000.0, 200.0),
                ("Frontline",     "Flea and tick preventative",        "ml",    12.50,  200.0,  20.0),
                ("Rimadyl",       "NSAID pain relief (carprofen)",     "mg",     0.30, 1500.0, 150.0),
                ("Heartgard",     "Heartworm preventative (monthly)",  "tablet", 8.00,  300.0,  30.0),
                ("Baytril",       "Fluoroquinolone antibiotic",        "mg",     0.12, 2500.0, 250.0),
                ("Vitamin B12",   "Nutritional supplement injection",  "ml",     3.50,  500.0,  50.0)
            };

            const string sql = @"
                INSERT OR IGNORE INTO Medicines
                    (Name,Description,Unit,UnitPrice,StockQty,ReorderLevel)
                VALUES (@N,@D,@U,@P,@S,@R);";

            foreach (var (n, d, u, p, s, r) in rows)
                ExecuteNonQueryConn(conn, sql,
                    new SQLiteParameter("@N", n),
                    new SQLiteParameter("@D", d),
                    new SQLiteParameter("@U", u),
                    new SQLiteParameter("@P", p),
                    new SQLiteParameter("@S", s),
                    new SQLiteParameter("@R", r));
        }

        private void SeedVisits(SQLiteConnection conn)
        {
            var rows = new[]
            {
                (1, 1, "2024-11-05", "Annual wellness exam",
                 "Healthy, vaccines due",          "Vaccinations administered",        85.00, 1, "Completed"),
                (1, 1, "2025-01-20", "Limping on front right leg",
                 "Mild sprain",                    "Rest and anti-inflammatory",      120.00, 1, "Completed"),
                (2, 2, "2025-02-14", "Vomiting and lethargy",
                 "Gastrointestinal upset",          "IV fluids, antibiotic course",   200.00, 1, "Completed"),
                (3, 1, "2025-03-01", "Routine check-up",
                 "Healthy",                         "Heartworm prevention prescribed", 95.00, 1, "Completed"),
                (4, 2, "2025-04-10", "Weight loss, poor appetite",
                 "Hyperthyroidism suspected",       "Blood panel ordered, diet change",175.00, 0, "Completed"),
                (7, 1, "2025-05-12", "Post-spay follow-up",
                 "Incision healing well",           "Suture removal, pain management",  60.00, 0, "Completed"),
                (8, 2, "2025-05-13", "Annual check-up",
                 "Scheduled",                       "",                                  0.00, 0, "Scheduled")
            };

            const string sql = @"
                INSERT OR IGNORE INTO Visits
                    (AnimalId,EmployeeId,VisitDate,Reason,Diagnosis,Treatment,TotalCost,IsPaid,Status)
                VALUES (@AID,@EID,@Date,@Reason,@Diag,@Treat,@Cost,@Paid,@Status);";

            foreach (var (aid, eid, date, reason, diag, treat, cost, paid, status) in rows)
                ExecuteNonQueryConn(conn, sql,
                    new SQLiteParameter("@AID", aid),
                    new SQLiteParameter("@EID", eid),
                    new SQLiteParameter("@Date", date),
                    new SQLiteParameter("@Reason", reason),
                    new SQLiteParameter("@Diag", diag),
                    new SQLiteParameter("@Treat", treat),
                    new SQLiteParameter("@Cost", cost),
                    new SQLiteParameter("@Paid", paid),
                    new SQLiteParameter("@Status", status));
        }

        private void SeedVisitMedicines(SQLiteConnection conn)
        {
            var rows = new[]
            {
                (2, 5, 30.0,  0.30, "25 mg",    "Once daily 5 days"),
                (3, 1, 500.0, 0.05, "250 mg",   "Twice daily 7 days"),
                (3, 2, 250.0, 0.08, "125 mg",   "Once daily 5 days"),
                (4, 6, 1.0,   8.00, "1 tablet", "Once monthly, chewed"),
                (6, 5, 14.0,  0.30, "25 mg",    "Once daily 3 days post-op")
            };

            const string sql = @"
                INSERT OR IGNORE INTO VisitMedicines
                    (VisitId,MedicineId,Quantity,UnitPrice,Dosage,Instructions)
                VALUES (@VID,@MID,@Qty,@Price,@Dosage,@Instr);";

            foreach (var (vid, mid, qty, price, dosage, instr) in rows)
                ExecuteNonQueryConn(conn, sql,
                    new SQLiteParameter("@VID", vid),
                    new SQLiteParameter("@MID", mid),
                    new SQLiteParameter("@Qty", qty),
                    new SQLiteParameter("@Price", price),
                    new SQLiteParameter("@Dosage", dosage),
                    new SQLiteParameter("@Instr", instr));
        }

        // ═════════════════════════════════════════════
        //  PUBLIC QUERY HELPERS
        // ═════════════════════════════════════════════

        /// <summary>Executes a SELECT and returns a DataTable.</summary>
        public DataTable ExecuteQuery(string sql, params SQLiteParameter[] parameters)
        {
            var dt = new DataTable();
            try
            {
                using (var conn = GetConnection())
                using (var cmd = new SQLiteCommand(sql, conn))
                {
                    if (parameters != null)
                        foreach (var p in parameters)
                            cmd.Parameters.Add(p);

                    using (var adapter = new SQLiteDataAdapter(cmd))
                        adapter.Fill(dt);
                }
            }
            catch (Exception ex)
            {
                throw new DataException(
                    $"[ExecuteQuery] Query failed:\n{sql}\n{ex.Message}", ex);
            }
            return dt;
        }

        /// <summary>Executes INSERT / UPDATE / DELETE. Returns rows affected.</summary>
        public int ExecuteNonQuery(string sql, params SQLiteParameter[] parameters)
        {
            try
            {
                using (var conn = GetConnection())
                using (var cmd = new SQLiteCommand(sql, conn))
                {
                    if (parameters != null)
                        foreach (var p in parameters)
                            cmd.Parameters.Add(p);

                    return cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                throw new DataException(
                    $"[ExecuteNonQuery] Command failed:\n{sql}\n{ex.Message}", ex);
            }
        }

        /// <summary>Returns the RowId of the most recent INSERT.</summary>
        public long GetLastInsertId()
        {
            using (var conn = GetConnection())
            using (var cmd = new SQLiteCommand("SELECT last_insert_rowid();", conn))
                return (long)cmd.ExecuteScalar();
        }

        /// <summary>Absolute path of the SQLite database file.</summary>
        public string GetDatabasePath() => DbPath;

        // ─────────────────────────────────────────────
        //  Private connection-scoped helper
        // ─────────────────────────────────────────────
        private void ExecuteNonQueryConn(SQLiteConnection conn, string sql,
            params SQLiteParameter[] parameters)
        {
            using (var cmd = new SQLiteCommand(sql, conn))
            {
                if (parameters != null)
                    foreach (var p in parameters)
                        cmd.Parameters.Add(p);

                cmd.ExecuteNonQuery();
            }
        }
    }
}